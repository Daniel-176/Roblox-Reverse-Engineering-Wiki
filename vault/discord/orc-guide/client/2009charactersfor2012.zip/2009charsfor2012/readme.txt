by VMware/Multiman in ORC Guide

This is supposed to make characters in 2012 Roblox clients appear as they did in 2009. This is mainly for making 2009 character renders using something like rbxRenderHook or ORRH.

To install this, simply drag this folder into your 2012 client's content folder. It should prompt you asking if you want to replace certain things, hit "Yes" and overwrite them. No need to put this readme.txt file in the content folder, feel free to delete it.

--Important
Turn off bevels in studio. If you wish to keep them, to keep an accurate April 2009 type of look, replace textures and optionally sky, but manually remove or unselect all limb meshes in fonts before dragging them into 2012's content folder.