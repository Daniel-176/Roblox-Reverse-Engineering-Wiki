@echo off
cd src
python -m http.server 869
cd ..