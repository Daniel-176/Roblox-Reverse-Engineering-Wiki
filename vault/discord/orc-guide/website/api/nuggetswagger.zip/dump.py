import copy
import json
import re
import shutil
from pathlib import Path
from collections import defaultdict


INPUT_FILE = "swagger.raw"
OUTPUT_DIR = Path("generated")
MASTER_FILE = OUTPUT_DIR / "master.json"

HTTP_METHODS = (
    "get",
    "put",
    "post",
    "delete",
    "options",
    "head",
    "patch",
    "trace",
)


def parse_generic_name(name):
    if "[" not in name:
        return name

    start = name.find("[")
    base = name[:start]
    args = name[start + 1:]

    if args.endswith("]"):
        args = args[:-1]

    depth = 0
    current = []
    arguments = []

    for char in args:
        if char == "[":
            depth += 1
            current.append(char)
        elif char == "]":
            depth -= 1
            current.append(char)
        elif char == "," and depth == 0:
            arguments.append("".join(current))
            current = []
        else:
            current.append(char)

    if current:
        arguments.append("".join(current))

    arguments = [
        parse_generic_name(x.strip())
        for x in arguments
        if x.strip()
    ]

    return f"{base}<{', '.join(arguments)}>"


def clean_type(schema):
    if not schema:
        return "object"

    if "$ref" in schema:
        ref = schema["$ref"].rsplit("/", 1)[-1]
        return parse_generic_name(ref)

    if "schema" in schema and isinstance(schema["schema"], dict):
        return clean_type(schema["schema"])

    if schema.get("type") == "array":
        item_schema = schema.get("items", {})

        if not item_schema:
            return "object[]"

        item_type = clean_type(item_schema)
        collection = schema.get("x-csharp-collection")

        if collection == "List":
            return f"List<{item_type}>"

        return f"{item_type}[]"

    if "allOf" in schema:
        for item in schema["allOf"]:
            if "$ref" in item:
                ref = item["$ref"].rsplit("/", 1)[-1]
                return parse_generic_name(ref)

    typ = schema.get("type")
    fmt = schema.get("format")

    if typ == "integer":
        return {
            "int32": "int",
            "int64": "long",
        }.get(fmt, "int")

    if typ == "number":
        return {
            "float": "float",
            "double": "double",
        }.get(fmt, "double")

    if typ == "string":
        if fmt in ("date-time", "date"):
            return "DateTime"

        return "string"

    if typ == "boolean":
        return "bool"

    return "object"


def split_name(full_name):
    full_name = full_name.strip()

    if "[" in full_name:
        generic_start = full_name.find("[")
        base_name = full_name[:generic_start]

        namespace, class_name = (
            base_name.rsplit(".", 1)
            if "." in base_name
            else ("(global)", base_name)
        )

        generic_name = parse_generic_name(full_name)

        prefix = (
            namespace + "."
            if namespace != "(global)"
            else ""
        )

        if generic_name.startswith(prefix):
            generic_name = generic_name[len(prefix):]

        return namespace, generic_name

    if "." not in full_name:
        return "(global)", full_name

    return full_name.rsplit(".", 1)


def parse_multiple_json(text):
    decoder = json.JSONDecoder()
    documents = []
    pos = 0

    while pos < len(text):
        while pos < len(text) and text[pos].isspace():
            pos += 1

        if pos >= len(text):
            break

        obj, end = decoder.raw_decode(text, pos)

        if isinstance(obj, dict):
            documents.append(obj)

        pos = end

    return documents


def collect_models(documents):
    models = defaultdict(lambda: defaultdict(dict))

    for doc in documents:
        for full_name, schema in doc.get(
            "definitions",
            {},
        ).items():
            namespace, class_name = split_name(full_name)

            for prop, prop_schema in schema.get(
                "properties",
                {},
            ).items():
                prop_type = clean_type(prop_schema)

                if prop not in models[namespace][class_name]:
                    models[namespace][class_name][prop] = prop_type

            models[namespace][class_name]

    return models


def safe_identifier(name):
    name = str(name)

    name = re.sub(
        r"[^A-Za-z0-9_]+",
        "_",
        name,
    )

    if name and name[0].isdigit():
        name = "_" + name

    return name


def nullable_type(typ):
    if typ.endswith("[]"):
        return typ

    if typ.startswith("List<"):
        return typ

    if typ in {
        "string",
        "DateTime",
        "object",
    }:
        return typ + "?"

    return typ


def resolve_schema_type(schema, ref_map):
    if not schema:
        return "object"

    if "$ref" in schema:
        ref = schema["$ref"].rsplit("/", 1)[-1]
        return ref_map.get(ref, ref)

    typ = clean_type(schema)

    if typ == "object":
        additional = schema.get("additionalProperties")

        if isinstance(additional, dict):
            value_type = resolve_schema_type(
                additional,
                ref_map,
            )
            return f"Dictionary<string, {value_type}>"

    if typ.endswith("[]"):
        item_schema = schema.get("items")

        if isinstance(item_schema, dict):
            item_type = resolve_schema_type(
                item_schema,
                ref_map,
            )

            return f"{item_type}[]"

    if typ.startswith("List<"):
        item_schema = schema.get("items")

        if isinstance(item_schema, dict):
            item_type = resolve_schema_type(
                item_schema,
                ref_map,
            )

            return f"List<{item_type}>"

    return typ


def generate_class(
    namespace,
    class_name,
    properties,
):
    if "<" in class_name and class_name.endswith(">"):
        base_name = class_name[
            :class_name.find("<")
        ]

        generic_args = class_name[
            class_name.find("<") + 1:-1
        ]

        class_name = (
            safe_identifier(base_name)
            + "<"
            + ", ".join(
                safe_identifier(
                    x.strip().split(".")[-1]
                )
                for x in generic_args.split(",")
            )
            + ">"
        )
    else:
        class_name = safe_identifier(
            class_name
        )

    lines = [
        "using System;",
        "using System.Collections.Generic;",
        "",
        f"namespace {namespace};",
        "",
        f"public class {class_name}",
        "{",
    ]

    for prop, typ in properties.items():
        prop = safe_identifier(prop)
        typ = nullable_type(typ)

        lines.append(
            f"    public {typ} {prop} {{ get; set; }}"
        )

    lines.extend([
        "}",
        "",
    ])

    return "\n".join(lines)


def namespace_path(namespace):
    if namespace == "(global)":
        return OUTPUT_DIR

    return OUTPUT_DIR.joinpath(
        *namespace.split(".")
    )


def generate_dump(models):
    lines = []

    for namespace in sorted(models):
        lines.append(namespace)

        for class_name in sorted(
            models[namespace]
        ):
            lines.append(
                f"  {class_name}"
            )

            for prop, typ in sorted(
                models[namespace][class_name].items()
            ):
                lines.append(
                    f"    {prop}: {typ}"
                )

        lines.append("")

    (OUTPUT_DIR / "dump.txt").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def sanitize_ref_name(name):
    return re.sub(
        r"[^A-Za-z0-9_.-]+",
        "_",
        str(name),
    )


def clone_with_refs(value, ref_map):
    if isinstance(value, dict):
        result = {}

        for key, item in value.items():
            if (
                key == "$ref"
                and isinstance(item, str)
                and item.startswith(
                    "#/definitions/"
                )
            ):
                old_name = item[
                    len("#/definitions/"):
                ]

                new_name = ref_map.get(
                    old_name,
                    old_name,
                )

                result[key] = (
                    "#/components/schemas/"
                    + new_name
                )

            elif key == "definitions":
                continue

            else:
                result[key] = clone_with_refs(
                    item,
                    ref_map,
                )

        return result

    if isinstance(value, list):
        return [
            clone_with_refs(
                item,
                ref_map,
            )
            for item in value
        ]

    return value


def definition_signature(schema):
    return json.dumps(
        schema,
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
    )


def make_unique_name(name, used):
    if name not in used:
        return name

    counter = 2

    while True:
        candidate = f"{name}_{counter}"

        if candidate not in used:
            return candidate

        counter += 1


def merge_definitions(documents, master):
    definitions = (
        master["components"]["schemas"]
    )

    signatures = {}
    collisions = []

    for doc in documents:
        metadata = doc.get(
            "_metadata",
            doc.get("_source", {}),
        )

        host = metadata.get(
            "host",
            "unknown",
        )

        version = metadata.get(
            "version",
            "unknown",
        )

        source_definitions = doc.get(
            "definitions",
            {},
        )

        ref_map = {}

        for original_name, schema in (
            source_definitions.items()
        ):
            signature = definition_signature(
                schema
            )

            clean_name = sanitize_ref_name(
                original_name
            )

            if clean_name not in definitions:
                ref_map[
                    original_name
                ] = clean_name

                continue

            existing_signature = signatures.get(
                clean_name
            )

            if existing_signature == signature:
                ref_map[
                    original_name
                ] = clean_name

                continue

            candidate = sanitize_ref_name(
                f"{clean_name}_{host}_{version}"
            )

            target_name = make_unique_name(
                candidate,
                definitions,
            )

            ref_map[
                original_name
            ] = target_name

            collisions.append({
                "original": original_name,
                "generated": target_name,
                "host": host,
                "version": version,
            })

        doc["_master_ref_map"] = ref_map

        for original_name, schema in (
            source_definitions.items()
        ):
            target_name = ref_map[
                original_name
            ]

            if target_name in definitions:
                continue

            converted = clone_with_refs(
                schema,
                ref_map,
            )

            definitions[
                target_name
            ] = converted

            signatures[
                target_name
            ] = definition_signature(
                converted
            )

    if collisions:
        master[
            "x-roblox-definition-collisions"
        ] = collisions

    return documents


def get_document_metadata(doc):
    metadata = doc.get(
        "_metadata"
    )

    if metadata:
        return metadata

    return doc.get(
        "_source",
        {},
    )


def operation_metadata(
    operation,
    doc,
):
    metadata = get_document_metadata(
        doc
    )

    result = copy.deepcopy(
        operation
    )

    result["x-roblox-host"] = (
        metadata.get(
            "host",
            "unknown",
        )
    )

    result["x-roblox-version"] = (
        metadata.get(
            "version",
            "unknown",
        )
    )

    result["x-roblox-source"] = {
        "host": metadata.get(
            "host"
        ),
        "version": metadata.get(
            "version"
        ),
        "snapshot": metadata.get(
            "snapshot"
        ),
        "url": metadata.get(
            "sourceUrl",
            metadata.get("url"),
        ),
    }

    return result


def merge_path_operation(
    master_path,
    method,
    operation,
    doc,
):
    operation = operation_metadata(
        operation,
        doc,
    )

    if method not in master_path:
        master_path[
            method
        ] = operation

        return

    existing = master_path[
        method
    ]

    variants = existing.setdefault(
        "x-roblox-variants",
        [],
    )

    variants.append(
        operation
    )


def merge_paths(
    documents,
    master,
):
    paths = master["paths"]

    for doc in documents:
        ref_map = doc.get(
            "_master_ref_map",
            {},
        )

        for path, path_item in doc.get(
            "paths",
            {},
        ).items():

            target_path = paths.setdefault(
                path,
                {},
            )

            for key, value in (
                path_item.items()
            ):
                if key.lower() not in (
                    HTTP_METHODS
                ):
                    if key not in target_path:
                        target_path[key] = (
                            clone_with_refs(
                                value,
                                ref_map,
                            )
                        )

            for method in HTTP_METHODS:
                operation = path_item.get(
                    method
                )

                if not isinstance(
                    operation,
                    dict,
                ):
                    continue

                operation = clone_with_refs(
                    operation,
                    ref_map,
                )

                merge_path_operation(
                    target_path,
                    method,
                    operation,
                    doc,
                )


def merge_tags(
    documents,
    master,
):
    tags = {}
    ordered = []

    for doc in documents:
        for tag in doc.get(
            "tags",
            [],
        ):
            if not isinstance(
                tag,
                dict,
            ):
                continue

            name = tag.get(
                "name"
            )

            if not name:
                continue

            if name not in tags:
                tags[name] = copy.deepcopy(
                    tag
                )

                ordered.append(
                    name
                )

    master["tags"] = [
        tags[name]
        for name in ordered
    ]


def merge_security_definitions(
    documents,
    master,
):
    target = master[
        "components"
    ].setdefault(
        "securitySchemes",
        {},
    )

    for doc in documents:
        definitions = doc.get(
            "securityDefinitions",
            {},
        )

        for name, value in (
            definitions.items()
        ):
            if name not in target:
                target[name] = copy.deepcopy(
                    value
                )


def collect_servers(
    documents,
):
    hosts = set()
    versions = set()

    for doc in documents:
        metadata = get_document_metadata(
            doc
        )

        host = metadata.get(
            "host"
        )

        version = metadata.get(
            "version"
        )

        if host:
            hosts.add(host)

        if version is not None:
            versions.add(str(version))

    hosts = sorted(hosts)

    def version_sort_key(value):
        parts = value.split(".")

        try:
            return (
                tuple(
                    int(
                        part
                    )
                    for part in parts
                ),
                value,
            )
        except ValueError:
            return (
                (999999,),
                value,
            )

    versions = sorted(
        versions,
        key=version_sort_key,
    )

    if not hosts:
        return []

    default_host = hosts[0]
    default_version = (
        versions[0]
        if versions
        else "1"
    )

    server = {
        "url": "https://{host}",
        "description": (
            "Roblox API server"
        ),
        "variables": {
            "host": {
                "default": default_host,
                "enum": hosts,
                "description": (
                    "Roblox API service"
                ),
            },
        },
    }

    server["variables"]["version"] = {
        "default": default_version,
        "enum": versions,
        "description": (
            "Roblox API version"
        ),
    }

    return [server]


def add_server_metadata(
    documents,
    master,
):
    servers = collect_servers(
        documents
    )

    master["servers"] = servers

    matrix = []

    seen = set()

    for doc in documents:
        metadata = get_document_metadata(
            doc
        )

        host = metadata.get(
            "host"
        )

        version = metadata.get(
            "version"
        )

        if not host or version is None:
            continue

        key = (
            host,
            str(version),
        )

        if key in seen:
            continue

        seen.add(key)

        matrix.append({
            "host": host,
            "version": str(version),
            "label": (
                f"{host} / v{version}"
            ),
        })

    matrix.sort(
        key=lambda item: (
            item["host"],
            item["version"],
        )
    )

    master[
        "x-roblox-hosts"
    ] = sorted(
        {
            item["host"]
            for item in matrix
        }
    )

    master[
        "x-roblox-versions"
    ] = sorted(
        {
            item["version"]
            for item in matrix
        }
    )

    master[
        "x-roblox-api-matrix"
    ] = matrix


def merge_top_level(
    documents,
    master,
):
    for field in (
        "consumes",
        "produces",
        "schemes",
        "externalDocs",
    ):
        seen = []

        for doc in documents:
            value = doc.get(
                field
            )

            if isinstance(
                value,
                list,
            ):
                for item in value:
                    if item not in seen:
                        seen.append(item)

        if seen:
            master[field] = seen

    merge_tags(
        documents,
        master,
    )

    merge_security_definitions(
        documents,
        master,
    )


def resolve_ref_name(schema):
    if not isinstance(
        schema,
        dict,
    ):
        return None

    ref = schema.get(
        "$ref"
    )

    if not isinstance(
        ref,
        str,
    ):
        return None

    if ref.startswith(
        "#/components/schemas/"
    ):
        return ref.rsplit("/", 1)[-1]

    if ref.startswith(
        "#/definitions/"
    ):
        return ref.rsplit("/", 1)[-1]

    return None


def request_body_parameter(
    parameters,
):
    for parameter in parameters:
        if parameter.get(
            "in"
        ) == "body":
            return parameter

    return None


def parameter_csharp_type(
    parameter,
    ref_map,
):
    if "schema" in parameter:
        return resolve_schema_type(
            parameter.get("schema"),
            ref_map,
        )

    return resolve_schema_type(
        parameter,
        ref_map,
    )


def get_response_schema(
    operation,
):
    responses = operation.get(
        "responses",
        {},
    )

    successful = []

    for status, response in responses.items():
        try:
            status_code = int(status)
        except (
            TypeError,
            ValueError,
        ):
            continue

        if 200 <= status_code < 300:
            successful.append(
                (
                    status_code,
                    response,
                )
            )

    successful.sort(
        key=lambda item: item[0]
    )

    for _, response in successful:
        if not isinstance(
            response,
            dict,
        ):
            continue

        schema = response.get(
            "schema"
        )

        if schema:
            return schema

        content = response.get(
            "content"
        )

        if isinstance(
            content,
            dict,
        ):
            for media_type in content.values():
                if isinstance(
                    media_type,
                    dict,
                ):
                    schema = media_type.get(
                        "schema"
                    )

                    if schema:
                        return schema

    return None


def get_return_type(
    operation,
    ref_map,
):
    schema = get_response_schema(
        operation
    )

    if not schema:
        return "IActionResult"

    return_type = resolve_schema_type(
        schema,
        ref_map,
    )

    if return_type == "void":
        return "IActionResult"

    return f"ActionResult<{return_type}>"


def get_operation_name(
    operation,
    method,
    path,
):
    operation_id = operation.get(
        "operationId"
    )

    if operation_id:
        return safe_identifier(
            operation_id
        )

    parts = [
        method.lower()
    ]

    for part in re.split(
        r"[/{}]+",
        path,
    ):
        if not part:
            continue

        clean = safe_identifier(
            part
        )

        if clean:
            parts.append(
                clean[:1].upper()
                + clean[1:]
            )

    return "".join(parts)


def controller_name_from_tag(tag):
    tag = tag or "Default"

    name = safe_identifier(
        tag
    )

    if not name:
        name = "Default"

    if not name.endswith(
        "Controller"
    ):
        name += "Controller"

    return name


def route_template(path):
    return path.strip(
        "/"
    )


def controller_parameter(
    parameter,
    ref_map,
    body_parameter=None,
):
    name = safe_identifier(
        parameter.get(
            "name",
            "value",
        )
    )

    parameter_type = parameter_csharp_type(
        parameter,
        ref_map,
    )

    required = parameter.get(
        "required",
        False,
    )

    if not required:
        parameter_type = nullable_type(
            parameter_type
        )

    location = parameter.get(
        "in"
    )

    if location == "path":
        attribute = "FromRoute"

    elif location == "query":
        attribute = "FromQuery"

    elif location == "header":
        attribute = "FromHeader"

    elif location == "formData":
        attribute = "FromForm"

    elif location == "cookie":
        attribute = "FromQuery"

    else:
        attribute = None

    if attribute:
        return (
            f"[{attribute}] "
            f"{parameter_type} "
            f"{name}"
        )

    return (
        f"{parameter_type} "
        f"{name}"
    )


def generate_controller_method(
    method,
    path,
    operation,
    ref_map,
):
    lines = []

    operation_name = get_operation_name(
        operation,
        method,
        path,
    )

    return_type = get_return_type(
        operation,
        ref_map,
    )

    route = route_template(
        path
    )

    attribute = (
        f"[Http{method.capitalize()}]"
        if not route
        else f'[Http{method.capitalize()}("{route}")]'
    )

    lines.append(
        f"    {attribute}"
    )

    parameters = operation.get(
        "parameters",
        [],
    )

    body_parameter = request_body_parameter(
        parameters
    )

    signature_parameters = []

    for parameter in parameters:
        if parameter.get(
            "in"
        ) == "body":
            continue

        signature_parameters.append(
            controller_parameter(
                parameter,
                ref_map,
            )
        )

    if body_parameter:
        body_name = safe_identifier(
            body_parameter.get(
                "name",
                "request",
            )
        )

        body_type = parameter_csharp_type(
            body_parameter,
            ref_map,
        )

        if not body_parameter.get(
            "required",
            False,
        ):
            body_type = nullable_type(
                body_type
            )

        signature_parameters.append(
            f"[FromBody] "
            f"{body_type} "
            f"{body_name}"
        )

    signature = ", ".join(
        signature_parameters
    )

    lines.append(
        f"    public {return_type} "
        f"{operation_name}({signature})"
    )

    lines.append(
        "    {"
    )

    if return_type == "IActionResult":
        lines.append(
            "        return StatusCode(501);"
        )
    else:
        lines.append(
            "        return StatusCode(501);"
        )

    lines.append(
        "    }"
    )

    lines.append("")

    return lines


def collect_controller_operations(
    documents,
):
    controllers = defaultdict(list)

    for doc in documents:
        ref_map = doc.get(
            "_master_ref_map",
            {},
        )

        for path, path_item in doc.get(
            "paths",
            {},
        ).items():
            for method in HTTP_METHODS:
                operation = path_item.get(
                    method
                )

                if not isinstance(
                    operation,
                    dict,
                ):
                    continue

                operation = clone_with_refs(
                    operation,
                    ref_map,
                )

                tags = operation.get(
                    "tags"
                )

                if not tags:
                    tags = ["Default"]

                for tag in tags:
                    controller_name = (
                        controller_name_from_tag(
                            tag
                        )
                    )

                    controllers[
                        controller_name
                    ].append({
                        "method": method,
                        "path": path,
                        "operation": operation,
                        "ref_map": ref_map,
                    })

    return controllers


def generate_controller(
    namespace,
    controller_name,
    operations,
):
    lines = [
        "using Microsoft.AspNetCore.Mvc;",
        "",
        f"namespace {namespace};",
        "",
        "[ApiController]",
        f"[Route(\"api/[controller]\")]",
        f"public class {controller_name} : ControllerBase",
        "{",
    ]

    used_methods = set()

    for item in sorted(
        operations,
        key=lambda x: (
            x["path"],
            x["method"],
            x["operation"].get(
                "operationId",
                "",
            ),
        ),
    ):
        method_name = get_operation_name(
            item["operation"],
            item["method"],
            item["path"],
        )

        base_name = method_name
        counter = 2

        while method_name in used_methods:
            method_name = (
                f"{base_name}{counter}"
            )
            counter += 1

        used_methods.add(
            method_name
        )

        lines.extend(
            generate_controller_method(
                item["method"],
                item["path"],
                item["operation"],
                item["ref_map"],
            )
        )

    lines.extend([
        "}",
        "",
    ])

    return "\n".join(lines)


def generate_controllers(
    documents,
):
    controllers_dir = (
        OUTPUT_DIR / "controllers"
    )

    controllers_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    controllers = (
        collect_controller_operations(
            documents
        )
    )

    files = 0

    for controller_name in sorted(
        controllers
    ):
        output = generate_controller(
            "Roblox.Website.Controllers",
            controller_name,
            controllers[
                controller_name
            ],
        )

        path = controllers_dir / (
            f"{controller_name}.cs"
        )

        path.write_text(
            output,
            encoding="utf-8",
        )

        files += 1

    return files


def generate(
    models,
    documents,
):
    if OUTPUT_DIR.exists():
        shutil.rmtree(
            OUTPUT_DIR
        )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    files = 0

    for namespace in sorted(
        models
    ):
        folder = namespace_path(
            namespace
        )

        folder.mkdir(
            parents=True,
            exist_ok=True,
        )

        for class_name in sorted(
            models[namespace]
        ):
            output = generate_class(
                namespace,
                class_name,
                models[
                    namespace
                ][class_name],
            )

            file_name = class_name.split(
                "<",
                1,
            )[0]

            path = folder / (
                f"{safe_identifier(file_name)}.cs"
            )

            path.write_text(
                output,
                encoding="utf-8",
            )

            files += 1

    generate_dump(
        models
    )

    controller_files = (
        generate_controllers(
            documents
        )
    )

    return files, controller_files


def generate_master_openapi(
    documents,
):
    master = {
        "openapi": "3.0.3",
        "info": {
            "title": "Roblox API Master",
            "version": "2021.01.08",
            "description": (
                "Merged OpenAPI documentation "
                "collected from Roblox API services."
            ),
        },
        "servers": [],
        "paths": {},
        "components": {
            "schemas": {},
            "securitySchemes": {},
        },
    }

    services = []

    for doc in documents:
        metadata = get_document_metadata(
            doc
        )

        source_url = metadata.get(
            "sourceUrl",
            metadata.get("url"),
        )

        services.append({
            "host": metadata.get(
                "host"
            ),
            "version": metadata.get(
                "version"
            ),
            "snapshot": metadata.get(
                "snapshot"
            ),
            "url": source_url,
            "title": doc.get(
                "info",
                {},
            ).get(
                "title"
            ),
            "description": doc.get(
                "info",
                {},
            ).get(
                "description"
            ),
            "pathCount": len(
                doc.get(
                    "paths",
                    {},
                )
            ),
            "definitionCount": len(
                doc.get(
                    "definitions",
                    {},
                )
            ),
        })

    services.sort(
        key=lambda item: (
            item.get("host") or "",
            str(
                item.get("version")
                or ""
            ),
        )
    )

    master[
        "x-roblox-services"
    ] = services

    merge_definitions(
        documents,
        master,
    )

    merge_paths(
        documents,
        master,
    )

    merge_top_level(
        documents,
        master,
    )

    add_server_metadata(
        documents,
        master,
    )

    operation_count = 0

    for path_item in master[
        "paths"
    ].values():
        for method in HTTP_METHODS:
            if method in path_item:
                operation_count += 1

    master[
        "x-roblox-stats"
    ] = {
        "documents": len(
            documents
        ),
        "hosts": len(
            master.get(
                "x-roblox-hosts",
                [],
            )
        ),
        "versions": len(
            master.get(
                "x-roblox-versions",
                [],
            )
        ),
        "paths": len(
            master["paths"]
        ),
        "operations": operation_count,
        "definitions": len(
            master[
                "components"
            ]["schemas"]
        ),
        "tags": len(
            master.get(
                "tags",
                [],
            )
        ),
    }

    return master


def write_master_openapi(
    documents,
):
    master = generate_master_openapi(
        documents
    )

    MASTER_FILE.write_text(
        json.dumps(
            master,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    return master


def main():
    raw = Path(
        INPUT_FILE
    ).read_text(
        encoding="utf-8-sig"
    )

    documents = parse_multiple_json(
        raw
    )

    models = collect_models(
        documents
    )

    files, controller_files = generate(
        models,
        documents,
    )

    master = write_master_openapi(
        documents
    )

    print(
        f"parsed {len(documents)} swagger documents"
    )

    print(
        f"generated {files} classes"
    )

    print(
        f"generated {controller_files} controllers"
    )

    print(
        f"master hosts: "
        f"{master['x-roblox-stats']['hosts']}"
    )

    print(
        f"master versions: "
        f"{master['x-roblox-stats']['versions']}"
    )

    print(
        f"master paths: "
        f"{master['x-roblox-stats']['paths']}"
    )

    print(
        f"master operations: "
        f"{master['x-roblox-stats']['operations']}"
    )

    print(
        f"master definitions: "
        f"{master['x-roblox-stats']['definitions']}"
    )

    print(
        f"dump: "
        f"{(OUTPUT_DIR / 'dump.txt').resolve()}"
    )

    print(
        f"controllers: "
        f"{(OUTPUT_DIR / 'controllers').resolve()}"
    )

    print(
        f"master: "
        f"{MASTER_FILE.resolve()}"
    )

    print(
        f"output: "
        f"{OUTPUT_DIR.resolve()}"
    )


if __name__ == "__main__":
    main()