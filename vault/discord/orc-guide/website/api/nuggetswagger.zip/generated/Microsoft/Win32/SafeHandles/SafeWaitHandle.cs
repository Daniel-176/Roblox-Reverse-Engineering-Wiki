using System;
using System.Collections.Generic;

namespace Microsoft.Win32.SafeHandles;

public class SafeWaitHandle
{
    public bool IsInvalid { get; set; }
    public bool IsClosed { get; set; }
}
