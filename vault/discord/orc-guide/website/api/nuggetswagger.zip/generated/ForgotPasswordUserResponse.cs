using System;
using System.Collections.Generic;

namespace (global);

public class ForgotPasswordUserResponse
{
    public UserResponse user { get; set; }
    public string? ticket { get; set; }
}
