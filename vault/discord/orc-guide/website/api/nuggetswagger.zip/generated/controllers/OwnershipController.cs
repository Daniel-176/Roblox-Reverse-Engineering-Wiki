using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OwnershipController : ControllerBase
{
    [HttpGet("ownership/hasasset")]
    public ActionResult<object> Ownership_HasAsset([FromQuery] long userId, [FromQuery] long assetId)
    {
        return StatusCode(501);
    }

}
