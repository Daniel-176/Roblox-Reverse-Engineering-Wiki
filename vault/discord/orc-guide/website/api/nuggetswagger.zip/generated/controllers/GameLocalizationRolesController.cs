using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GameLocalizationRolesController : ControllerBase
{
    [HttpPatch("v1/game-localization-roles/games/{gameId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1Game_localization_rolesGamesGameId([FromRoute] long gameId, [FromBody] Roblox.TranslationRoles.Api.UpdateRoleRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/game-localization-roles/games/{gameId}/current-user/roles")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[System.String]> getV1Game_localization_rolesGamesGameIdCurrent_userRoles([FromRoute] long gameId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/game-localization-roles/games/{gameId}/roles/{role}/assignees")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.TranslationRoles.Api.Assignee]> getV1Game_localization_rolesGamesGameIdRolesRoleAssignees([FromRoute] long gameId, [FromRoute] int role)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/game-localization-roles/roles/{role}/current-user")]
    public ActionResult<Roblox.TranslationRoles.Api.GetGameLocalizationRoleAssignmentsForUserResponse> getV1Game_localization_rolesRolesRoleCurrent_user([FromRoute] int role, [FromQuery] string? exclusiveStartKey, [FromQuery] int pageSize)
    {
        return StatusCode(501);
    }

}
