using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    [HttpGet("v1/user/groups/canmanage")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Api.Develop.Models.GroupModel]> getV1UserGroupsCanmanage()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/user/notifications/statistic-reports")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.DevMetrics.Models.INotification]> getV1UserNotificationsStatistic_reports()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/user/studiodata")]
    public ActionResult<object> getV1UserStudiodata([FromQuery] string? clientKey)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/user/studiodata")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> postV1UserStudiodata([FromQuery] string? clientKey, [FromBody] object data)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/user/universes")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Api.Develop.Models.UniverseModel]> getV1UserUniverses([FromQuery] bool isArchived, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

}
