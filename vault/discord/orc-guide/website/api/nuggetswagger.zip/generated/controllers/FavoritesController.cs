using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FavoritesController : ControllerBase
{
    [HttpGet("v1/favorites/assets/{assetId}/count")]
    public ActionResult<long> getV1FavoritesAssetsAssetIdCount([FromRoute] long assetId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/favorites/bundles/{bundleId}/count")]
    public ActionResult<long> getV1FavoritesBundlesBundleIdCount([FromRoute] long bundleId)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/favorites/users/{userId}/assets/{assetId}/favorite")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1FavoritesUsersUserIdAssetsAssetIdFavorite([FromRoute] long userId, [FromRoute] long assetId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/favorites/users/{userId}/assets/{assetId}/favorite")]
    public ActionResult<Roblox.Catalog.Api.AssetFavoriteModel> getV1FavoritesUsersUserIdAssetsAssetIdFavorite([FromRoute] long userId, [FromRoute] long assetId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/favorites/users/{userId}/assets/{assetId}/favorite")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1FavoritesUsersUserIdAssetsAssetIdFavorite([FromRoute] long userId, [FromRoute] long assetId)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/favorites/users/{userId}/bundles/{bundleId}/favorite")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1FavoritesUsersUserIdBundlesBundleIdFavorite([FromRoute] long userId, [FromRoute] long bundleId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/favorites/users/{userId}/bundles/{bundleId}/favorite")]
    public ActionResult<Roblox.Catalog.Api.BundleFavoriteModel> getV1FavoritesUsersUserIdBundlesBundleIdFavorite([FromRoute] long userId, [FromRoute] long bundleId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/favorites/users/{userId}/bundles/{bundleId}/favorite")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1FavoritesUsersUserIdBundlesBundleIdFavorite([FromRoute] long userId, [FromRoute] long bundleId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/{universeId}/favorites")]
    public ActionResult<Roblox.Games.Api.Models.Response.GameFavoriteResponse> getV1GamesUniverseIdFavorites([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/games/{universeId}/favorites")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GamesUniverseIdFavorites([FromRoute] long universeId, [FromBody] Roblox.Games.Api.Models.Request.GameFavoritesRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/{universeId}/favorites/count")]
    public ActionResult<Roblox.Games.Api.Models.Response.GameFavoritesCountResponse> getV1GamesUniverseIdFavoritesCount([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

}
