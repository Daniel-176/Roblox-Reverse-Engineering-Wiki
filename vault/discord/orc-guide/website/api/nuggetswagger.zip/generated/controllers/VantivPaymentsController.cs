using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class VantivPaymentsController : ControllerBase
{
    [HttpPost("v1/payments/vantiv/checkout")]
    public ActionResult<Roblox.Api.Billing.Models.Response.VantivPaymentResponse> postV1PaymentsVantivCheckout([FromBody] Roblox.Api.Billing.Models.Requests.VantivPaymentRequest vantivPaymentRequest)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/payments/vantiv/metadata")]
    public ActionResult<Roblox.Api.Billing.Models.Response.VantivPaymentMetadataResponse> getV1PaymentsVantivMetadata([FromQuery] int vantivPaymentMetadataRequest_productId, [FromQuery] string? vantivPaymentMetadataRequest_paymentMethod, [FromQuery] int vantivPaymentMetadataRequest_selectedUpsellProductId)
    {
        return StatusCode(501);
    }

}
