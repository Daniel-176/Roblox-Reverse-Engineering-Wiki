using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class LocaleController : ControllerBase
{
    [HttpGet("v1/locales")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Locale.Api.SupportedLocaleLocus]> getV1Locales([FromQuery] string? displayValueLocale)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/locales/set-user-supported-locale")]
    public ActionResult<Roblox.Locale.Api.SuccessResponse> postV1LocalesSet_user_supported_locale([FromBody] Roblox.Locale.Api.SetSupportedLocaleForUserRequest userRequest)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/locales/supported-locales")]
    public ActionResult<Roblox.Locale.Api.SupportedLocalesResponse> getV1LocalesSupported_locales()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/locales/user-locale")]
    public ActionResult<Roblox.Locale.Api.UserLocaleResponse> getV1LocalesUser_locale()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/locales/user-localization-locus-supported-locales")]
    public ActionResult<Roblox.Locale.Api.UserLocalizationLocusLocalesResponse> getV1LocalesUser_localization_locus_supported_locales()
    {
        return StatusCode(501);
    }

}
