using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TransactionRecordsController : ControllerBase
{
    [HttpGet("v2/users/transaction-totals")]
    public ActionResult<Roblox.Economy.Api.Models.TransactionTotalsResponse> getV2UsersTransaction_totals([FromQuery] string timeFrame, [FromQuery] int batchCount, [FromQuery] string transactionType)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/users/transactions")]
    public ActionResult<Roblox.Economy.Api.Models.TransactionRecordCollectionResponse> getV2UsersTransactions([FromQuery] long exclusiveStartId, [FromQuery] long salesStartIndex, [FromQuery] long purchasesStartIndex, [FromQuery] int affiliateStartIndex, [FromQuery] int developerExchangeStartIndex, [FromQuery] long holdExclusiveStartId, [FromQuery] string transactionType, [FromQuery] int batchCount)
    {
        return StatusCode(501);
    }

}
