using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AssetFetchController : ControllerBase
{
    [HttpGet("v1/alias/{alias}")]
    public ActionResult<Roblox.Platform.Assets.IAssetResponseItem> getV1AliasAlias([FromRoute] string alias, [FromHeader] string Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string AssetType, [FromHeader] string Accept, [FromHeader] string AssetFormat, [FromHeader] string Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/asset")]
    public ActionResult<System.Web.Http.Results.RedirectResult> getV1Asset([FromHeader] string Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string AssetType, [FromHeader] string Accept, [FromHeader] string AssetFormat, [FromHeader] string Roblox_AssetFormat, [FromQuery] long id, [FromQuery] long userAssetId, [FromQuery] long assetVersionId, [FromQuery] int version, [FromQuery] long universeId, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] string? serverplaceid, [FromQuery] string? assetName, [FromQuery] string? hash, [FromQuery] string? marAssetHash, [FromQuery] string? marCheckSum, [FromQuery] string? expectedAssetType, [FromQuery] bool skipSigningScripts)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/assetHash/{hash}")]
    public ActionResult<Roblox.Platform.Assets.IAssetResponseItem> getV1AssetHashHash([FromRoute] string hash, [FromHeader] string Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string AssetType, [FromHeader] string Accept, [FromHeader] string AssetFormat, [FromHeader] string Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/assetId/{assetId}")]
    public ActionResult<Roblox.Platform.Assets.IAssetResponseItem> getV1AssetIdAssetId([FromRoute] long assetId, [FromHeader] string Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string AssetType, [FromHeader] string Accept, [FromHeader] string AssetFormat, [FromHeader] string Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/assetId/{assetId}/version/{version}")]
    public ActionResult<Roblox.Platform.Assets.IAssetResponseItem> getV1AssetIdAssetIdVersionVersion([FromRoute] long assetId, [FromRoute] int version, [FromHeader] string Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string AssetType, [FromHeader] string Accept, [FromHeader] string AssetFormat, [FromHeader] string Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/assetVersionId/{assetVersionId}")]
    public ActionResult<Roblox.Platform.Assets.IAssetResponseItem> getV1AssetVersionIdAssetVersionId([FromRoute] long assetVersionId, [FromHeader] string Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string AssetType, [FromHeader] string Accept, [FromHeader] string AssetFormat, [FromHeader] string Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/marAssetHash/{marAssetHash}/marCheckSum/{marCheckSum}")]
    public ActionResult<Roblox.Platform.Assets.IAssetResponseItem> getV1MarAssetHashMarAssetHashMarCheckSumMarCheckSum([FromRoute] string marAssetHash, [FromRoute] string marCheckSum, [FromHeader] string Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string AssetType, [FromHeader] string Accept, [FromHeader] string AssetFormat, [FromHeader] string Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/userAssetId/{userAssetId}")]
    public ActionResult<Roblox.Platform.Assets.IAssetResponseItem> getV1UserAssetIdUserAssetId([FromRoute] long userAssetId, [FromHeader] string Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string AssetType, [FromHeader] string Accept, [FromHeader] string AssetFormat, [FromHeader] string Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

}
