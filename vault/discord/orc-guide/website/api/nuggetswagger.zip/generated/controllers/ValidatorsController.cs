using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ValidatorsController : ControllerBase
{
    [HttpGet("v1/validators/email")]
    public ActionResult<Roblox.Authentication.Api.Models.EmailValidationResponse> getV1ValidatorsEmail([FromQuery] string? requestBody_email)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/validators/username")]
    public ActionResult<Roblox.Authentication.Api.Models.RecommendedUsernameResponse> getV1ValidatorsUsername([FromQuery] string? requestBody_username, [FromQuery] string? requestBody_birthday)
    {
        return StatusCode(501);
    }

}
