using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GameJoinController : ControllerBase
{
    [HttpPost("v1/join-game")]
    public ActionResult<Roblox.GameJoin.Api.GameJoinResponse> postV1Join_game([FromBody] Roblox.GameJoin.Api.GameJoinRequest gameJoinRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/join-game-instance")]
    public ActionResult<Roblox.GameJoin.Api.GameJoinResponse> postV1Join_game_instance([FromBody] Roblox.GameJoin.Api.JoinGameInstanceRequest joinGameInstanceRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/join-play-together-game")]
    public ActionResult<Roblox.GameJoin.Api.GameJoinResponse> postV1Join_play_together_game([FromBody] Roblox.GameJoin.Api.JoinPlayTogetherGameRequest joinPlayTogetherGameRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/join-private-game")]
    public ActionResult<Roblox.GameJoin.Api.GameJoinResponse> postV1Join_private_game([FromBody] Roblox.GameJoin.Api.JoinPrivateGameRequest joinPrivateGameRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/join-reserved-game")]
    public ActionResult<Roblox.GameJoin.Api.GameJoinResponse> postV1Join_reserved_game([FromBody] Roblox.GameJoin.Api.JoinReservedGameRequest joinReservedGameRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/play-with-party")]
    public ActionResult<Roblox.GameJoin.Api.GameJoinResponse> postV1Play_with_party([FromBody] Roblox.GameJoin.Api.PlayWithPartyRequest playWithPartyRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/play-with-user")]
    public ActionResult<Roblox.GameJoin.Api.GameJoinResponse> postV1Play_with_user([FromBody] Roblox.GameJoin.Api.PlayWithUserRequest playWithUserRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/team-create")]
    public ActionResult<Roblox.GameJoin.Api.TeamCreateResponse> postV1Team_create([FromBody] Roblox.GameJoin.Api.TeamCreateRequest teamCreateRequest)
    {
        return StatusCode(501);
    }

}
