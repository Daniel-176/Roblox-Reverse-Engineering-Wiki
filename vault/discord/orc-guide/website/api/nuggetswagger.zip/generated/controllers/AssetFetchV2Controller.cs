using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AssetFetchV2Controller : ControllerBase
{
    [HttpGet("v2/alias/{alias}")]
    public ActionResult<Roblox.Web.Assets.IAssetResponseItemV2> getV2AliasAlias([FromRoute] string alias, [FromHeader] string? Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string? AssetType, [FromHeader] string? Accept, [FromHeader] string? AssetFormat, [FromHeader] string? Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/asset")]
    public ActionResult<Roblox.Web.Assets.IAssetResponseItemV2> getV2Asset([FromHeader] string? Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string? AssetType, [FromHeader] string? Accept, [FromHeader] string? AssetFormat, [FromHeader] string? Roblox_AssetFormat, [FromQuery] long id, [FromQuery] long userAssetId, [FromQuery] long assetVersionId, [FromQuery] int version, [FromQuery] long universeId, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] string? serverplaceid, [FromQuery] string? assetName, [FromQuery] string? hash, [FromQuery] string? marAssetHash, [FromQuery] string? marCheckSum, [FromQuery] string? expectedAssetType, [FromQuery] bool skipSigningScripts, [FromQuery] string? permissionContext)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/assetHash/{hash}")]
    public ActionResult<Roblox.Web.Assets.IAssetResponseItemV2> getV2AssetHashHash([FromRoute] string hash, [FromHeader] string? Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string? AssetType, [FromHeader] string? Accept, [FromHeader] string? AssetFormat, [FromHeader] string? Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/assetId/{assetId}")]
    public ActionResult<Roblox.Web.Assets.IAssetResponseItemV2> getV2AssetIdAssetId([FromRoute] long assetId, [FromHeader] string? Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string? AssetType, [FromHeader] string? Accept, [FromHeader] string? AssetFormat, [FromHeader] string? Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/assetId/{assetId}/version/{version}")]
    public ActionResult<Roblox.Web.Assets.IAssetResponseItemV2> getV2AssetIdAssetIdVersionVersion([FromRoute] long assetId, [FromRoute] int version, [FromHeader] string? Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string? AssetType, [FromHeader] string? Accept, [FromHeader] string? AssetFormat, [FromHeader] string? Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/assetVersionId/{assetVersionId}")]
    public ActionResult<Roblox.Web.Assets.IAssetResponseItemV2> getV2AssetVersionIdAssetVersionId([FromRoute] long assetVersionId, [FromHeader] string? Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string? AssetType, [FromHeader] string? Accept, [FromHeader] string? AssetFormat, [FromHeader] string? Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/marAssetHash/{marAssetHash}/marCheckSum/{marCheckSum}")]
    public ActionResult<Roblox.Web.Assets.IAssetResponseItem> getV2MarAssetHashMarAssetHashMarCheckSumMarCheckSum([FromRoute] string marAssetHash, [FromRoute] string marCheckSum, [FromHeader] string? Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string? AssetType, [FromHeader] string? Accept, [FromHeader] string? AssetFormat, [FromHeader] string? Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/userAssetId/{userAssetId}")]
    public ActionResult<Roblox.Web.Assets.IAssetResponseItemV2> getV2UserAssetIdUserAssetId([FromRoute] long userAssetId, [FromHeader] string? Accept_Encoding, [FromHeader] long Roblox_Place_Id, [FromHeader] string? AssetType, [FromHeader] string? Accept, [FromHeader] string? AssetFormat, [FromHeader] string? Roblox_AssetFormat, [FromQuery] bool skipSigningScripts, [FromQuery] int clientInsert, [FromQuery] int scriptinsert, [FromQuery] long modulePlaceId, [FromQuery] long serverplaceid, [FromQuery] string? expectedAssetType)
    {
        return StatusCode(501);
    }

}
