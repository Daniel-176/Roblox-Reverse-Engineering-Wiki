using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PhoneInformationController : ControllerBase
{
    [HttpGet("v1/phone")]
    public ActionResult<Roblox.AccountInformation.Api.Models.PhoneResponse> getV1Phone()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/phone")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Phone([FromBody] Roblox.AccountInformation.Api.Models.PhoneRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/phone/delete")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1PhoneDelete([FromBody] Roblox.AccountInformation.Api.Models.PhoneRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/phone/resend")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1PhoneResend([FromBody] Roblox.AccountInformation.Api.Models.PhoneRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/phone/verify")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1PhoneVerify([FromBody] Roblox.AccountInformation.Api.Models.VerifyPhoneRequest request)
    {
        return StatusCode(501);
    }

}
