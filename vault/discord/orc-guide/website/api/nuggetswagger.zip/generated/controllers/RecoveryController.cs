using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RecoveryController : ControllerBase
{
    [HttpGet("v1/recovery/metadata")]
    public ActionResult<Roblox.Authentication.Api.Models.RecoveryMetadataResponse> getV1RecoveryMetadata()
    {
        return StatusCode(501);
    }

}
