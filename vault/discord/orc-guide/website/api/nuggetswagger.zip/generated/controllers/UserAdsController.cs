using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserAdsController : ControllerBase
{
    [HttpPost("v1/user-ads/assets/create")]
    public IActionResult postV1User_adsAssetsCreate([FromQuery] long assetId, [FromForm] string? request_name, [FromForm] object? request_files)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/user-ads/game-passes/create")]
    public IActionResult postV1User_adsGame_passesCreate([FromQuery] long gamePassId, [FromForm] string? request_name, [FromForm] object? request_files)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/user-ads/groups/create")]
    public IActionResult postV1User_adsGroupsCreate([FromQuery] long groupId, [FromForm] string? request_name, [FromForm] object? request_files)
    {
        return StatusCode(501);
    }

}
