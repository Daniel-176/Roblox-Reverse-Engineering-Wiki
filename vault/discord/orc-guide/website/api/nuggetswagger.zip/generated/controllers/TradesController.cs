using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TradesController : ControllerBase
{
    [HttpGet("v1/trades/metadata")]
    public ActionResult<Roblox.Trades.Api.TradeMetadata> getV1TradesMetadata()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/trades/send")]
    public ActionResult<Roblox.Trades.Api.NewTradeResponse> postV1TradesSend([FromBody] Roblox.Trades.Api.TradeRequest tradeRequest)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/trades/{tradeId}")]
    public ActionResult<Roblox.Trades.Api.TradeDetailResponse> getV1TradesTradeId([FromRoute] long tradeId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/trades/{tradeId}/accept")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1TradesTradeIdAccept([FromRoute] long tradeId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/trades/{tradeId}/counter")]
    public ActionResult<Roblox.Trades.Api.NewTradeResponse> postV1TradesTradeIdCounter([FromRoute] long tradeId, [FromBody] Roblox.Trades.Api.TradeRequest tradeRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/trades/{tradeId}/decline")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1TradesTradeIdDecline([FromRoute] long tradeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/trades/{tradeStatusType}")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Trades.Api.TradeResponse]> getV1TradesTradeStatusType([FromRoute] string tradeStatusType, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/trades/{tradeStatusType}/count")]
    public ActionResult<Roblox.Trades.Api.TradeCountResponse> getV1TradesTradeStatusTypeCount([FromRoute] string tradeStatusType)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/can-trade-with")]
    public ActionResult<Roblox.Trades.Api.CanTradeResponse> getV1UsersUserIdCan_trade_with([FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
