using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class NotificationsController : ControllerBase
{
    [HttpPost("v1/notifications/xsolla")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1NotificationsXsolla([FromBody] Roblox.Api.Billing.Models.XsollaNotificationRequest xsollaNotificationModel)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/notifications/get-rollout-settings")]
    public ActionResult<Roblox.Api.Notifications.Models.NotificationRolloutSettingsModel> getV2NotificationsGet_rollout_settings([FromQuery] string[] featureNames)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/notifications/get-settings")]
    public ActionResult<Roblox.Api.Notifications.Models.UserNotificationSettingsModel> getV2NotificationsGet_settings()
    {
        return StatusCode(501);
    }

    [HttpPost("v2/notifications/notification-source-types/allow")]
    public ActionResult<object> postV2NotificationsNotification_source_typesAllow([FromBody] Roblox.Api.Notifications.Models.NotificationSourceTypeModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/notifications/notification-source-types/opt-out")]
    public ActionResult<object> postV2NotificationsNotification_source_typesOpt_out([FromBody] Roblox.Api.Notifications.Models.NotificationSourceTypeModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/notifications/receiver-destination-types/allow")]
    public ActionResult<object> postV2NotificationsReceiver_destination_typesAllow([FromBody] Roblox.Api.Notifications.Models.ReceiverDestinationTypeModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/notifications/receiver-destination-types/opt-out")]
    public ActionResult<object> postV2NotificationsReceiver_destination_typesOpt_out([FromBody] Roblox.Api.Notifications.Models.ReceiverDestinationTypeModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/notifications/settings/realtime")]
    public ActionResult<Roblox.Api.Notifications.RealTimeNotificationsSettingsResponseModel> getV2NotificationsSettingsRealtime()
    {
        return StatusCode(501);
    }

    [HttpPost("v2/notifications/update-destination-setting")]
    public ActionResult<object> postV2NotificationsUpdate_destination_setting([FromBody] Roblox.Api.Notifications.Models.ReceiverDestinationPreferenceModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/notifications/update-notification-settings")]
    public ActionResult<object> postV2NotificationsUpdate_notification_settings([FromBody] Roblox.Api.Notifications.Models.NotificationBandSettingsModel requestModel)
    {
        return StatusCode(501);
    }

}
