using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SignupController : ControllerBase
{
    [HttpPost("v1/signup")]
    public ActionResult<Roblox.Authentication.Api.Models.SignupResponse> postV1Signup([FromBody] Roblox.Authentication.Api.Models.SignupRequest request)
    {
        return StatusCode(501);
    }

}
