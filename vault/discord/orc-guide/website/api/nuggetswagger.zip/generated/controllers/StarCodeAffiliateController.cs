using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class StarCodeAffiliateController : ControllerBase
{
    [HttpDelete("v1/star-code-affiliates")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1Star_code_affiliates()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/star-code-affiliates")]
    public ActionResult<Roblox.AccountInformation.Api.Models.StarCodeAffiliateResponse> getV1Star_code_affiliates()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/star-code-affiliates")]
    public ActionResult<Roblox.AccountInformation.Api.Models.StarCodeAffiliateResponse> postV1Star_code_affiliates([FromBody] Roblox.AccountInformation.Api.Models.StarCodeAffiliateRequest request)
    {
        return StatusCode(501);
    }

}
