using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AutoLocalizationTableController : ControllerBase
{
    [HttpPost("v1/auto-localization-table/games/{gameId}/assets-generation-request")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Auto_localization_tableGamesGameIdAssets_generation_request([FromRoute] long gameId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/auto-localization-table/games/{gameId}/auto-scrape-cleanup-request")]
    public ActionResult<object> postV1Auto_localization_tableGamesGameIdAuto_scrape_cleanup_request([FromRoute] long gameId, [FromBody] Roblox.LocalizationTables.Api.RaiseEventForAutoScrapedEntriesCleanupRequest request)
    {
        return StatusCode(501);
    }

}
