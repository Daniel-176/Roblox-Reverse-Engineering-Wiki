using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ConfigurationController : ControllerBase
{
    [HttpGet("v1/users/{userId}/configuration")]
    public ActionResult<Roblox.TwoStepVerification.Api.UserConfiguration> getV1UsersUserIdConfiguration([FromRoute] long userId, [FromQuery] string? challengeId, [FromQuery] string? actionType)
    {
        return StatusCode(501);
    }

}
