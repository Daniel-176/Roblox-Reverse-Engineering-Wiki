using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class Toolbox2014Controller : ControllerBase
{
    [HttpGet("v1/toolbox/items")]
    public ActionResult<Roblox.Api.Develop.Models.Response.ToolboxItemsResponse> getV1ToolboxItems([FromQuery] string category, [FromQuery] string? keyword, [FromQuery] string? sort, [FromQuery] long creatorId, [FromQuery] int num, [FromQuery] int page, [FromQuery] long groupId, [FromQuery] int creatorType, [FromQuery] string? cacheMode)
    {
        return StatusCode(501);
    }

}
