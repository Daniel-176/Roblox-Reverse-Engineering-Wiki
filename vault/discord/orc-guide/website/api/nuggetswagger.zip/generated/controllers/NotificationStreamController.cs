using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class NotificationStreamController : ControllerBase
{
    [HttpPost("v2/stream-notifications/clear-unread")]
    public ActionResult<Roblox.Api.Notifications.Models.SuccessResponseModel> postV2Stream_notificationsClear_unread()
    {
        return StatusCode(501);
    }

    [HttpPost("v2/stream-notifications/game-update-notification-interacted")]
    public ActionResult<Roblox.Api.Notifications.Models.SuccessResponseModel> postV2Stream_notificationsGame_update_notification_interacted([FromBody] Roblox.Api.Notifications.Models.GameUpdateNotificationInteractedRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/stream-notifications/game-update-notification-read")]
    public ActionResult<Roblox.Api.Notifications.Models.SuccessResponseModel> postV2Stream_notificationsGame_update_notification_read([FromBody] Roblox.Api.Notifications.Models.GameUpdateNotificationReadRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/stream-notifications/get-latest-game-updates")]
    public ActionResult<Roblox.Api.Notifications.Models.GameUpdateNotificationModel[]> getV2Stream_notificationsGet_latest_game_updates([FromQuery] long[] universeIds, [FromQuery] string? sinceDateTime)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/stream-notifications/get-prompt-settings")]
    public ActionResult<Roblox.Api.Notifications.Models.NotificationStreamPromptSettingsModel> getV2Stream_notificationsGet_prompt_settings()
    {
        return StatusCode(501);
    }

    [HttpGet("v2/stream-notifications/get-recent")]
    public ActionResult<Roblox.Api.Notifications.Models.NotificationStreamEntriesModel[]> getV2Stream_notificationsGet_recent([FromQuery] int startIndex, [FromQuery] int maxRows)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/stream-notifications/mark-interacted")]
    public ActionResult<Roblox.Api.Notifications.Models.SuccessResponseModel> postV2Stream_notificationsMark_interacted([FromBody] Roblox.Api.Notifications.Models.MarkInteractedRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/stream-notifications/metadata")]
    public ActionResult<Roblox.Api.Notifications.Models.ResponseModels.NotificationStreamMetadataResponse> getV2Stream_notificationsMetadata()
    {
        return StatusCode(501);
    }

    [HttpPost("v2/stream-notifications/suppress-prompt")]
    public ActionResult<Roblox.Api.Notifications.Models.SuccessResponseModel> postV2Stream_notificationsSuppress_prompt()
    {
        return StatusCode(501);
    }

    [HttpGet("v2/stream-notifications/unread-count")]
    public ActionResult<Roblox.Api.Notifications.Models.UnreadStreamNotificationsModel> getV2Stream_notificationsUnread_count()
    {
        return StatusCode(501);
    }

}
