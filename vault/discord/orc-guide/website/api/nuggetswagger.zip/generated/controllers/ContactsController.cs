using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ContactsController : ControllerBase
{
    [HttpGet("v1/contacts/metadata")]
    public ActionResult<Roblox.Contacts.Api.Models.Response.ContactsMetadataResponseModel> getV1ContactsMetadata()
    {
        return StatusCode(501);
    }

}
