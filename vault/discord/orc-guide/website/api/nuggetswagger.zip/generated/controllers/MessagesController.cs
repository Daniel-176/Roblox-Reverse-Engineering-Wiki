using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MessagesController : ControllerBase
{
    [HttpGet("v1/messages")]
    public ActionResult<Roblox.PrivateMessages.Api.Models.GetMessagesResponse> getV1Messages([FromQuery] int pageNumber, [FromQuery] int pageSize, [FromQuery] string? messageTab)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/messages/archive")]
    public ActionResult<Roblox.PrivateMessages.Api.Models.BatchMessagesResponse> postV1MessagesArchive([FromBody] Roblox.PrivateMessages.Api.Models.BatchMessagesRequest batchMessagesRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/messages/mark-read")]
    public ActionResult<Roblox.PrivateMessages.Api.Models.BatchMessagesResponse> postV1MessagesMark_read([FromBody] Roblox.PrivateMessages.Api.Models.BatchMessagesRequest batchMessagesRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/messages/mark-unread")]
    public ActionResult<Roblox.PrivateMessages.Api.Models.BatchMessagesResponse> postV1MessagesMark_unread([FromBody] Roblox.PrivateMessages.Api.Models.BatchMessagesRequest batchMessagesRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/messages/send")]
    public ActionResult<Roblox.PrivateMessages.Api.Models.SendMessageResponse> postV1MessagesSend([FromBody] Roblox.PrivateMessages.Api.Models.SendMessageRequest sendMessageRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/messages/unarchive")]
    public ActionResult<Roblox.PrivateMessages.Api.Models.BatchMessagesResponse> postV1MessagesUnarchive([FromBody] Roblox.PrivateMessages.Api.Models.BatchMessagesRequest batchMessagesRequest)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/messages/unread/count")]
    public ActionResult<Roblox.PrivateMessages.Api.Models.UnreadMessagesCountResponse> getV1MessagesUnreadCount()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/messages/{messageId}")]
    public ActionResult<Roblox.PrivateMessages.Api.Models.MessageDetailsResponse> getV1MessagesMessageId([FromRoute] long messageId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/messages/{userId}/can-message")]
    public ActionResult<Roblox.PrivateMessages.Api.Models.Messages.Response.CanMessageResponse> getV1MessagesUserIdCan_message([FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
