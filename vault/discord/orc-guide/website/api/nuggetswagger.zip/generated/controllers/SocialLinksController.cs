using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SocialLinksController : ControllerBase
{
    [HttpGet("v1/groups/{groupId}/social-links")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Groups.Api.SocialLinkResponse]> getV1GroupsGroupIdSocial_links([FromRoute] long groupId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/{groupId}/social-links")]
    public ActionResult<Roblox.Groups.Api.SocialLinkResponse> postV1GroupsGroupIdSocial_links([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.SocialLinkRequest request)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/groups/{groupId}/social-links/{socialLinkId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1GroupsGroupIdSocial_linksSocialLinkId([FromRoute] long groupId, [FromRoute] long socialLinkId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/groups/{groupId}/social-links/{socialLinkId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1GroupsGroupIdSocial_linksSocialLinkId([FromRoute] long groupId, [FromRoute] long socialLinkId, [FromBody] Roblox.Groups.Api.SocialLinkRequest request)
    {
        return StatusCode(501);
    }

}
