using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class LuobuDeveloperExchangeController : ControllerBase
{
    [HttpGet("v1/luobu-developer-exchange/balance")]
    public ActionResult<Roblox.Api.Billing.Models.Response.GetLuobuDevexBalanceResponse> getV1Luobu_developer_exchangeBalance()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/luobu-developer-exchange/eligibility")]
    public ActionResult<Roblox.Api.Billing.Models.Response.GetLuobuDevexEligibilityResponse> getV1Luobu_developer_exchangeEligibility()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/luobu-developer-exchange/latest-request-status")]
    public ActionResult<Roblox.Api.Billing.Models.Response.GetLuobuLatestRequestStatusResponse> getV1Luobu_developer_exchangeLatest_request_status()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/luobu-developer-exchange/request")]
    public ActionResult<Roblox.Api.Billing.Models.Response.SubmitLuobuDevexResponse> postV1Luobu_developer_exchangeRequest([FromBody] Roblox.Api.Billing.Models.Requests.SubmitLuobuDevexRequest request)
    {
        return StatusCode(501);
    }

}
