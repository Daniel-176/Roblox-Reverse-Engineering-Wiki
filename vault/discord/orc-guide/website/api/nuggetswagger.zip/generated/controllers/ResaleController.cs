using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ResaleController : ControllerBase
{
    [HttpGet("v1/assets/{assetId}/resale-data")]
    public ActionResult<Roblox.Economy.Api.ResaleDataResponse> getV1AssetsAssetIdResale_data([FromRoute] long assetId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/assets/{assetId}/resellable-copies/{userAssetId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1AssetsAssetIdResellable_copiesUserAssetId([FromRoute] long assetId, [FromRoute] long userAssetId, [FromBody] Roblox.Economy.Api.UserAssetsPatchRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/assets/{assetId}/resellers")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Economy.Api.ResaleRecordResponse]> getV1AssetsAssetIdResellers([FromRoute] long assetId, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/assets/{assetId}/users/{userId}/resellable-copies")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Economy.Api.ResaleRecordResponse]> getV1AssetsAssetIdUsersUserIdResellable_copies([FromRoute] long userId, [FromRoute] long assetId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/resale-tax-rate")]
    public ActionResult<Roblox.Economy.Api.ResaleTaxRateResponse> getV1Resale_tax_rate()
    {
        return StatusCode(501);
    }

}
