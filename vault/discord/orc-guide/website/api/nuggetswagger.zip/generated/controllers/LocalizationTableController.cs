using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class LocalizationTableController : ControllerBase
{
    [HttpGet("v1/localization-table/available-languages")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.LocalizationTables.Api.Language]> getV1Localization_tableAvailable_languages()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/localization-table/limits")]
    public ActionResult<Roblox.LocalizationTables.Api.GetLimitsResponse> getV1Localization_tableLimits()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/localization-table/metadata")]
    public ActionResult<Roblox.LocalizationTables.Api.LocalizationTablesMetadataResponse> getV1Localization_tableMetadata()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/localization-table/tables")]
    public ActionResult<Roblox.LocalizationTables.Api.CreateTableResponse> postV1Localization_tableTables([FromBody] Roblox.LocalizationTables.Api.CreateTableRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/localization-table/tables/{assetId}")]
    public ActionResult<Roblox.LocalizationTables.Api.GetTableResponse> getV1Localization_tableTablesAssetId([FromRoute] long assetId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/localization-table/tables/{tableId}")]
    public ActionResult<Roblox.LocalizationTables.Api.GetTableResponse> getV1Localization_tableTablesTableId([FromRoute] string tableId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/localization-table/tables/{tableId}")]
    public ActionResult<Roblox.LocalizationTables.Api.UpdateTableContentsResponse> patchV1Localization_tableTablesTableId([FromRoute] string tableId, [FromQuery] long gameId, [FromBody] Roblox.LocalizationTables.Api.UpdateTableContentsRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/localization-table/tables/{tableId}/entries")]
    public ActionResult<Roblox.LocalizationTables.Api.GetTableEntriesPagedResponse> getV1Localization_tableTablesTableIdEntries([FromRoute] string tableId, [FromQuery] string? cursor, [FromQuery] long gameId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/localization-table/tables/{tableId}/entries/translation-history")]
    public ActionResult<Roblox.LocalizationTables.Api.GetTableEntriesTranslationHistoryResponse> postV1Localization_tableTablesTableIdEntriesTranslation_history([FromRoute] string tableId, [FromQuery] long gameId, [FromBody] Roblox.LocalizationTables.Api.GetTableEntriesTranslationHistoryRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/localization-table/tables/{tableId}/entry-count")]
    public ActionResult<Roblox.LocalizationTables.Api.GetTableEntryCountResponse> getV1Localization_tableTablesTableIdEntry_count([FromRoute] string tableId, [FromQuery] long gameId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/localization-table/tables/{tableId}/language-translation-counts")]
    public ActionResult<Roblox.LocalizationTables.Api.GetLanguageTranslationCountsForTableResponse> getV1Localization_tableTablesTableIdLanguage_translation_counts([FromRoute] string tableId, [FromQuery] string[] locales, [FromQuery] long gameId)
    {
        return StatusCode(501);
    }

}
