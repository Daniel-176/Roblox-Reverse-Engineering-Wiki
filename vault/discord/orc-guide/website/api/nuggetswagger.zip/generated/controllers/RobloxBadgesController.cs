using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RobloxBadgesController : ControllerBase
{
    [HttpGet("v1/users/{userId}/roblox-badges")]
    public ActionResult<Roblox.AccountInformation.Api.RobloxBadgeResponse[]> getV1UsersUserIdRoblox_badges([FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
