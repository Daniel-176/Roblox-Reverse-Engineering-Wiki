using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AmazonController : ControllerBase
{
    [HttpPost("v1/amazon/purchase")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1AmazonPurchase([FromBody] Roblox.Api.Billing.Models.AmazonStorePurchaseModel amazonStorePurchaseModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/amazon/validate")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1AmazonValidate([FromBody] Roblox.Api.Billing.Models.ValidateModel validateModel)
    {
        return StatusCode(501);
    }

}
