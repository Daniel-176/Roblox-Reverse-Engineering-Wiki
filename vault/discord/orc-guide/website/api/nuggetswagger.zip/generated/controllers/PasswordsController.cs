using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PasswordsController : ControllerBase
{
    [HttpGet("v1/passwords/validate")]
    public ActionResult<Roblox.Authentication.Api.Models.PasswordValidationResponse> getV1PasswordsValidate([FromQuery] string? request_username, [FromQuery] string? request_password)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/passwords/validate")]
    public ActionResult<Roblox.Authentication.Api.Models.PasswordValidationResponse> postV1PasswordsValidate([FromBody] Roblox.Authentication.Api.Models.PasswordValidationModel request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/user/passwords/change")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UserPasswordsChange([FromBody] Roblox.Authentication.Api.Models.PasswordChangeModel request)
    {
        return StatusCode(501);
    }

}
