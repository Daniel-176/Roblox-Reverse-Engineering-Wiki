using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RolesController : ControllerBase
{
    [HttpGet("v1/roles")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Groups.Api.GroupRoleDetailResponse]> getV1Roles([FromQuery] long[] ids)
    {
        return StatusCode(501);
    }

}
