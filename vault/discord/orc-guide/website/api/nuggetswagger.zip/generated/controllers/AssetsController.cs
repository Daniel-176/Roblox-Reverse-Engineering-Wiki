using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AssetsController : ControllerBase
{
    [HttpPost("assets/award-badge")]
    public ActionResult<object> Assets_AwardBadge([FromQuery] long userId, [FromQuery] long badgeId, [FromQuery] long placeId)
    {
        return StatusCode(501);
    }

    [HttpGet("assets/{id:long}/versions")]
    public ActionResult<object> Assets_Versions([FromQuery] long id, [FromQuery] long placeId, [FromQuery] int page)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/assets")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Thumbnails.ThumbnailResponse]> getV1Assets([FromQuery] long[] assetIds, [FromQuery] string? returnPolicy, [FromQuery] string? size, [FromQuery] int format, [FromQuery] bool isCircular)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/assets-thumbnail-3d")]
    public ActionResult<Roblox.Web.Responses.Thumbnails.ThumbnailResponse> getV1Assets_thumbnail_3d([FromQuery] long assetId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/assets/voting")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Api.Develop.Models.Response.AssetVotingModel]> getV1AssetsVoting([FromQuery] long[] assetIds)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/packages/{packageID}/assets")]
    public ActionResult<Roblox.Inventory.Api.Models.AssetIdListModel> getV1PackagesPackageIDAssets([FromRoute] long packageID)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/assets/{assetId}/owners")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Inventory.Api.V2.AssetOwnerResponse]> getV2AssetsAssetIdOwners([FromRoute] long assetId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

}
