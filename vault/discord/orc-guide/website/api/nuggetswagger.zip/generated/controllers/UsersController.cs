using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    [HttpGet("users/get-by-username")]
    public ActionResult<object> Users_GetUserByUserName([FromQuery] string username)
    {
        return StatusCode(501);
    }

    [HttpGet("users/{userId:long}")]
    public ActionResult<object> Users_GetUser([FromQuery] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("users/{userId:long}/canmanage/{assetId:long}")]
    public ActionResult<object> Users_CanManage([FromQuery] long userId, [FromQuery] long assetId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/usernames/users")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Users.Api.MultiGetUserByNameResponse]> postV1UsernamesUsers([FromBody] Roblox.Users.Api.MultiGetByUsernameRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Users.SkinnyUserResponse]> postV1Users([FromBody] Roblox.Users.Api.MultiGetByUserIdRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/authenticated")]
    public ActionResult<Roblox.Web.Responses.Users.SkinnyUserResponse> getV1UsersAuthenticated()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}")]
    public ActionResult<Roblox.Web.Responses.Users.UserResponseV2> getV1UsersUserId([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/universes")]
    public ActionResult<Roblox.Followings.Api.Models.UserFollowingUniverseResponse[]> getV1UsersUserIdUniverses([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/users/{userId}/universes/{universeId}")]
    public ActionResult<Roblox.Followings.Api.Models.UserFollowingUniverseResponse> deleteV1UsersUserIdUniversesUniverseId([FromRoute] long userId, [FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{userId}/universes/{universeId}")]
    public ActionResult<Roblox.Followings.Api.Models.UserFollowingUniverseResponse> postV1UsersUserIdUniversesUniverseId([FromRoute] long userId, [FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/universes/{universeId}/status")]
    public ActionResult<Roblox.Followings.Api.Models.UserFollowingUniverseStatusResponse> getV1UsersUserIdUniversesUniverseIdStatus([FromRoute] long userId, [FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/users/{userId}/universes")]
    public ActionResult<Roblox.Followings.Api.Models.FollowsByTypeResponse> getV2UsersUserIdUniverses([FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
