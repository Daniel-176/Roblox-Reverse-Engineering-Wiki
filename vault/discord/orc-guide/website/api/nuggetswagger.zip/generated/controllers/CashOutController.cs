using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CashOutController : ControllerBase
{
    [HttpGet("v1/developer-exchange/cashoutAbility")]
    public ActionResult<Roblox.Economy.Api.Models.CashOutAbilityResponseModel> getV1Developer_exchangeCashoutAbility()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/developer-exchange/help")]
    public ActionResult<object> getV1Developer_exchangeHelp()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/developer-exchange/info")]
    public ActionResult<Roblox.Economy.Api.Controllers.V1.CashoutInfoResponseModel> getV1Developer_exchangeInfo([FromQuery] bool fromDevExPage)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/developer-exchange/submit")]
    public ActionResult<Roblox.Economy.Api.Models.SubmitResponseModel> postV1Developer_exchangeSubmit([FromBody] Roblox.Economy.Api.Models.SubmitRequestModel requestModel)
    {
        return StatusCode(501);
    }

}
