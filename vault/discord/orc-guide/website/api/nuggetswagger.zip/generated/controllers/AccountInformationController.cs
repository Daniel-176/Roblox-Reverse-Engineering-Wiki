using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AccountInformationController : ControllerBase
{
    [HttpGet("v1/birthdate")]
    public ActionResult<Roblox.AccountInformation.Api.Models.BirthdateResponse> getV1Birthdate()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/birthdate")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Birthdate([FromBody] Roblox.AccountInformation.Api.Models.BirthdateRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/description")]
    public ActionResult<Roblox.AccountInformation.Api.Models.DescriptionResponse> getV1Description()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/description")]
    public ActionResult<Roblox.AccountInformation.Api.Models.DescriptionResponse> postV1Description([FromBody] Roblox.AccountInformation.Api.Models.DescriptionRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/gender")]
    public ActionResult<Roblox.AccountInformation.Api.Models.GenderResponse> getV1Gender()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/gender")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Gender([FromBody] Roblox.AccountInformation.Api.Models.GenderRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/xbox-live/consecutive-login-days")]
    public ActionResult<Roblox.AccountInformation.Api.Models.ConsecutiveLoginDaysResponse> getV1Xbox_liveConsecutive_login_days()
    {
        return StatusCode(501);
    }

}
