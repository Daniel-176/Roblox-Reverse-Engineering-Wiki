using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AvatarController : ControllerBase
{
    [HttpGet("v1/avatar")]
    public ActionResult<Roblox.Api.Avatar.Models.AvatarModel> getV1Avatar()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/avatar-rules")]
    public ActionResult<Roblox.Api.Avatar.Models.AvatarRulesModel> getV1Avatar_rules()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/avatar/assets/{assetId}/remove")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> postV1AvatarAssetsAssetIdRemove([FromRoute] long assetId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/avatar/assets/{assetId}/wear")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> postV1AvatarAssetsAssetIdWear([FromRoute] long assetId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/avatar/metadata")]
    public ActionResult<Roblox.Api.Avatar.Models.AvatarMetadataModel> getV1AvatarMetadata()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/avatar/redraw-thumbnail")]
    public ActionResult<Roblox.Api.Avatar.Controllers.V1.AvatarController.EmptyResponse> postV1AvatarRedraw_thumbnail()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/avatar/set-body-colors")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> postV1AvatarSet_body_colors([FromBody] Roblox.Api.Avatar.Models.BodyColorsModel bodyColorsModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/avatar/set-player-avatar-type")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> postV1AvatarSet_player_avatar_type([FromBody] Roblox.Api.Avatar.Models.PlayerAvatarTypeModel playerAvatarTypeModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/avatar/set-scales")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> postV1AvatarSet_scales([FromBody] Roblox.Web.Responses.Avatar.ScaleModel scalesModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/avatar/set-wearing-assets")]
    public ActionResult<Roblox.Api.Avatar.Models.WearResponseModel> postV1AvatarSet_wearing_assets([FromBody] Roblox.Api.Avatar.Models.AssetIdListModel assetIdsModel)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/avatar")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Thumbnails.ThumbnailResponse]> getV1UsersAvatar([FromQuery] long[] userIds, [FromQuery] string? size, [FromQuery] int format, [FromQuery] bool isCircular)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/avatar-3d")]
    public ActionResult<Roblox.Web.Responses.Thumbnails.ThumbnailResponse> getV1UsersAvatar_3d([FromQuery] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/avatar-bust")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Thumbnails.ThumbnailResponse]> getV1UsersAvatar_bust([FromQuery] long[] userIds, [FromQuery] string? size, [FromQuery] int format, [FromQuery] bool isCircular)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/avatar-headshot")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Thumbnails.ThumbnailResponse]> getV1UsersAvatar_headshot([FromQuery] long[] userIds, [FromQuery] string? size, [FromQuery] int format, [FromQuery] bool isCircular)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/avatar")]
    public ActionResult<Roblox.Api.Avatar.Models.AvatarModel> getV1UsersUserIdAvatar([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/currently-wearing")]
    public ActionResult<Roblox.Api.Avatar.Models.AssetIdListModel> getV1UsersUserIdCurrently_wearing([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/outfits")]
    public ActionResult<Roblox.Api.Avatar.Models.AvatarFilteredPageResponse[Roblox.Api.Avatar.Models.OutfitModel]> getV1UsersUserIdOutfits([FromRoute] long userId, [FromQuery] int page, [FromQuery] int itemsPerPage, [FromQuery] bool isEditable)
    {
        return StatusCode(501);
    }

}
