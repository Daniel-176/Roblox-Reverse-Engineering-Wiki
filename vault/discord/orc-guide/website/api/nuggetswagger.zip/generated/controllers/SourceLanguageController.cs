using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SourceLanguageController : ControllerBase
{
    [HttpGet("v1/source-language/games/{gameId}")]
    public ActionResult<Roblox.GameInternationalization.Api.Language> getV1Source_languageGamesGameId([FromRoute] long gameId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/source-language/games/{gameId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1Source_languageGamesGameId([FromRoute] long gameId, [FromQuery] string languageCode)
    {
        return StatusCode(501);
    }

}
