using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SupportedLanguagesController : ControllerBase
{
    [HttpGet("v1/supported-languages/games/{gameId}")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.GameInternationalization.Api.LanguageOrLocale]> getV1Supported_languagesGamesGameId([FromRoute] long gameId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/supported-languages/games/{gameId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1Supported_languagesGamesGameId([FromRoute] long gameId, [FromBody] Roblox.GameInternationalization.Api.PatchLanguage[] languages)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/supported-languages/games/{gameId}/automatic-translation-status")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.GameInternationalization.Api.LanguageOrLocaleSettings]> getV1Supported_languagesGamesGameIdAutomatic_translation_status([FromRoute] long gameId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/supported-languages/games/{gameId}/languages/{languageCode}/automatic-translation-status")]
    public ActionResult<Roblox.GameInternationalization.Api.EditAutomaticTranslationStatusForGameAndLanguageResponse> patchV1Supported_languagesGamesGameIdLanguagesLanguageCodeAutomatic_translation_status([FromRoute] long gameId, [FromRoute] string languageCode, [FromBody] bool enableAutomaticTranslation)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/supported-languages/games/{gameId}/languages/{languageCode}/universe-display-info-automatic-translation-settings")]
    public ActionResult<Roblox.GameInternationalization.Api.UpdateUniverseDisplayInfoAutomaticTranslationSettingsResponse> patchV1Supported_languagesGamesGameIdLanguagesLanguageCodeUniverse_display_info_automatic_translation_settings([FromRoute] long gameId, [FromRoute] string languageCode, [FromBody] bool enableUniverseDisplayInfoAutomaticTranslation)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/supported-languages/games/{gameId}/universe-display-info-automatic-translation-settings")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.GameInternationalization.Api.UniverseDisplayInfoAutomaticTranslationSettings]> getV1Supported_languagesGamesGameIdUniverse_display_info_automatic_translation_settings([FromRoute] long gameId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/supported-languages/metadata")]
    public ActionResult<Roblox.GameInternationalization.Api.SupportedLanguagesMetadataResponse> getV1Supported_languagesMetadata()
    {
        return StatusCode(501);
    }

    [HttpGet("v2/supported-languages/games/{gameId}")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.GameInternationalization.Api.LanguageWithLocales]> getV2Supported_languagesGamesGameId([FromRoute] long gameId)
    {
        return StatusCode(501);
    }

}
