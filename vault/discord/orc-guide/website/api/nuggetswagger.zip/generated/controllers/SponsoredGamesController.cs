using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SponsoredGamesController : ControllerBase
{
    [HttpGet("v2/sponsored-games")]
    public ActionResult<Roblox.AdConfiguration.Api.GetSponsoredGamesResponse> getV2Sponsored_games([FromQuery] long universeId, [FromQuery] bool includeReportingStats, [FromQuery] bool isArchived, [FromQuery] string? pageCursor)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/sponsored-games/create")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV2Sponsored_gamesCreate([FromBody] Roblox.AdConfiguration.Api.CreateSponsoredGameV2Request request)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/sponsored-games/stop")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV2Sponsored_gamesStop([FromBody] Roblox.AdConfiguration.Api.Models.StopSponsoredGameV2Request request)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/sponsored-games/universes")]
    public ActionResult<Roblox.AdConfiguration.Api.Models.GetRecentAdsRankedUniversesResponse> getV2Sponsored_gamesUniverses([FromQuery] long groupId)
    {
        return StatusCode(501);
    }

}
