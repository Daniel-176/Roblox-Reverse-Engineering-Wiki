using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class WindowsController : ControllerBase
{
    [HttpPost("windows/v1/report-purchase")]
    public ActionResult<object> Windows_ProcessWindowsStorePurchase([FromQuery] string receipt, [FromQuery] bool isRetry, [FromBody] string[] transactionIds)
    {
        return StatusCode(501);
    }

}
