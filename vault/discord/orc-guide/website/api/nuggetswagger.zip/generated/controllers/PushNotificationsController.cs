using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PushNotificationsController : ControllerBase
{
    [HttpGet("v2/push-notifications/chrome-manifest")]
    public ActionResult<Roblox.Api.Notifications.Models.ChromeManifestModel> getV2Push_notificationsChrome_manifest()
    {
        return StatusCode(501);
    }

    [HttpPost("v2/push-notifications/deregister-all-devices")]
    public ActionResult<Roblox.Api.Notifications.Models.SuccessResponseModel> postV2Push_notificationsDeregister_all_devices()
    {
        return StatusCode(501);
    }

    [HttpPost("v2/push-notifications/deregister-current-device")]
    public ActionResult<Roblox.Api.Notifications.Models.SuccessResponseModel> postV2Push_notificationsDeregister_current_device()
    {
        return StatusCode(501);
    }

    [HttpGet("v2/push-notifications/get-current-device-destination")]
    public ActionResult<Roblox.Api.Notifications.Models.GetCurrentPushDestinationResponseModel> getV2Push_notificationsGet_current_device_destination()
    {
        return StatusCode(501);
    }

    [HttpGet("v2/push-notifications/get-destinations")]
    public ActionResult<Roblox.Api.Notifications.Models.GetPushDestinationsResponseModel> getV2Push_notificationsGet_destinations()
    {
        return StatusCode(501);
    }

    [HttpPost("v2/push-notifications/mark-as-read")]
    public ActionResult<Roblox.Api.Notifications.Models.SuccessResponseModel> postV2Push_notificationsMark_as_read([FromBody] Roblox.Api.Notifications.Models.MarkAsReadRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/push-notifications/mark-category-as-read")]
    public ActionResult<Roblox.Api.Notifications.Models.SuccessResponseModel> postV2Push_notificationsMark_category_as_read([FromBody] Roblox.Api.Notifications.Models.MarkCategoryAsReadRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/push-notifications/mark-interaction")]
    public ActionResult<Roblox.Api.Notifications.Models.SuccessResponseModel> postV2Push_notificationsMark_interaction([FromBody] Roblox.Api.Notifications.Models.MarkInteractionRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/push-notifications/metadata")]
    public ActionResult<Roblox.Api.Notifications.Models.GetMetadataResponseModel> getV2Push_notificationsMetadata([FromQuery] string notificationToken, [FromQuery] string notificationId)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/push-notifications/notification-ids")]
    public ActionResult<Roblox.Api.Notifications.Models.NotificationIdsResponseModel> getV2Push_notificationsNotification_ids([FromQuery] string notificationToken, [FromQuery] int limit, [FromQuery] int cursor)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/push-notifications/register-android-amazon")]
    public ActionResult<Roblox.Api.Notifications.Models.RegistrationResponseModel> postV2Push_notificationsRegister_android_amazon([FromBody] Roblox.Api.Notifications.Models.RegisterAndroidAmazonRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/push-notifications/register-android-native")]
    public ActionResult<Roblox.Api.Notifications.Models.RegistrationResponseModel> postV2Push_notificationsRegister_android_native([FromBody] Roblox.Api.Notifications.Models.RegisterAndroidRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/push-notifications/register-android-tencent-service")]
    public ActionResult<Roblox.Api.Notifications.Models.RegistrationResponseModel> postV2Push_notificationsRegister_android_tencent_service([FromBody] Roblox.Api.Notifications.Models.RegisterTencentServiceRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/push-notifications/register-chrome")]
    public ActionResult<Roblox.Api.Notifications.Models.RegistrationResponseModel> postV2Push_notificationsRegister_chrome([FromBody] Roblox.Api.Notifications.Models.RegisterChromeRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/push-notifications/register-firefox")]
    public ActionResult<Roblox.Api.Notifications.Models.RegistrationResponseModel> postV2Push_notificationsRegister_firefox([FromBody] Roblox.Api.Notifications.Models.RegisterFirefoxRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/push-notifications/register-ios-native")]
    public ActionResult<Roblox.Api.Notifications.Models.RegistrationResponseModel> postV2Push_notificationsRegister_ios_native([FromBody] Roblox.Api.Notifications.Models.RegisterIOSNativeRequestModel requestModel)
    {
        return StatusCode(501);
    }

}
