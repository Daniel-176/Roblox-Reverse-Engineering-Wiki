using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ItemsController : ControllerBase
{
    [HttpPost("v1/assets/upload")]
    public ActionResult<Roblox.Publish.Api.UploadAssetResponse> postV1AssetsUpload([FromForm] object? uploadAssetRequest_files)
    {
        return StatusCode(501);
    }

}
