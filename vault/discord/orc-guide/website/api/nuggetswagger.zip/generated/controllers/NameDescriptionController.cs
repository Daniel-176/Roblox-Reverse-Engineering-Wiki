using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class NameDescriptionController : ControllerBase
{
    [HttpGet("v1/name-description/games/{gameId}")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.GameInternationalization.Api.NameDescription]> getV1Name_descriptionGamesGameId([FromRoute] long gameId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/name-description/games/{gameId}")]
    public ActionResult<Roblox.GameInternationalization.Api.UpdateNameDescriptionsResponse> patchV1Name_descriptionGamesGameId([FromRoute] long gameId, [FromBody] Roblox.GameInternationalization.Api.UpdateNameDescriptionsRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/name-description/games/{gameId}/history")]
    public ActionResult<Roblox.GameInternationalization.Api.GetNameDescriptionHistoryResponse> postV1Name_descriptionGamesGameIdHistory([FromRoute] long gameId, [FromBody] Roblox.GameInternationalization.Api.GetNameDescriptionHistoryRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/name-description/metadata")]
    public ActionResult<Roblox.GameInternationalization.Api.Models.Response.GameNameDescriptionMetadataResponse> getV1Name_descriptionMetadata()
    {
        return StatusCode(501);
    }

}
