using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MetadataController : ControllerBase
{
    [HttpGet("v1/metadata")]
    public ActionResult<Roblox.AccountInformation.Api.Models.MetadataResponse> getV1Metadata()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/metadata")]
    public ActionResult<Roblox.Authentication.Api.Models.MetadataResponse> getV1Metadata()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/metadata")]
    public ActionResult<Roblox.TwoStepVerification.Api.MetadataResponse> getV1Metadata([FromQuery] long userId, [FromQuery] string? challengeId, [FromQuery] string? actionType)
    {
        return StatusCode(501);
    }

}
