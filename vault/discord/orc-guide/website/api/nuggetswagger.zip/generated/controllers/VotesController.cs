using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class VotesController : ControllerBase
{
    [HttpGet("v1/games/votes")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Games.Api.Models.Response.GameVoteResponse]> getV1GamesVotes([FromQuery] long[] universeIds)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/games/{universeId}/user-votes")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1GamesUniverseIdUser_votes([FromRoute] long universeId, [FromBody] Roblox.Games.Api.Models.Request.SetUserGameVoteRequest requestBody)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/{universeId}/votes")]
    public ActionResult<Roblox.Games.Api.Models.Response.GameVoteResponse> getV1GamesUniverseIdVotes([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/{universeId}/votes/user")]
    public ActionResult<Roblox.Games.Api.Models.Response.UserGameVoteResponse> getV1GamesUniverseIdVotesUser([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

}
