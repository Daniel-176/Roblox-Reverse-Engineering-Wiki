using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class WallController : ControllerBase
{
    [HttpGet("v1/groups/{groupId}/wall/posts")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Groups.Api.Models.Response.GroupWallPostModel]> getV1GroupsGroupIdWallPosts([FromRoute] long groupId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/{groupId}/wall/posts")]
    public ActionResult<Roblox.Groups.Api.Models.Response.GroupWallPostModel> postV1GroupsGroupIdWallPosts([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.CreateWallPostRequest request)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/groups/{groupId}/wall/posts/{postId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1GroupsGroupIdWallPostsPostId([FromRoute] long groupId, [FromRoute] long postId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/{groupId}/wall/subscribe")]
    public ActionResult<object> postV1GroupsGroupIdWallSubscribe([FromRoute] long groupId)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/groups/{groupId}/wall/users/{userId}/posts")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1GroupsGroupIdWallUsersUserIdPosts([FromRoute] long groupId, [FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/groups/{groupId}/wall/posts")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Groups.Api.GroupWallPostV2Model]> getV2GroupsGroupIdWallPosts([FromRoute] long groupId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/groups/{groupId}/wall/posts")]
    public ActionResult<Roblox.Groups.Api.GroupWallPostV2Model> postV2GroupsGroupIdWallPosts([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.CreateWallPostRequest request)
    {
        return StatusCode(501);
    }

}
