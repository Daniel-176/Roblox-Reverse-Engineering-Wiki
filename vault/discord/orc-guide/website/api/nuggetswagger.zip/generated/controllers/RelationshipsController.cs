using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RelationshipsController : ControllerBase
{
    [HttpGet("v1/groups/{groupId}/relationships/{groupRelationshipType}")]
    public ActionResult<Roblox.Groups.Api.GroupRelationshipsResponse> getV1GroupsGroupIdRelationshipsGroupRelationshipType([FromRoute] long groupId, [FromRoute] string groupRelationshipType, [FromQuery] int model_startRowIndex, [FromQuery] int model_maxRows)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/groups/{groupId}/relationships/{groupRelationshipType}/requests")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1GroupsGroupIdRelationshipsGroupRelationshipTypeRequests([FromRoute] long groupId, [FromRoute] string groupRelationshipType, [FromBody] Roblox.Groups.Api.RelationshipsRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/relationships/{groupRelationshipType}/requests")]
    public ActionResult<Roblox.Groups.Api.GroupRelationshipsResponse> getV1GroupsGroupIdRelationshipsGroupRelationshipTypeRequests([FromRoute] long groupId, [FromRoute] string groupRelationshipType, [FromQuery] int model_startRowIndex, [FromQuery] int model_maxRows)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/{groupId}/relationships/{groupRelationshipType}/requests")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GroupsGroupIdRelationshipsGroupRelationshipTypeRequests([FromRoute] long groupId, [FromRoute] string groupRelationshipType, [FromBody] Roblox.Groups.Api.RelationshipsRequest request)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/groups/{groupId}/relationships/{groupRelationshipType}/requests/{relatedGroupId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1GroupsGroupIdRelationshipsGroupRelationshipTypeRequestsRelatedGroupId([FromRoute] long groupId, [FromRoute] string groupRelationshipType, [FromRoute] long relatedGroupId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/{groupId}/relationships/{groupRelationshipType}/requests/{relatedGroupId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GroupsGroupIdRelationshipsGroupRelationshipTypeRequestsRelatedGroupId([FromRoute] long groupId, [FromRoute] string groupRelationshipType, [FromRoute] long relatedGroupId)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/groups/{groupId}/relationships/{groupRelationshipType}/{relatedGroupId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1GroupsGroupIdRelationshipsGroupRelationshipTypeRelatedGroupId([FromRoute] long groupId, [FromRoute] string groupRelationshipType, [FromRoute] long relatedGroupId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/{groupId}/relationships/{groupRelationshipType}/{relatedGroupId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GroupsGroupIdRelationshipsGroupRelationshipTypeRelatedGroupId([FromRoute] long groupId, [FromRoute] string groupRelationshipType, [FromRoute] long relatedGroupId)
    {
        return StatusCode(501);
    }

}
