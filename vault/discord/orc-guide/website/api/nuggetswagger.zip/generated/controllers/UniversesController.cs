using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UniversesController : ControllerBase
{
    [HttpGet("v1/universes/multiget")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Api.Develop.Models.UniverseModel]> getV1UniversesMultiget([FromQuery] long[] ids)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/multiget/permissions")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Api.Develop.Models.UniverseIdPermissionsModel]> getV1UniversesMultigetPermissions([FromQuery] long[] ids)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}")]
    public ActionResult<Roblox.Api.Develop.Models.UniverseModel> getV1UniversesUniverseId([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/universes/{universeId}/activate")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UniversesUniverseIdActivate([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/universes/{universeId}/deactivate")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UniversesUniverseIdDeactivate([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/live-stats")]
    public ActionResult<Roblox.Api.Develop.Models.LiveStatsResponseModel> getV1UniversesUniverseIdLive_stats([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/permissions")]
    public ActionResult<Roblox.Api.Develop.Models.UniversePermissionsModel> getV1UniversesUniverseIdPermissions([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/places")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Api.Develop.Models.IPlaceModel]> getV1UniversesUniverseIdPlaces([FromRoute] long universeId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/revenue-reports")]
    public ActionResult<Roblox.Api.Develop.Models.RevenueReportStatusListResponse> getV1UniversesUniverseIdRevenue_reports([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/revenue-reports/{yearDashMonth}")]
    public ActionResult<Roblox.Api.Develop.Models.MonthlyRevenueReportStatus> getV1UniversesUniverseIdRevenue_reportsYearDashMonth([FromRoute] long universeId, [FromRoute] string yearDashMonth)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/revenue-reports/{yearDashMonth}/download")]
    public ActionResult<object> getV1UniversesUniverseIdRevenue_reportsYearDashMonthDownload([FromRoute] long universeId, [FromRoute] string yearDashMonth)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/universes/{universeId}/revenue-reports/{yearDashMonth}/generate")]
    public ActionResult<Roblox.Api.Develop.Models.RequestRevenueReportResponse> postV1UniversesUniverseIdRevenue_reportsYearDashMonthGenerate([FromRoute] long universeId, [FromRoute] string yearDashMonth)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/statistic-reports")]
    public ActionResult<Roblox.Api.Develop.Models.GameStatsListResponse> getV1UniversesUniverseIdStatistic_reports([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/statistic-reports/{yearDashMonth}")]
    public ActionResult<Roblox.DevMetrics.Models.ReportStatusResult> getV1UniversesUniverseIdStatistic_reportsYearDashMonth([FromRoute] long universeId, [FromRoute] string yearDashMonth)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/statistic-reports/{yearDashMonth}/download")]
    public ActionResult<object> getV1UniversesUniverseIdStatistic_reportsYearDashMonthDownload([FromRoute] long universeId, [FromRoute] string yearDashMonth)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/universes/{universeId}/statistic-reports/{yearDashMonth}/generate")]
    public ActionResult<object> postV1UniversesUniverseIdStatistic_reportsYearDashMonthGenerate([FromRoute] long universeId, [FromRoute] string yearDashMonth)
    {
        return StatusCode(501);
    }

}
