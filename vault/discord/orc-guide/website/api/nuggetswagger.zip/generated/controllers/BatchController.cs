using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BatchController : ControllerBase
{
    [HttpPost("v1/assets/batch")]
    public ActionResult<Roblox.Platform.Assets.IAssetResponseItem[]> postV1AssetsBatch([FromHeader] long Roblox_Place_Id, [FromHeader] string Accept, [FromHeader] string Roblox_Browser_Asset_Request, [FromBody] Roblox.Web.Assets.BatchAssetRequestItem[] assetRequestItems)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/batch")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Thumbnails.ThumbnailBatchResponse]> postV1Batch([FromBody] Roblox.Thumbnails.Apis.Models.ThumbnailBatchRequest[] requests)
    {
        return StatusCode(501);
    }

}
