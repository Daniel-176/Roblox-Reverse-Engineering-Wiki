using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PromotionChannelController : ControllerBase
{
    [HttpGet("v1/promotion-channels")]
    public ActionResult<Roblox.AccountInformation.Api.Models.PromotionChannelsResponse> getV1Promotion_channels()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/promotion-channels")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Promotion_channels([FromBody] Roblox.AccountInformation.Api.Models.PromotionChannelsRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/promotion-channels")]
    public ActionResult<Roblox.AccountInformation.Api.Models.PromotionChannelsByUserIdResponse> getV1UsersUserIdPromotion_channels([FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
