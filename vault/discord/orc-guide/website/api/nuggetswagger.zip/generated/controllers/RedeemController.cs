using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RedeemController : ControllerBase
{
    [HttpPost("v1/promocodes/redeem")]
    public ActionResult<Roblox.Api.Billing.Models.Response.PromoCodeResponse> postV1PromocodesRedeem([FromBody] Roblox.Api.Billing.Models.Requests.PromoCodeRequest promoCodeRequest)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/toys/redeem/metadata")]
    public ActionResult<Roblox.Api.Billing.Models.Response.RedeemToyMetadataResponse> getV1ToysRedeemMetadata()
    {
        return StatusCode(501);
    }

}
