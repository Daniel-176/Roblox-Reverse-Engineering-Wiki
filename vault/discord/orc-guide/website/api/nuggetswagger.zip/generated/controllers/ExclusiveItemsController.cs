using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ExclusiveItemsController : ControllerBase
{
    [HttpGet("v1/exclusive-items/{appStoreType}/bundles")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiLegacyPageResponse[Roblox.Catalog.Api.CatalogItemModel]> getV1Exclusive_itemsAppStoreTypeBundles([FromRoute] string appStoreType)
    {
        return StatusCode(501);
    }

}
