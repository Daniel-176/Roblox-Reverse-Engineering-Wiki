using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BadgesController : ControllerBase
{
    [HttpGet("v1/badges/icons")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Thumbnails.ThumbnailResponse]> getV1BadgesIcons([FromQuery] long[] badgeIds, [FromQuery] string? size, [FromQuery] int format, [FromQuery] bool isCircular)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/badges/{badgeId}")]
    public ActionResult<Roblox.Badges.Api.BadgeResponse> getV1BadgesBadgeId([FromRoute] long badgeId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/badges/{badgeId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1BadgesBadgeId([FromRoute] long badgeId, [FromBody] Roblox.Badges.Api.UpdateBadgeRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/badges/{badgeId}/icon")]
    public ActionResult<Roblox.Publish.Api.UploadResponse> postV1BadgesBadgeIdIcon([FromRoute] long badgeId, [FromForm] object? request_files)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/badges")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Badges.Api.BadgeResponse]> getV1UniversesUniverseIdBadges([FromRoute] long universeId, [FromQuery] int limit, [FromQuery] string? cursor, [FromQuery] string? sortOrder)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/badges")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Web.Responses.Badges.BadgeResponseV2]> getV1UsersUserIdBadges([FromRoute] long userId, [FromQuery] int limit, [FromQuery] string? cursor, [FromQuery] string? sortOrder)
    {
        return StatusCode(501);
    }

}
