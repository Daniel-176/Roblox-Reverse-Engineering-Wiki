using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PrivacySettingsController : ControllerBase
{
    [HttpGet("v1/app-chat-privacy")]
    public ActionResult<Roblox.AccountSettings.Api.AppChatPrivacyResponse> getV1App_chat_privacy()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/app-chat-privacy")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1App_chat_privacy([FromBody] Roblox.AccountSettings.Api.AppChatPrivacyRequest model)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/game-chat-privacy")]
    public ActionResult<Roblox.AccountSettings.Api.GameChatPrivacyResponse> getV1Game_chat_privacy()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/game-chat-privacy")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Game_chat_privacy([FromBody] Roblox.AccountSettings.Api.GameChatPrivacyRequest model)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/inventory-privacy")]
    public ActionResult<Roblox.AccountSettings.Api.InventoryPrivacyResponse> getV1Inventory_privacy()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/inventory-privacy")]
    public ActionResult<Roblox.AccountSettings.Api.InventoryPrivacyUpdateResponse> postV1Inventory_privacy([FromBody] Roblox.AccountSettings.Api.InventoryPrivacyRequest model)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/private-message-privacy")]
    public ActionResult<Roblox.AccountSettings.Api.PrivateMessagePrivacyResponse> getV1Private_message_privacy()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/private-message-privacy")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Private_message_privacy([FromBody] Roblox.AccountSettings.Api.PrivateMessagePrivacyRequest model)
    {
        return StatusCode(501);
    }

}
