using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CurrencyController : ControllerBase
{
    [HttpGet("my/balance")]
    public ActionResult<object> Currency_GetBalance()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/currency")]
    public ActionResult<Roblox.Web.Responses.Economy.CurrencyResponse> getV1GroupsGroupIdCurrency([FromRoute] long groupId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/currency")]
    public ActionResult<Roblox.Web.Responses.Economy.CurrencyResponse> getV1UsersUserIdCurrency([FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
