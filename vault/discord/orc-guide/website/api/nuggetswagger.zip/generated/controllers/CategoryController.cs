using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CategoryController : ControllerBase
{
    [HttpGet("v1/asset-to-category")]
    public ActionResult<Dictionary<string, long>> getV1Asset_to_category()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/asset-to-subcategory")]
    public ActionResult<Dictionary<string, long>> getV1Asset_to_subcategory()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/categories")]
    public ActionResult<Dictionary<string, long>> getV1Categories()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/subcategories")]
    public ActionResult<Dictionary<string, long>> getV1Subcategories()
    {
        return StatusCode(501);
    }

}
