using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DisplayNamesController : ControllerBase
{
    [HttpGet("v1/display-names/validate")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> getV1Display_namesValidate([FromQuery] string displayName, [FromQuery] string birthdate)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/users/{userId}/display-names")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1UsersUserIdDisplay_names([FromRoute] long userId, [FromBody] Roblox.Users.Api.SetDisplayNameRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/display-names/validate")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> getV1UsersUserIdDisplay_namesValidate([FromRoute] long userId, [FromQuery] string displayName)
    {
        return StatusCode(501);
    }

}
