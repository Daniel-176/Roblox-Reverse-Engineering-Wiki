using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AppleController : ControllerBase
{
    [HttpPost("v1/apple/purchase")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1ApplePurchase([FromBody] Roblox.Api.Billing.Models.AppleStorePurchaseModel appleStorePurchaseModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/apple/validate")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1AppleValidate([FromBody] Roblox.Api.Billing.Models.ValidateModel validateModel)
    {
        return StatusCode(501);
    }

}
