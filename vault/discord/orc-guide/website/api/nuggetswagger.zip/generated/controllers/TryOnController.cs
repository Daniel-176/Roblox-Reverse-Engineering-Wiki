using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TryOnController : ControllerBase
{
    [HttpGet("v1/try-on/2d")]
    public ActionResult<Roblox.Api.Avatar.Models.TryOnModel> getV1Try_on_2d([FromQuery] long[] assetIds, [FromQuery] int width, [FromQuery] int height, [FromQuery] string format, [FromQuery] bool addAccoutrements)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/try-on/3d")]
    public ActionResult<Roblox.Api.Avatar.Models.TryOnModel> getV1Try_on_3d([FromQuery] long[] assetIds, [FromQuery] bool addAccoutrements)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/try-on/metadata")]
    public ActionResult<Roblox.Api.Avatar.Models.TryOnMetadataModel> getV1Try_onMetadata()
    {
        return StatusCode(501);
    }

}
