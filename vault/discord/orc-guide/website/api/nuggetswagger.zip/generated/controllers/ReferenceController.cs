using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ReferenceController : ControllerBase
{
    [HttpGet("reference/deviceinfo")]
    public ActionResult<object> Reference_DeviceInfoJson()
    {
        return StatusCode(501);
    }

}
