using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PointsController : ControllerBase
{
    [HttpGet("v1/universes/{universeId}/users/{userId}/all-time")]
    public ActionResult<Roblox.Points.Api.GetAllTimePointBalanceResponse> getV1UniversesUniverseIdUsersUserIdAll_time([FromRoute] long universeId, [FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
