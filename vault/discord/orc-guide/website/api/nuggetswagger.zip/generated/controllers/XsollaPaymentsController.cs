using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class XsollaPaymentsController : ControllerBase
{
    [HttpPost("v1/payments/xsolla/iframe-token")]
    public ActionResult<Roblox.Api.Billing.Models.Response.XsollaPaymentIframeTokenModel> postV1PaymentsXsollaIframe_token([FromBody] Roblox.Api.Billing.Models.Requests.XsollaIframeRequest xsollaIframeRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/payments/xsolla/incrementcounterbyagent")]
    public IActionResult postV1PaymentsXsollaIncrementcounterbyagent([FromQuery] string counterPrefix)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/payments/xsolla/metadata")]
    public ActionResult<Roblox.Api.Billing.Models.Response.XsollaPaymentMetadataResponse> getV1PaymentsXsollaMetadata([FromQuery] int xsollaPaymentMetadataRequest_productId, [FromQuery] string? xsollaPaymentMetadataRequest_paymentMethod, [FromQuery] int xsollaPaymentMetadataRequest_selectedUpsellProductId)
    {
        return StatusCode(501);
    }

}
