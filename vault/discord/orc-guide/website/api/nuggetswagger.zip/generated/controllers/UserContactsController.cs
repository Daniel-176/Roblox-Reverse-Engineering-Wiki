using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserContactsController : ControllerBase
{
    [HttpPost("v1/contacts/match")]
    public ActionResult<Roblox.Contacts.Api.UserContactsResponse> postV1ContactsMatch([FromBody] Roblox.Contacts.Api.MatchUserContactsRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/contacts/match")]
    public ActionResult<Roblox.Contacts.Api.UserContactsResponse> postV1ContactsMatch([FromBody] Roblox.Contacts.Api.MatchUserContactsRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/contacts/update")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1ContactsUpdate([FromBody] Roblox.Contacts.Api.UpdateUserContactsRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/contacts/update")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1ContactsUpdate([FromBody] Roblox.Contacts.Api.UpdateUserContactsRequest requestModel)
    {
        return StatusCode(501);
    }

}
