using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BlockUserController : ControllerBase
{
    [HttpGet("v1/users/get-blocked-users")]
    public ActionResult<Roblox.AccountSettings.Api.Models.Response.GetBlockedUsersResponse> getV1UsersGet_blocked_users()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/get-detailed-blocked-users")]
    public ActionResult<Roblox.AccountSettings.Api.Models.Response.GetDetailedBlockedUsersResponse> getV1UsersGet_detailed_blocked_users()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{userId}/block")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UsersUserIdBlock([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{userId}/unblock")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UsersUserIdUnblock([FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
