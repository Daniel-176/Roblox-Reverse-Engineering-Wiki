using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserModerationController : ControllerBase
{
    [HttpGet("v1/not-approved")]
    public ActionResult<Roblox.UserModeration.Api.Models.Response.NotApprovedResponse> getV1Not_approved()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/not-approved/reactivate")]
    public ActionResult<Roblox.UserModeration.Api.Models.Response.SetAllPunishmentAcknowledgmentResponse> postV1Not_approvedReactivate()
    {
        return StatusCode(501);
    }

}
