using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserBlockController : ControllerBase
{
    [HttpPost("userblock/block")]
    public ActionResult<object> UserBlock_BlockUser([FromQuery] long userId)
    {
        return StatusCode(501);
    }

    [HttpPost("userblock/unblock")]
    public ActionResult<object> UserBlock_UnblockUser([FromQuery] long userId)
    {
        return StatusCode(501);
    }

}
