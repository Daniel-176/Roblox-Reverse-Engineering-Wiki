using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GamesController : ControllerBase
{
    [HttpGet("v1/games")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Games.Api.Models.Response.GameDetailResponse]> getV1Games([FromQuery] long[] universeIds)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/game-thumbnail")]
    public ActionResult<object> getV1GamesGame_thumbnail([FromQuery] string imageToken, [FromQuery] int height, [FromQuery] int width)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/game-thumbnails")]
    public ActionResult<Roblox.Games.Api.Models.Response.Thumbnail[]> getV1GamesGame_thumbnails([FromQuery] string[] imageTokens, [FromQuery] int height, [FromQuery] int width)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/games-product-info")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Games.Api.Models.Response.GameProductResponse]> getV1GamesGames_product_info([FromQuery] long[] universeIds)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/icons")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Thumbnails.ThumbnailResponse]> getV1GamesIcons([FromQuery] long[] universeIds, [FromQuery] string? returnPolicy, [FromQuery] string? size, [FromQuery] int format, [FromQuery] bool isCircular)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/list")]
    public ActionResult<Roblox.Games.Api.Models.Response.GamesSearchResponse> getV1GamesList([FromQuery] string? model_sortToken, [FromQuery] string? model_gameFilter, [FromQuery] string? model_timeFilter, [FromQuery] string? model_genreFilter, [FromQuery] long model_exclusiveStartId, [FromQuery] int model_sortOrder, [FromQuery] long model_gameSetTargetId, [FromQuery] string? model_keyword, [FromQuery] int model_startRows, [FromQuery] int model_maxRows, [FromQuery] bool model_isKeywordSuggestionEnabled, [FromQuery] int model_contextCountryRegionId, [FromQuery] long model_contextUniverseId, [FromQuery] string? model_pageContext_pageId, [FromQuery] bool model_pageContext_isSeeAllPage, [FromQuery] int model_sortPosition)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/list-spotlight")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Games.Api.Models.Response.GameSpotlightResponse]> getV1GamesList_spotlight()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/multiget-place-details")]
    public ActionResult<Roblox.Games.Api.Models.Response.PlaceDetails[]> getV1GamesMultiget_place_details([FromQuery] long[] placeIds)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/multiget-playability-status")]
    public ActionResult<Roblox.Games.Api.Models.Response.PlayabilityStatusResponse[]> getV1GamesMultiget_playability_status([FromQuery] long[] universeIds)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/multiget/thumbnails")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Thumbnails.Api.Models.UniverseThumbnailsResponse]> getV1GamesMultigetThumbnails([FromQuery] long[] universeIds, [FromQuery] int countPerUniverse, [FromQuery] bool defaults, [FromQuery] string? size, [FromQuery] int format, [FromQuery] bool isCircular)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/recommendations/algorithm/{algorithmName}")]
    public ActionResult<Roblox.Games.Api.Models.Response.GameRecommendationsResponse> getV1GamesRecommendationsAlgorithmAlgorithmName([FromRoute] string algorithmName, [FromQuery] string? model_paginationKey, [FromQuery] int model_maxRows, [FromQuery] bool model_isTruncatedResultsEnabled)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/recommendations/game/{universeId}")]
    public ActionResult<Roblox.Games.Api.Models.Response.GameRecommendationsResponse> getV1GamesRecommendationsGameUniverseId([FromRoute] long universeId, [FromQuery] string? model_paginationKey, [FromQuery] int model_maxRows, [FromQuery] bool model_isTruncatedResultsEnabled)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/sorts")]
    public ActionResult<Roblox.Games.Api.Models.Response.GameSortsResponse> getV1GamesSorts([FromQuery] string? model_gameSortsContext)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/{placeId}/servers/{serverType}")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Web.Responses.Games.GameServerResponse]> getV1GamesPlaceIdServersServerType([FromRoute] long placeId, [FromRoute] string serverType, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/{universeId}/media")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Games.Api.Models.Response.GameMediaItem]> getV1GamesUniverseIdMedia([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/{universeId}/thumbnails")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Thumbnails.ThumbnailResponse]> getV1GamesUniverseIdThumbnails([FromRoute] long universeId, [FromQuery] long[] thumbnailIds, [FromQuery] string? size, [FromQuery] int format, [FromQuery] bool isCircular)
    {
        return StatusCode(501);
    }

}
