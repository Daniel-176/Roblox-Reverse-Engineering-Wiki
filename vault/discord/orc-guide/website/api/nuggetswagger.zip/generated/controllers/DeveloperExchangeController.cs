using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DeveloperExchangeController : ControllerBase
{
    [HttpGet("v1/developer-exchange-rate")]
    public ActionResult<Roblox.Api.Billing.Models.Response.GetDevexRateResponse> getV1Developer_exchange_rate()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/developer-exchange-request")]
    public ActionResult<Roblox.Api.Billing.Models.Response.SubmitDevexResponse> postV1Developer_exchange_request([FromBody] Roblox.Api.Billing.Models.Requests.SubmitDevexRequest request)
    {
        return StatusCode(501);
    }

}
