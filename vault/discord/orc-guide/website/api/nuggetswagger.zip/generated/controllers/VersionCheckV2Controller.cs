using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class VersionCheckV2Controller : ControllerBase
{
    [HttpGet("v2/client-version/{binaryType}")]
    public ActionResult<Roblox.ClientSettings.Api.Models.Response.ClientVersionResponse> getV2Client_versionBinaryType([FromRoute] string binaryType)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/client-version/{binaryType}/channel/{channelName}")]
    public ActionResult<Roblox.ClientSettings.Api.Models.Response.ClientVersionResponse> getV2Client_versionBinaryTypeChannelChannelName([FromRoute] string binaryType, [FromRoute] string channelName)
    {
        return StatusCode(501);
    }

}
