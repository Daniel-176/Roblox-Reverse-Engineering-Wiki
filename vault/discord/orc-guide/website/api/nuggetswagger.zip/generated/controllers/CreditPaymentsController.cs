using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CreditPaymentsController : ControllerBase
{
    [HttpPost("v1/payments/credit/checkout")]
    public ActionResult<Roblox.Api.Billing.Models.Response.CreditPaymentCheckoutResponse> postV1PaymentsCreditCheckout([FromBody] Roblox.Api.Billing.Models.Requests.CreditPaymentCheckoutRequest creditPaymentCheckoutRequest)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/payments/credit/metadata")]
    public ActionResult<Roblox.Api.Billing.Models.Response.CreditPaymentMetadataResponse> getV1PaymentsCreditMetadata([FromQuery] int ap)
    {
        return StatusCode(501);
    }

}
