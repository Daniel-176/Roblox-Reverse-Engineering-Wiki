using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AccountsController : ControllerBase
{
    [HttpGet("v1/account/settings/metadata")]
    public ActionResult<Roblox.AccountSettings.Api.Models.AccountsSettingsMetadataModel> getV1AccountSettingsMetadata()
    {
        return StatusCode(501);
    }

}
