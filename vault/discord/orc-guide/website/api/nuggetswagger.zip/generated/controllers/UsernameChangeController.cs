using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsernameChangeController : ControllerBase
{
    [HttpPost("v1/username")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Username([FromBody] Roblox.Authentication.Api.Models.UsernameChangeRequest request)
    {
        return StatusCode(501);
    }

}
