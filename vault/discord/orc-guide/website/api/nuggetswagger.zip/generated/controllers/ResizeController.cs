using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ResizeController : ControllerBase
{
    [HttpGet("v1/resize/{hash}/{width}/{height}/{type}/{format}/{filterType}")]
    public ActionResult<object> getV1ResizeHashWidthHeightTypeFormatFilterType([FromRoute] string hash, [FromRoute] int width, [FromRoute] int height, [FromRoute] string type, [FromRoute] string format, [FromRoute] string filterType)
    {
        return StatusCode(501);
    }

}
