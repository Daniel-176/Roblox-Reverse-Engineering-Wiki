using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AnnouncementsController : ControllerBase
{
    [HttpGet("v1/announcements")]
    public ActionResult<Roblox.PrivateMessages.Api.Models.GetAnnouncementsResponse> getV1Announcements()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/announcements/metadata")]
    public ActionResult<Roblox.PrivateMessages.Api.Models.AnnouncementsMetadataResponse> getV1AnnouncementsMetadata()
    {
        return StatusCode(501);
    }

}
