using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TeamCreateController : ControllerBase
{
    [HttpGet("v1/places/{placeId}/teamcreate/active_session/members")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Users.SkinnyUserResponse]> getV1PlacesPlaceIdTeamcreateActive_sessionMembers([FromRoute] long placeId, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/teamcreate")]
    public ActionResult<Roblox.Api.Develop.Models.Response.TeamCreateSettingsResponse> getV1UniversesUniverseIdTeamcreate([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/universes/{universeId}/teamcreate")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1UniversesUniverseIdTeamcreate([FromRoute] long universeId, [FromBody] Roblox.Api.Develop.Models.UpdateTeamCreateSettingsRequest request)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/universes/{universeId}/teamcreate/memberships")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1UniversesUniverseIdTeamcreateMemberships([FromRoute] long universeId, [FromBody] Roblox.Api.Develop.Models.TeamCreateMembershipRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/teamcreate/memberships")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Api.Develop.Models.UserResponse]> getV1UniversesUniverseIdTeamcreateMemberships([FromRoute] long universeId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/user/teamcreate/memberships")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Api.Develop.Models.UniverseModel]> getV1UserTeamcreateMemberships([FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

}
