using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OutfitsController : ControllerBase
{
    [HttpPost("v1/outfits/create")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> postV1OutfitsCreate([FromBody] Roblox.Api.Avatar.Models.OutfitUpdateModel outfitUpdateModel)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/outfits/{userOutfitId}")]
    public ActionResult<Roblox.Api.Avatar.Models.OutfitModel> patchV1OutfitsUserOutfitId([FromRoute] long userOutfitId, [FromBody] Roblox.Api.Avatar.Models.OutfitUpdateModel outfitUpdateModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/outfits/{userOutfitId}/delete")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> postV1OutfitsUserOutfitIdDelete([FromRoute] long userOutfitId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/outfits/{userOutfitId}/details")]
    public ActionResult<Roblox.Api.Avatar.Models.OutfitDetailsModel> getV1OutfitsUserOutfitIdDetails([FromRoute] long userOutfitId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/outfits/{userOutfitId}/update")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> postV1OutfitsUserOutfitIdUpdate([FromRoute] long userOutfitId, [FromBody] Roblox.Api.Avatar.Models.OutfitUpdateModel outfitUpdateModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/outfits/{userOutfitId}/wear")]
    public ActionResult<Roblox.Api.Avatar.Models.WearResponseModel> postV1OutfitsUserOutfitIdWear([FromRoute] long userOutfitId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/outfits")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Thumbnails.ThumbnailResponse]> getV1UsersOutfits([FromQuery] long[] userOutfitIds, [FromQuery] string? size, [FromQuery] int format, [FromQuery] bool isCircular)
    {
        return StatusCode(501);
    }

}
