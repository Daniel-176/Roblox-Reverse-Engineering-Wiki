using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GamePassesController : ControllerBase
{
    [HttpGet("v1/game-passes")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Thumbnails.ThumbnailResponse]> getV1Game_passes([FromQuery] long[] gamePassIds, [FromQuery] string? size, [FromQuery] int format, [FromQuery] bool isCircular)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/games/{universeId}/game-passes")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Games.Api.Models.Response.GamePassResponse]> getV1GamesUniverseIdGame_passes([FromRoute] long universeId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

}
