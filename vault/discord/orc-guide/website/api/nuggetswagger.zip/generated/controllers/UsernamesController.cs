using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsernamesController : ControllerBase
{
    [HttpGet("v1/usernames")]
    public ActionResult<Roblox.Authentication.Api.Models.UsernamesResponse> getV1Usernames([FromQuery] string? username)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/usernames/recover")]
    public ActionResult<Roblox.Authentication.Api.Models.RecoverUsernameResponse> postV1UsernamesRecover([FromBody] Roblox.Authentication.Api.Models.RecoverUsernameRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/usernames/validate")]
    public ActionResult<Roblox.Authentication.Api.Models.UsernameValidationResponse> getV1UsernamesValidate([FromQuery] string? request_username, [FromQuery] string? request_birthday, [FromQuery] string? request_context)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/usernames/validate")]
    public ActionResult<Roblox.Authentication.Api.Models.UsernameValidationResponse> postV1UsernamesValidate([FromBody] Roblox.Authentication.Api.Models.UsernameValidationRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/username-history")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Users.Api.UsernameHistoryResponse]> getV1UsersUserIdUsername_history([FromRoute] long userId, [FromQuery] int limit, [FromQuery] string? cursor, [FromQuery] string? sortOrder)
    {
        return StatusCode(501);
    }

}
