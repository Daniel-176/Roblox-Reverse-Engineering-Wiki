using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PaypalPaymentController : ControllerBase
{
    [HttpPost("v1/payments/paypal/paymentResult")]
    public ActionResult<Roblox.Api.Billing.Models.Response.PaypalPaymentResultResponse> postV1PaymentsPaypalPaymentResult([FromQuery] long orderCode, [FromQuery] string? token)
    {
        return StatusCode(501);
    }

}
