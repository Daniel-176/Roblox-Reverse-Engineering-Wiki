using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TranslationsController : ControllerBase
{
    [HttpGet("v1/translations")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Translations.Api.TranslationsResponse]> getV1Translations([FromQuery] int consumerType)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/translations/language-resources")]
    public ActionResult<Dictionary<string, string>> getV1TranslationsLanguage_resources([FromQuery] int consumerType, [FromQuery] string contentNamespace, [FromQuery] string[] keys, [FromQuery] string? localeCode)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/translations/{locale}")]
    public ActionResult<Roblox.Translations.Api.TranslationsResponse> getV1TranslationsLocale([FromRoute] string locale, [FromQuery] int consumerType)
    {
        return StatusCode(501);
    }

}
