using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PartyController : ControllerBase
{
    [HttpPost("v1.0/party/create")]
    public ActionResult<Roblox.Chat.Api.Models.Party> postV1_0PartyCreate([FromBody] Roblox.Chat.Api.Models.CreatePartyRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1.0/party/get-current")]
    public ActionResult<Roblox.Chat.Api.Models.CurrentParty> getV1_0PartyGet_current()
    {
        return StatusCode(501);
    }

    [HttpGet("v1.0/party/get-invites")]
    public ActionResult<Roblox.Chat.Api.Models.Party[]> getV1_0PartyGet_invites([FromQuery] int pageNumber, [FromQuery] int pageSize)
    {
        return StatusCode(501);
    }

    [HttpGet("v1.0/party/get-parties-for-conversations")]
    public ActionResult<Roblox.Chat.Api.Models.Party[]> getV1_0PartyGet_parties_for_conversations([FromQuery] long[] conversationIds)
    {
        return StatusCode(501);
    }

    [HttpPost("v1.0/party/invite")]
    public ActionResult<Roblox.Chat.Api.Models.Party> postV1_0PartyInvite([FromBody] Roblox.Chat.Api.Models.InviteUserRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1.0/party/join")]
    public ActionResult<Roblox.Chat.Api.Models.StatusResponse> postV1_0PartyJoin([FromBody] Roblox.Chat.Api.Models.JoinPartyRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1.0/party/leave")]
    public ActionResult<Roblox.Chat.Api.Models.Party> postV1_0PartyLeave([FromBody] Roblox.Chat.Api.Models.PartyRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1.0/party/remove-from-party")]
    public ActionResult<Roblox.Chat.Api.Models.Party> postV1_0PartyRemove_from_party([FromBody] Roblox.Chat.Api.Models.RemoveFromPartyRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1.0/party/take-leadership")]
    public ActionResult<Roblox.Chat.Api.Models.StatusResponse> postV1_0PartyTake_leadership([FromBody] Roblox.Chat.Api.Models.PartyRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1.0/party/update-user-device")]
    public ActionResult<Roblox.Chat.Api.Models.StatusResponse> postV1_0PartyUpdate_user_device()
    {
        return StatusCode(501);
    }

}
