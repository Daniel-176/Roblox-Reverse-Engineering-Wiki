using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MembershipController : ControllerBase
{
    [HttpPost("v1/groups/{groupId}/change-owner")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GroupsGroupIdChange_owner([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.ChangeOwnerRequest changeOwnerRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/{groupId}/claim-ownership")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GroupsGroupIdClaim_ownership([FromRoute] long groupId)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/groups/{groupId}/join-requests")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1GroupsGroupIdJoin_requests([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.MembersRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/join-requests")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Groups.Api.GroupJoinRequestResponse]> getV1GroupsGroupIdJoin_requests([FromRoute] long groupId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/{groupId}/join-requests")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GroupsGroupIdJoin_requests([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.MembersRequest request)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/groups/{groupId}/join-requests/users/{userId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1GroupsGroupIdJoin_requestsUsersUserId([FromRoute] long groupId, [FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/join-requests/users/{userId}")]
    public ActionResult<Roblox.Groups.Api.GroupJoinRequestResponse> getV1GroupsGroupIdJoin_requestsUsersUserId([FromRoute] long groupId, [FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/{groupId}/join-requests/users/{userId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GroupsGroupIdJoin_requestsUsersUserId([FromRoute] long groupId, [FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/membership")]
    public ActionResult<Roblox.Groups.Api.GroupMembershipMetadataResponse> getV1GroupsGroupIdMembership([FromRoute] long groupId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/roles")]
    public ActionResult<Roblox.Groups.Api.GroupAllRolesResponse> getV1GroupsGroupIdRoles([FromRoute] long groupId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/roles/{roleSetId}/users")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Groups.Api.Models.Response.UserModel]> getV1GroupsGroupIdRolesRoleSetIdUsers([FromRoute] long groupId, [FromRoute] int roleSetId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/users")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Groups.Api.UserGroupRoleResponse]> getV1GroupsGroupIdUsers([FromRoute] long groupId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/{groupId}/users")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GroupsGroupIdUsers([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.JoinGroupRequest joinGroupModel)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/groups/{groupId}/users/{userId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1GroupsGroupIdUsersUserId([FromRoute] long groupId, [FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/groups/{groupId}/users/{userId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1GroupsGroupIdUsersUserId([FromRoute] long groupId, [FromRoute] long userId, [FromBody] Roblox.Groups.Api.UpdateUserRoleRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/user/groups/pending")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Groups.Api.GroupDetailResponse]> getV1UserGroupsPending()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/friends/groups/roles")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Groups.Api.UserGroupMembershipResponse]> getV1UsersUserIdFriendsGroupsRoles([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/groups/roles")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Groups.Api.GroupMembershipDetailResponse]> getV1UsersUserIdGroupsRoles([FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
