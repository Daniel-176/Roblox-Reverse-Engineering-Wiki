using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GoogleController : ControllerBase
{
    [HttpPost("v1/google/purchase")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GooglePurchase([FromBody] Roblox.Api.Billing.Models.GooglePlayPurchaseModel purchaseModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/google/validate")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GoogleValidate([FromBody] Roblox.Api.Billing.Models.ValidateModel validateModel)
    {
        return StatusCode(501);
    }

}
