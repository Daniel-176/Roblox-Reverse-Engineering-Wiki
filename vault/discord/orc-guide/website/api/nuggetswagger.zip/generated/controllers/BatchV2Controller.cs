using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BatchV2Controller : ControllerBase
{
    [HttpPost("v2/assets/batch")]
    public ActionResult<Roblox.Web.Assets.IAssetResponseItemV2[]> postV2AssetsBatch([FromHeader] long Roblox_Place_Id, [FromHeader] string? Accept, [FromHeader] string? Roblox_Browser_Asset_Request, [FromBody] Roblox.Web.Assets.BatchAssetRequestItem[] assetRequestItems)
    {
        return StatusCode(501);
    }

}
