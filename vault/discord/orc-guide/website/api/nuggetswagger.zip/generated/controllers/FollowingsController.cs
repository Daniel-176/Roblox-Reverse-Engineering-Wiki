using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FollowingsController : ControllerBase
{
    [HttpPost("v1/user/following-exists")]
    public ActionResult<Roblox.Friends.Api.Models.Response.FollowingExistsResponseModel> postV1UserFollowing_exists([FromBody] Roblox.Friends.Api.FollowingExistsRequestModel requestModel)
    {
        return StatusCode(501);
    }

}
