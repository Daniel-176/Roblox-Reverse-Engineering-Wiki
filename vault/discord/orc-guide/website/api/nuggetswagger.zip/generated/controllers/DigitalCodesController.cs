using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DigitalCodesController : ControllerBase
{
    [HttpPost("v1/digital-codes/redeem")]
    public ActionResult<object> postV1Digital_codesRedeem([FromBody] Roblox.Api.Billing.Models.DigitalCodeRedemptionModel redemptionModel)
    {
        return StatusCode(501);
    }

}
