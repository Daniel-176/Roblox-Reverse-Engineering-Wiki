using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AudioController : ControllerBase
{
    [HttpPost("v1/audio")]
    public ActionResult<Roblox.Publish.Api.PublishAudioResponse> postV1Audio([FromBody] Roblox.Publish.Api.UploadAudioRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/audio/verify")]
    public ActionResult<Roblox.Publish.Api.VerifyAudioResponse> postV1AudioVerify([FromBody] Roblox.Publish.Api.VerifyAudioRequest request)
    {
        return StatusCode(501);
    }

}
