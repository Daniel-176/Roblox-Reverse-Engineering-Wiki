using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserSearchController : ControllerBase
{
    [HttpGet("v1/users/search")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Users.Api.UserSearchUserResponse]> getV1UsersSearch([FromQuery] string keyword, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

}
