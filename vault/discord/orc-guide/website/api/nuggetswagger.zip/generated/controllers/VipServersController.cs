using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class VipServersController : ControllerBase
{
    [HttpPost("v1/games/vip-servers/{universeId}")]
    public ActionResult<Roblox.Web.Responses.Games.GameServerResponse> postV1GamesVip_serversUniverseId([FromRoute] long universeId, [FromBody] Roblox.Games.Api.CreateVipServersRequest requestBody)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/vip-server/can-invite/{userId}")]
    public ActionResult<Roblox.Games.Api.VipServerCanInviteResponse> getV1Vip_serverCan_inviteUserId([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/vip-servers/{id}")]
    public ActionResult<Roblox.Games.Api.VipServerResponse> getV1Vip_serversId([FromRoute] long id)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/vip-servers/{id}")]
    public ActionResult<Roblox.Games.Api.VipServerResponse> patchV1Vip_serversId([FromRoute] long id, [FromBody] Roblox.Games.Api.VipServerUpdateRequest request)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/vip-servers/{id}/permissions")]
    public ActionResult<Roblox.Games.Api.VipServerPermissionsResponse> patchV1Vip_serversIdPermissions([FromRoute] long id, [FromBody] Roblox.Games.Api.VipServerUpdatePermissionsRequest request)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/vip-servers/{id}/subscription")]
    public ActionResult<Roblox.Games.Api.VipServerSubscriptionResponse> patchV1Vip_serversIdSubscription([FromRoute] long id, [FromBody] Roblox.Games.Api.VipServerUpdateSubscriptionRequest request)
    {
        return StatusCode(501);
    }

}
