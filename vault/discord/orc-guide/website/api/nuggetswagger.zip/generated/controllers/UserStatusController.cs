using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserStatusController : ControllerBase
{
    [HttpGet("v1/users/{userId}/status")]
    public ActionResult<Roblox.Users.Api.UserStatusResponse> getV1UsersUserIdStatus([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/users/{userId}/status")]
    public ActionResult<Roblox.Users.Api.UserStatusResponse> patchV1UsersUserIdStatus([FromRoute] long userId, [FromBody] Roblox.Users.Api.SetUserStatusRequest request)
    {
        return StatusCode(501);
    }

}
