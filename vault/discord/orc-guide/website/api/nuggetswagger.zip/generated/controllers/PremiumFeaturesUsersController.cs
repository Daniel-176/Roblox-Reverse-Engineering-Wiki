using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PremiumFeaturesUsersController : ControllerBase
{
    [HttpGet("v1/users/{userId}/premium-upsell-precheck")]
    public ActionResult<object> getV1UsersUserIdPremium_upsell_precheck([FromRoute] long userId, [FromQuery] long universeId, [FromQuery] long placeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/validate-membership")]
    public ActionResult<object> getV1UsersUserIdValidate_membership([FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
