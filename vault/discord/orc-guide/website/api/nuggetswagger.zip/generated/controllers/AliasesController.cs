using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AliasesController : ControllerBase
{
    [HttpPost("v1/universes/{universeId}/aliases")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UniversesUniverseIdAliases([FromRoute] long universeId, [FromBody] Roblox.Api.Develop.Models.AliasRequest request)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/universes/{universeId}/aliases/{name}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1UniversesUniverseIdAliasesName([FromRoute] long universeId, [FromRoute] string name)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/universes/{universeId}/aliases/{name}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1UniversesUniverseIdAliasesName([FromRoute] long universeId, [FromRoute] string name, [FromBody] Roblox.Api.Develop.Models.AliasRequest request)
    {
        return StatusCode(501);
    }

}
