using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthenticationController : ControllerBase
{
    [HttpGet("v1/auth/metadata")]
    public ActionResult<Roblox.Authentication.Api.Models.AuthMetaDataResponse> getV1AuthMetadata()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/login")]
    public ActionResult<Roblox.Authentication.Api.Models.LoginResponse> postV1Login([FromBody] Roblox.Authentication.Api.Models.LoginRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/logout")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Logout()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/logoutfromallsessionsandreauthenticate")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Logoutfromallsessionsandreauthenticate()
    {
        return StatusCode(501);
    }

}
