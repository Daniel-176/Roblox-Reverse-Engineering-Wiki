using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ThemeConfigurationController : ControllerBase
{
    [HttpGet("v1/themes/types")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[System.String]> getV1ThemesTypes()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/themes/{consumerType}/{consumerId}")]
    public ActionResult<Roblox.AccountSettings.Api.ThemeConfigurationResponse> getV1ThemesConsumerTypeConsumerId([FromRoute] int consumerType, [FromRoute] string consumerId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/themes/{consumerType}/{consumerId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1ThemesConsumerTypeConsumerId([FromRoute] int consumerType, [FromRoute] long consumerId, [FromBody] Roblox.AccountSettings.Api.ThemeConfigurationRequest request)
    {
        return StatusCode(501);
    }

}
