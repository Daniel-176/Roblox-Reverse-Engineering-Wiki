using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PresenceController : ControllerBase
{
    [HttpPost("v1/presence/register-app-presence")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1PresenceRegister_app_presence([FromBody] Roblox.Presence.Api.Models.Request.RegisterAppPresenceRequest registerAppPresenceRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/presence/users")]
    public ActionResult<Roblox.Presence.Api.Models.Response.UserPresencesResponse> postV1PresenceUsers([FromBody] Roblox.Presence.Api.Models.Request.UserPresenceRequest userPresenceRequest)
    {
        return StatusCode(501);
    }

}
