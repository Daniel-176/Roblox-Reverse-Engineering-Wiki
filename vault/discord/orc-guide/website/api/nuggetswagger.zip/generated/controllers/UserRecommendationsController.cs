using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserRecommendationsController : ControllerBase
{
    [HttpGet("v1/recommended-users")]
    public ActionResult<Roblox.Friends.Api.Models.Response.UserRecommendationsResponse> getV1Recommended_users()
    {
        return StatusCode(501);
    }

}
