using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PluginsController : ControllerBase
{
    [HttpGet("v1/plugins")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Plugins.PluginResponse]> getV1Plugins([FromQuery] long[] pluginIds)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/plugins/{pluginId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1PluginsPluginId([FromRoute] long pluginId, [FromBody] Roblox.Develop.Api.UpdatePluginRequest request)
    {
        return StatusCode(501);
    }

}
