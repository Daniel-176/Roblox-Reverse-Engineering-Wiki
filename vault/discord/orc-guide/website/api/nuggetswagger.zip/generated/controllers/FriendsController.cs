using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FriendsController : ControllerBase
{
    [HttpPost("user/accept-friend-request")]
    public ActionResult<object> Friends_AcceptFriendRequest([FromQuery] int requesterUserId)
    {
        return StatusCode(501);
    }

    [HttpPost("user/decline-friend-request")]
    public ActionResult<object> Friends_DeclineFriendRequest([FromQuery] int requesterUserId)
    {
        return StatusCode(501);
    }

    [HttpPost("user/follow")]
    public ActionResult<object> Friends_Follow([FromQuery] long followedUserId)
    {
        return StatusCode(501);
    }

    [HttpGet("user/following-exists")]
    public ActionResult<object> Friends_FollowingExists([FromQuery] long userId, [FromQuery] long followerUserId)
    {
        return StatusCode(501);
    }

    [HttpGet("user/get-friendship-count")]
    public ActionResult<object> Friends_GetFriendshipCount([FromQuery] long userId)
    {
        return StatusCode(501);
    }

    [HttpPost("user/request-friendship")]
    public ActionResult<object> Friends_RequestFriendship([FromQuery] long recipientUserId)
    {
        return StatusCode(501);
    }

    [HttpPost("user/unfollow")]
    public ActionResult<object> Friends_UnFollow([FromQuery] long followedUserId)
    {
        return StatusCode(501);
    }

    [HttpPost("user/unfriend")]
    public ActionResult<object> Friends_UnFriend([FromQuery] long friendUserId)
    {
        return StatusCode(501);
    }

    [HttpGet("users/{userId:long}/friends")]
    public ActionResult<object> Friends_GetFriends([FromQuery] long userId, [FromQuery] int page)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/metadata")]
    public ActionResult<Roblox.Friends.Api.Models.Response.FriendsPageMetadataResponse> getV1Metadata([FromQuery] long targetUserId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/my/friends/count")]
    public ActionResult<Roblox.Friends.Api.FriendsCountResponse> getV1MyFriendsCount()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/my/friends/requests")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Web.Responses.Users.UserResponseV2]> getV1MyFriendsRequests([FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/user/friend-requests/count")]
    public ActionResult<Roblox.Friends.Api.PendingFriendRequestCountModel> getV1UserFriend_requestsCount()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/user/friend-requests/decline-all")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UserFriend_requestsDecline_all()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{requesterUserId}/accept-friend-request")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UsersRequesterUserIdAccept_friend_request([FromRoute] long requesterUserId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{requesterUserId}/decline-friend-request")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UsersRequesterUserIdDecline_friend_request([FromRoute] long requesterUserId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{targetUserId}/follow")]
    public ActionResult<Roblox.Friends.Api.CaptchaStatusResponseModel> postV1UsersTargetUserIdFollow([FromRoute] long targetUserId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{targetUserId}/followers")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Friends.Api.Models.Response.UserResponse]> getV1UsersTargetUserIdFollowers([FromRoute] long targetUserId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{targetUserId}/followers/count")]
    public ActionResult<Roblox.Friends.Api.FollowCountResponse> getV1UsersTargetUserIdFollowersCount([FromRoute] long targetUserId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{targetUserId}/followings")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Friends.Api.Models.Response.UserResponse]> getV1UsersTargetUserIdFollowings([FromRoute] long targetUserId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{targetUserId}/followings/count")]
    public ActionResult<Roblox.Friends.Api.FollowCountResponse> getV1UsersTargetUserIdFollowingsCount([FromRoute] long targetUserId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{targetUserId}/request-friendship")]
    public ActionResult<Roblox.Friends.Api.CaptchaStatusResponseModel> postV1UsersTargetUserIdRequest_friendship([FromRoute] long targetUserId, [FromBody] Roblox.Friends.Api.FriendshipRequestModel friendshipRequestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{targetUserId}/unfollow")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UsersTargetUserIdUnfollow([FromRoute] long targetUserId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{targetUserId}/unfriend")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UsersTargetUserIdUnfriend([FromRoute] long targetUserId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/friends")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Friends.Api.Models.Response.UserResponse]> getV1UsersUserIdFriends([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/friends/count")]
    public ActionResult<Roblox.Friends.Api.FriendsCountResponse> getV1UsersUserIdFriendsCount([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/friends/online")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Friends.Api.Models.Response.UserPresenceResponse]> getV1UsersUserIdFriendsOnline([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/friends/statuses")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Friends.Api.FriendStatusResponse]> getV1UsersUserIdFriendsStatuses([FromRoute] long userId, [FromQuery] long[] userIds)
    {
        return StatusCode(501);
    }

}
