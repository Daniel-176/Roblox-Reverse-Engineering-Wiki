using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class IdentityVerificationController : ControllerBase
{
    [HttpPost("v1/identity-verification/login")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Identity_verificationLogin([FromBody] Roblox.Authentication.Api.Models.Request.IdentityVerificationLoginRequest request)
    {
        return StatusCode(501);
    }

}
