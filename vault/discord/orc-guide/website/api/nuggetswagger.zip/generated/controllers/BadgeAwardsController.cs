using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BadgeAwardsController : ControllerBase
{
    [HttpDelete("v1/user/badges/{badgeId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1UserBadgesBadgeId([FromRoute] long badgeId)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/user/{userId}/badges/{badgeId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1UserUserIdBadgesBadgeId([FromRoute] long userId, [FromRoute] long badgeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/badges/awarded-dates")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Badges.Api.BadgeAwardResponse]> getV1UsersUserIdBadgesAwarded_dates([FromRoute] long userId, [FromQuery] long[] badgeIds)
    {
        return StatusCode(501);
    }

}
