using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OutfitsV3Controller : ControllerBase
{
    [HttpPost("v3/outfits/create")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV3OutfitsCreate([FromBody] Roblox.Api.Avatar.Models.OutfitUpdateModelV3 outfitUpdateModel)
    {
        return StatusCode(501);
    }

    [HttpPatch("v3/outfits/{userOutfitId}")]
    public ActionResult<Roblox.Api.Avatar.Models.OutfitModel> patchV3OutfitsUserOutfitId([FromRoute] long userOutfitId, [FromBody] Roblox.Api.Avatar.Models.OutfitUpdateModelV3 outfitUpdateModel)
    {
        return StatusCode(501);
    }

    [HttpGet("v3/outfits/{userOutfitId}/details")]
    public ActionResult<Roblox.Api.Avatar.Models.OutfitDetailsModelV2> getV3OutfitsUserOutfitIdDetails([FromRoute] long userOutfitId)
    {
        return StatusCode(501);
    }

    [HttpPost("v3/outfits/{userOutfitId}/update")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV3OutfitsUserOutfitIdUpdate([FromRoute] long userOutfitId, [FromBody] Roblox.Api.Avatar.Models.OutfitUpdateModelV3 outfitUpdateModel)
    {
        return StatusCode(501);
    }

}
