using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CountryRegionsController : ControllerBase
{
    [HttpGet("v1/country-regions")]
    public ActionResult<Roblox.Locale.Api.CountryRegionListResponse> getV1Country_regions([FromQuery] string? locale)
    {
        return StatusCode(501);
    }

}
