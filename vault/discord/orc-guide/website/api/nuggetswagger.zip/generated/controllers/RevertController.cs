using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RevertController : ControllerBase
{
    [HttpGet("v1/revert/account")]
    public ActionResult<Roblox.Authentication.Api.Models.RevertAccountInfoResponse> getV1RevertAccount([FromQuery] string ticket)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/revert/account")]
    public ActionResult<Roblox.Authentication.Api.Models.LoginResponse> postV1RevertAccount([FromBody] Roblox.Authentication.Api.Models.RevertAccountSubmitRequest request)
    {
        return StatusCode(501);
    }

}
