using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TagsController : ControllerBase
{
    [HttpGet("v1/tags")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.ItemConfiguration.Api.TagDetails]> getV1Tags([FromQuery] string[] tagIds)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/tags/prefix-search")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.ItemConfiguration.Api.TagDetails]> getV1TagsPrefix_search([FromQuery] string prefix, [FromQuery] int numberOfResults)
    {
        return StatusCode(501);
    }

}
