using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CdnProvidersController : ControllerBase
{
    [HttpGet("v1/cdnproviders/configuration")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.CdnProviders.Api.CdnConfiguration]> getV1CdnprovidersConfiguration([FromQuery] string? accessKey)
    {
        return StatusCode(501);
    }

}
