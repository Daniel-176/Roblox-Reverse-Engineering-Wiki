using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TransactionHistoryController : ControllerBase
{
    [HttpGet("v1/groups/{groupId}/transactions")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Economy.Api.Models.TransactionResponse]> getV1GroupsGroupIdTransactions([FromRoute] long groupId, [FromQuery] string transactionType, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/transactions")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Economy.Api.Models.TransactionResponse]> getV1UsersUserIdTransactions([FromRoute] long userId, [FromQuery] string transactionType, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

}
