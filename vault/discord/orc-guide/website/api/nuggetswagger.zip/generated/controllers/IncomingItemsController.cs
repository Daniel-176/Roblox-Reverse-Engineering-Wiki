using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class IncomingItemsController : ControllerBase
{
    [HttpGet("incoming-items/counts")]
    public ActionResult<object> IncomingItems_GetCounts()
    {
        return StatusCode(501);
    }

}
