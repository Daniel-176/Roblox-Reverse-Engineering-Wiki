using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PaymentMethodsController : ControllerBase
{
    [HttpGet("v1/paymentmethods")]
    public ActionResult<Roblox.Api.Billing.Models.Response.PaymentMethodsResponse> getV1Paymentmethods([FromQuery] int ap)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/paymentmethods/{paymentMethod}")]
    public ActionResult<Roblox.Api.Billing.Models.Response.GetPaymentMethodPageResponse> getV1PaymentmethodsPaymentMethod([FromRoute] string paymentMethod, [FromQuery] int ap)
    {
        return StatusCode(501);
    }

}
