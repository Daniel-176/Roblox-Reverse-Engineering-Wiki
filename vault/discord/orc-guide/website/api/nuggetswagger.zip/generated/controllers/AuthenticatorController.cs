using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthenticatorController : ControllerBase
{
    [HttpPost("v1/users/{userId}/challenges/authenticator/verify")]
    public ActionResult<Roblox.TwoStepVerification.Api.VerifyCodeResponse> postV1UsersUserIdChallengesAuthenticatorVerify([FromRoute] long userId, [FromBody] Roblox.TwoStepVerification.Api.VerifyCodeRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{userId}/configuration/authenticator/disable")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UsersUserIdConfigurationAuthenticatorDisable([FromRoute] long userId, [FromBody] Roblox.TwoStepVerification.Api.DisableTwoStepVerificationRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{userId}/configuration/authenticator/enable")]
    public ActionResult<Roblox.TwoStepVerification.Api.EnableAuthenticatorResponse> postV1UsersUserIdConfigurationAuthenticatorEnable([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{userId}/configuration/authenticator/enable-verify")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UsersUserIdConfigurationAuthenticatorEnable_verify([FromRoute] long userId, [FromBody] Roblox.TwoStepVerification.Api.EnableVerifyAuthenticatorRequest request)
    {
        return StatusCode(501);
    }

}
