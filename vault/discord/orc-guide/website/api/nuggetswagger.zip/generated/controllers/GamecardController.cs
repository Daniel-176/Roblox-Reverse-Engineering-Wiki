using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GamecardController : ControllerBase
{
    [HttpGet("v1/gamecard/metadata")]
    public ActionResult<Roblox.Api.Billing.Models.Response.GameCardMetadataResponse> getV1GamecardMetadata()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/gamecard/redeem")]
    public ActionResult<Roblox.Api.Billing.Models.Response.GamecardRedemptionResponse> postV1GamecardRedeem([FromBody] Roblox.Api.Billing.Models.Requests.GamecardRedemptionRequest redemptionRequest)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/gamecard/reverse")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GamecardReverse([FromBody] Roblox.Api.Billing.Models.Requests.GamecardReversalRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/gamecard/userdata")]
    public ActionResult<string> getV1GamecardUserdata()
    {
        return StatusCode(501);
    }

}
