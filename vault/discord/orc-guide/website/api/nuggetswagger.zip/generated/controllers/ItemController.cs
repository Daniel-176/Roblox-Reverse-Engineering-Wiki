using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ItemController : ControllerBase
{
    [HttpPost("v1/creations/get-asset-details")]
    public ActionResult<Roblox.ItemConfiguration.Api.AssetCreationsDetailsResponse[]> postV1CreationsGet_asset_details([FromBody] Roblox.ItemConfiguration.Api.AssetCreationsDetailsRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/creations/get-assets")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.ItemConfiguration.Api.AssetCreationsResponse]> getV1CreationsGet_assets([FromQuery] string assetType, [FromQuery] bool isArchived, [FromQuery] long groupId, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

}
