using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ChatController : ControllerBase
{
    [HttpPost("v2/add-to-conversation")]
    public ActionResult<Roblox.Chat.Api.Models.AddUserToConversationResponse> postV2Add_to_conversation([FromBody] Roblox.Chat.Api.Models.AddUsersToConversationRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/chat-settings")]
    public ActionResult<Roblox.Chat.Api.Models.ChatSettingsResponse> getV2Chat_settings()
    {
        return StatusCode(501);
    }

    [HttpGet("v2/get-conversations")]
    public ActionResult<Roblox.Chat.Api.Models.Conversation[]> getV2Get_conversations([FromQuery] long[] conversationIds)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/get-messages")]
    public ActionResult<Roblox.Chat.Api.Models.ChatMessage[]> getV2Get_messages([FromQuery] long conversationId, [FromQuery] int pageSize, [FromQuery] string? exclusiveStartMessageId)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/get-rollout-settings")]
    public ActionResult<Roblox.Chat.Api.Models.RolloutSettingsResponse> getV2Get_rollout_settings([FromQuery] string[] featureNames)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/get-unread-conversation-count")]
    public ActionResult<Roblox.Chat.Api.Models.UnreadConversationCountResponse> getV2Get_unread_conversation_count()
    {
        return StatusCode(501);
    }

    [HttpGet("v2/get-unread-conversations")]
    public ActionResult<Roblox.Chat.Api.Models.Conversation[]> getV2Get_unread_conversations([FromQuery] int pageNumber, [FromQuery] int pageSize)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/get-unread-messages")]
    public ActionResult<Roblox.Chat.Api.Models.MultigetConversationMessagesResponse[]> getV2Get_unread_messages([FromQuery] long[] conversationIds, [FromQuery] int pageSize)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/get-user-conversations")]
    public ActionResult<Roblox.Chat.Api.Models.Conversation[]> getV2Get_user_conversations([FromQuery] int pageNumber, [FromQuery] int pageSize)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/mark-as-read")]
    public ActionResult<Roblox.Chat.Api.Models.MarkAsReadResponse> postV2Mark_as_read([FromBody] Roblox.Chat.Api.Models.MarkAsReadRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/mark-as-seen")]
    public ActionResult<Roblox.Chat.Api.Models.MarkAsSeenResponse> postV2Mark_as_seen([FromBody] Roblox.Chat.Api.Models.MarkAsSeenRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/metadata")]
    public ActionResult<Roblox.Chat.Api.Models.ChatMetadataResponse> getV2Metadata()
    {
        return StatusCode(501);
    }

    [HttpGet("v2/multi-get-latest-messages")]
    public ActionResult<Roblox.Chat.Api.Models.MultigetConversationMessagesResponse[]> getV2Multi_get_latest_messages([FromQuery] long[] conversationIds, [FromQuery] int pageSize)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/remove-from-conversation")]
    public ActionResult<Roblox.Chat.Api.Models.RemoveUserFromConversationResponse> postV2Remove_from_conversation([FromBody] Roblox.Chat.Api.Models.RemoveUserFromConversationRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/rename-group-conversation")]
    public ActionResult<Roblox.Chat.Api.Models.RenameConversationResponse> postV2Rename_group_conversation([FromBody] Roblox.Chat.Api.Models.RenameGroupConversationRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/reset-conversation-universe")]
    public ActionResult<Roblox.Chat.Api.Models.UserVisibleStatusResponse> postV2Reset_conversation_universe([FromBody] Roblox.Chat.Api.Models.ResetConversationUniverseRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/send-game-link-message")]
    public ActionResult<Roblox.Chat.Api.Models.SendLinkChatResponse> postV2Send_game_link_message([FromBody] Roblox.Chat.Api.Models.SendGameLinkChatMessageRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/send-message")]
    public ActionResult<Roblox.Chat.Api.Models.SendPlainTextChatMessageResponse> postV2Send_message([FromBody] Roblox.Chat.Api.Models.SendPlainTextChatMessageRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/set-conversation-universe")]
    public ActionResult<Roblox.Chat.Api.Models.UserVisibleStatusResponse> postV2Set_conversation_universe([FromBody] Roblox.Chat.Api.Models.SetConversationUniverseRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/start-cloud-edit-conversation")]
    public ActionResult<Roblox.Chat.Api.Models.StartNewConversationResponse> postV2Start_cloud_edit_conversation([FromBody] Roblox.Chat.Api.Models.CreateCloudEditConversationRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/start-group-conversation")]
    public ActionResult<Roblox.Chat.Api.Models.StartNewConversationResponse> postV2Start_group_conversation([FromBody] Roblox.Chat.Api.Models.CreateGroupConversationRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/start-one-to-one-conversation")]
    public ActionResult<Roblox.Chat.Api.Models.StartNewConversationResponse> postV2Start_one_to_one_conversation([FromBody] Roblox.Chat.Api.Models.CreateOneToOneConversationRequest requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/update-user-typing-status")]
    public ActionResult<Roblox.Chat.Api.Models.UserVisibleStatusResponse> postV2Update_user_typing_status([FromBody] Roblox.Chat.Api.Models.UpdateUserTypingStatusRequest requestModel)
    {
        return StatusCode(501);
    }

}
