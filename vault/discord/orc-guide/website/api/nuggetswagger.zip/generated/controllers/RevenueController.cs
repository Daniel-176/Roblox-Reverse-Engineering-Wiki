using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RevenueController : ControllerBase
{
    [HttpGet("v1/groups/{groupId}/payout-restriction")]
    public ActionResult<Roblox.Groups.Api.GroupPayoutRestrictionResponse> getV1GroupsGroupIdPayout_restriction([FromRoute] long groupId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/payouts")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Groups.Api.GroupPayoutResponse]> getV1GroupsGroupIdPayouts([FromRoute] long groupId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/{groupId}/payouts")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GroupsGroupIdPayouts([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.PayoutRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/{groupId}/payouts/recurring")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1GroupsGroupIdPayoutsRecurring([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.PayoutRequest request)
    {
        return StatusCode(501);
    }

}
