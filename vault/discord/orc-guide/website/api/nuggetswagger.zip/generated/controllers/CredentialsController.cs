using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CredentialsController : ControllerBase
{
    [HttpGet("v1/credentials/verification")]
    public ActionResult<Roblox.Authentication.Api.Models.CanSendCredentialsVerificationMessageResponse> getV1CredentialsVerification([FromQuery] string? request_credentialType, [FromQuery] string? request_credentialValue, [FromQuery] string? request_password)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/credentials/verification")]
    public ActionResult<Roblox.Authentication.Api.Models.CanSendCredentialsVerificationMessageResponse> postV1CredentialsVerification([FromBody] Roblox.Authentication.Api.Models.SendCredentialsVerificationMessageRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/credentials/verification/send")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1CredentialsVerificationSend([FromBody] Roblox.Authentication.Api.Models.SendCredentialsVerificationMessageRequest request)
    {
        return StatusCode(501);
    }

}
