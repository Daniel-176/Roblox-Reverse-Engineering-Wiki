using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UniverseSettingsController : ControllerBase
{
    [HttpGet("v1/universes/{universeId}/configuration")]
    public ActionResult<Roblox.Api.Develop.Models.UniverseSettingsResponse> getV1UniversesUniverseIdConfiguration([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/universes/{universeId}/configuration")]
    public ActionResult<Roblox.Api.Develop.Models.UniverseSettingsResponse> patchV1UniversesUniverseIdConfiguration([FromRoute] long universeId, [FromBody] Roblox.Api.Develop.Models.UniverseSettingsRequest model)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/configuration/vip-servers")]
    public ActionResult<Roblox.Api.Develop.Models.PrivateServerDetailsResponse> getV1UniversesUniverseIdConfigurationVip_servers([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v2/universes/{universeId}/configuration")]
    public ActionResult<Roblox.Api.Develop.Models.UniverseSettingsResponseV2> patchV2UniversesUniverseIdConfiguration([FromRoute] long universeId, [FromBody] Roblox.Api.Develop.Models.UniverseSettingsRequestV2 model)
    {
        return StatusCode(501);
    }

}
