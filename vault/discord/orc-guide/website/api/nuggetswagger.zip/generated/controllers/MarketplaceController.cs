using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MarketplaceController : ControllerBase
{
    [HttpGet("marketplace/game-pass-product-info")]
    public ActionResult<object> Marketplace_GetGamePassProductInfo([FromQuery] long gamePassId)
    {
        return StatusCode(501);
    }

    [HttpGet("marketplace/productinfo")]
    public ActionResult<object> Marketplace_GetProductInfo([FromQuery] long assetId)
    {
        return StatusCode(501);
    }

}
