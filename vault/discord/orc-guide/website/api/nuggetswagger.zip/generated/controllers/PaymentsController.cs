using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PaymentsController : ControllerBase
{
    [HttpGet("v1/already-purchased-failure/info")]
    public ActionResult<Roblox.Api.Billing.Models.Response.FailurePageInfoResponse> getV1Already_purchased_failureInfo()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/user/payments")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Billing.Api.PaymentResponse]> getV1UserPayments([FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

}
