using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class EmailController : ControllerBase
{
    [HttpGet("v1/email")]
    public ActionResult<Roblox.AccountSettings.Api.EmailResponse> getV1Email()
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/email")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1Email([FromBody] Roblox.AccountSettings.Api.UpdateEmailRequest requestBody)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/email")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Email([FromBody] Roblox.AccountSettings.Api.UpdateEmailRequest requestBody)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/email/verify")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1EmailVerify([FromBody] Roblox.AccountSettings.Api.SendVerifyEmailRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{userId}/challenges/email/send-code")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UsersUserIdChallengesEmailSend_code([FromRoute] long userId, [FromBody] Roblox.TwoStepVerification.Api.SendCodeRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{userId}/challenges/email/verify")]
    public ActionResult<Roblox.TwoStepVerification.Api.VerifyCodeResponse> postV1UsersUserIdChallengesEmailVerify([FromRoute] long userId, [FromBody] Roblox.TwoStepVerification.Api.VerifyCodeRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{userId}/configuration/email/disable")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UsersUserIdConfigurationEmailDisable([FromRoute] long userId, [FromBody] Roblox.TwoStepVerification.Api.DisableTwoStepVerificationRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{userId}/configuration/email/enable")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UsersUserIdConfigurationEmailEnable([FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
