using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PrimaryGroupController : ControllerBase
{
    [HttpDelete("v1/user/groups/primary")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1UserGroupsPrimary()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/user/groups/primary")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UserGroupsPrimary([FromBody] Roblox.Groups.Api.PrimaryGroupRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/groups/primary/role")]
    public ActionResult<Roblox.Groups.Api.GroupMembershipDetailResponse> getV1UsersUserIdGroupsPrimaryRole([FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
