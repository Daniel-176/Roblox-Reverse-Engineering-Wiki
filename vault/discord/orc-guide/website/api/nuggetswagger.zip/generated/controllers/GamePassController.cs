using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GamePassController : ControllerBase
{
    [HttpPost("v1/game-passes/{gamePassId}/icon")]
    public ActionResult<Roblox.Publish.Api.UploadResponse> postV1Game_passesGamePassIdIcon([FromRoute] long gamePassId, [FromForm] object? request_files)
    {
        return StatusCode(501);
    }

}
