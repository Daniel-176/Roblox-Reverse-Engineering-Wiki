using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GroupSearchController : ControllerBase
{
    [HttpGet("v1/groups/search")]
    public ActionResult<Roblox.Groups.Api.GroupSearchPageResponse> getV1GroupsSearch([FromQuery] string keyword, [FromQuery] bool prioritizeExactMatch, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/search/lookup")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Groups.GroupBasicResponse]> getV1GroupsSearchLookup([FromQuery] string groupName)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/search/metadata")]
    public ActionResult<Roblox.Groups.Api.GroupSearchMetadataResponse> getV1GroupsSearchMetadata()
    {
        return StatusCode(501);
    }

}
