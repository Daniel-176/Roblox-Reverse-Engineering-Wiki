using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GameUpdateNotificationsController : ControllerBase
{
    [HttpPost("v1/gameUpdateNotifications/filter")]
    public IActionResult postV1GameUpdateNotificationsFilter([FromBody] string gameUpdateText)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/gameUpdateNotifications/{universeId}")]
    public ActionResult<Roblox.Api.Develop.Models.GameUpdateMessageModel[]> getV1GameUpdateNotificationsUniverseId([FromRoute] long universeId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/gameUpdateNotifications/{universeId}")]
    public ActionResult<Roblox.Api.Develop.Models.GameUpdateMessageModel> postV1GameUpdateNotificationsUniverseId([FromRoute] long universeId, [FromBody] string gameUpdateText)
    {
        return StatusCode(501);
    }

}
