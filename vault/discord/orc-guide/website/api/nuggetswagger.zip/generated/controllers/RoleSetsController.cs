using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RoleSetsController : ControllerBase
{
    [HttpPost("v1/groups/{groupId}/rolesets/create")]
    public ActionResult<Roblox.Groups.Api.GroupRoleResponse> postV1GroupsGroupIdRolesetsCreate([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.Models.Request.CreateRoleSetRequest request)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/groups/{groupId}/rolesets/{rolesetId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1GroupsGroupIdRolesetsRolesetId([FromRoute] long groupId, [FromRoute] long rolesetId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/groups/{groupId}/rolesets/{rolesetId}")]
    public ActionResult<Roblox.Groups.Api.GroupRoleResponse> patchV1GroupsGroupIdRolesetsRolesetId([FromRoute] long groupId, [FromRoute] long rolesetId, [FromBody] Roblox.Groups.Api.Models.Request.UpdateRoleSetRequest request)
    {
        return StatusCode(501);
    }

}
