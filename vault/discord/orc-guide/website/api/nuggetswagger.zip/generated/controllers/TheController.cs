using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TheController : ControllerBase
{
    [HttpGet("v1/universe-payout-history")]
    public ActionResult<Dictionary<string, Roblox.EngagementPayouts.Api.PayoutResponseModel>> getV1Universe_payout_history([FromQuery] long universeId, [FromQuery] string startDate, [FromQuery] string endDate)
    {
        return StatusCode(501);
    }

}
