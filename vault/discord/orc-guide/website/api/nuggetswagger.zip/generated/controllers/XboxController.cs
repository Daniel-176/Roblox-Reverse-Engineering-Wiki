using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class XboxController : ControllerBase
{
    [HttpGet("v1/xbox/connection")]
    public ActionResult<Roblox.Authentication.Api.Models.XboxConnectionModel> getV1XboxConnection()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/xbox/disconnect")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> postV1XboxDisconnect()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/xbox/get-login-consecutive-days")]
    public ActionResult<Roblox.Authentication.Api.Models.XboxLoginConsecutiveDaysResponse> getV1XboxGet_login_consecutive_days()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/xbox/translate")]
    public ActionResult<Roblox.Authentication.Api.Models.XboxCollectionsOfUserResponse> postV1XboxTranslate([FromBody] Roblox.Authentication.Api.Models.XboxTranslateRequest xboxTranslateRequest)
    {
        return StatusCode(501);
    }

}
