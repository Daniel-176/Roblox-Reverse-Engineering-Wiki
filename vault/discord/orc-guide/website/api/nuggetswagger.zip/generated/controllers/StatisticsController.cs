using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class StatisticsController : ControllerBase
{
    [HttpGet("v1/places/{placeId}/stats/developer-product-aggregation")]
    public ActionResult<Roblox.Api.Develop.Models.DeveloperProductAggregationResponse> getV1PlacesPlaceIdStatsDeveloper_product_aggregation([FromRoute] long placeId, [FromQuery] string timeFrame)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/places/{placeId}/stats/is-age-data-available")]
    public ActionResult<Roblox.Api.Develop.Models.Response.StatisticsAgeDataResponse> getV1PlacesPlaceIdStatsIs_age_data_available([FromRoute] long placeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/places/{placeId}/stats/{type}")]
    public ActionResult<Roblox.Api.Develop.Models.StatisticsResponse> getV1PlacesPlaceIdStatsType([FromRoute] long placeId, [FromRoute] string type, [FromQuery] string granularity, [FromQuery] string? divisionType, [FromQuery] string? startTime, [FromQuery] string? endTime)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/places/{placeId}/stats/{type}/legacy/flot")]
    public ActionResult<object> getV1PlacesPlaceIdStatsTypeLegacyFlot([FromRoute] long placeId, [FromRoute] string type, [FromQuery] string timeFrame, [FromQuery] string? divisionType, [FromQuery] string? startTime, [FromQuery] string? endTime)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/stats/creator-dashboard-metadata")]
    public ActionResult<Roblox.Api.Develop.Models.DevStatsCreatorDashboardMetadataResponse> getV1StatsCreator_dashboard_metadata()
    {
        return StatusCode(501);
    }

    [HttpGet("v1/universes/{universeId}/stats")]
    public ActionResult<Roblox.EconomyCreatorStats.Api.Models.StatisticsResponse> getV1UniversesUniverseIdStats([FromRoute] long universeId, [FromQuery] string request_type, [FromQuery] string request_startTime, [FromQuery] string request_endTime)
    {
        return StatusCode(501);
    }

}
