using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SocialAuthenticationController : ControllerBase
{
    [HttpGet("v1/social/connected-providers")]
    public ActionResult<Roblox.Authentication.Api.Models.SocialProvidersResponse> getV1SocialConnected_providers()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/social/{provider}/disconnect")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1SocialProviderDisconnect([FromRoute] string provider, [FromBody] Roblox.Authentication.Api.Models.SocialAuthenticationDisconnectRequest request)
    {
        return StatusCode(501);
    }

}
