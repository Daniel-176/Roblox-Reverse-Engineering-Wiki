using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ContentController : ControllerBase
{
    [HttpGet("v1/content")]
    public ActionResult<object> getV1Content([FromQuery] string hash)
    {
        return StatusCode(501);
    }

}
