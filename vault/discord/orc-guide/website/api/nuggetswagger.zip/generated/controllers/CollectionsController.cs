using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CollectionsController : ControllerBase
{
    [HttpDelete("v1/collections/items/{itemType}/{itemTargetId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1CollectionsItemsItemTypeItemTargetId([FromRoute] string itemType, [FromRoute] long itemTargetId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/collections/items/{itemType}/{itemTargetId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1CollectionsItemsItemTypeItemTargetId([FromRoute] string itemType, [FromRoute] long itemTargetId)
    {
        return StatusCode(501);
    }

}
