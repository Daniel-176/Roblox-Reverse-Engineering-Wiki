using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MetricsController : ControllerBase
{
    [HttpPost("v1/metrics/incrementcounterbyagent")]
    public IActionResult postV1MetricsIncrementcounterbyagent([FromBody] Roblox.Api.Billing.Models.Requests.IncrementUserAgentCounterRequest request)
    {
        return StatusCode(501);
    }

}
