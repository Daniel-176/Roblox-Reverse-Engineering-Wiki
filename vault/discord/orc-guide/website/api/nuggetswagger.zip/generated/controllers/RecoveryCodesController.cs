using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RecoveryCodesController : ControllerBase
{
    [HttpPost("v1/users/{userId}/challenges/recovery-codes/verify")]
    public ActionResult<Roblox.TwoStepVerification.Api.VerifyCodeResponse> postV1UsersUserIdChallengesRecovery_codesVerify([FromRoute] long userId, [FromBody] Roblox.TwoStepVerification.Api.VerifyCodeRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/recovery-codes")]
    public ActionResult<Roblox.TwoStepVerification.Api.RecoveryCodesStatusResponse> getV1UsersUserIdRecovery_codes([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{userId}/recovery-codes/clear")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UsersUserIdRecovery_codesClear([FromRoute] long userId, [FromBody] Roblox.TwoStepVerification.Api.ClearRecoveryCodesRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/users/{userId}/recovery-codes/regenerate")]
    public ActionResult<Roblox.TwoStepVerification.Api.RegenerateRecoveryCodesResponse> postV1UsersUserIdRecovery_codesRegenerate([FromRoute] long userId, [FromBody] Roblox.TwoStepVerification.Api.RegenerateRecoveryCodesRequest request)
    {
        return StatusCode(501);
    }

}
