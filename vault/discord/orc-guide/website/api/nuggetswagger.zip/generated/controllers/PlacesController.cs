using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PlacesController : ControllerBase
{
    [HttpPatch("v1/places/{placeId}")]
    public ActionResult<Roblox.Api.Develop.Models.PlaceModel> patchV1PlacesPlaceId([FromRoute] long placeId, [FromBody] Roblox.Api.Develop.Models.PlaceConfigurationModel configuration)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/places/{placeId}")]
    public ActionResult<Roblox.Api.Develop.Models.PlaceModel> postV1PlacesPlaceId([FromRoute] long placeId, [FromBody] Roblox.Api.Develop.Models.PlaceConfigurationModel configuration)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/places/{placeId}/compatibilities")]
    public ActionResult<Roblox.Api.Develop.Models.Response.PlaceCompatibilitiesResponse> getV1PlacesPlaceIdCompatibilities([FromRoute] long placeId)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/places/{placeId}")]
    public ActionResult<Roblox.Api.Develop.Models.PlaceModelV2> getV2PlacesPlaceId([FromRoute] long placeId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v2/places/{placeId}")]
    public ActionResult<Roblox.Api.Develop.Models.PlaceModelV2> patchV2PlacesPlaceId([FromRoute] long placeId, [FromBody] Roblox.Api.Develop.Models.PlaceConfigurationModelV2 configuration)
    {
        return StatusCode(501);
    }

}
