using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AccountPinController : ControllerBase
{
    [HttpDelete("v1/account/pin")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> deleteV1AccountPin([FromBody] Roblox.Authentication.Api.Models.AccountPinRequest requestBody)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/account/pin")]
    public ActionResult<Roblox.Authentication.Api.Models.AccountPinStatusResponse> getV1AccountPin()
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/account/pin")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> patchV1AccountPin([FromBody] Roblox.Authentication.Api.Models.AccountPinRequest requestBody)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/account/pin")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> postV1AccountPin([FromBody] Roblox.Authentication.Api.Models.AccountPinRequest requestBody)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/account/pin/lock")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiSuccessResponse> postV1AccountPinLock()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/account/pin/unlock")]
    public ActionResult<Roblox.Authentication.Api.Models.AccountPinResponse> postV1AccountPinUnlock([FromBody] Roblox.Authentication.Api.Models.AccountPinRequest requestBody)
    {
        return StatusCode(501);
    }

}
