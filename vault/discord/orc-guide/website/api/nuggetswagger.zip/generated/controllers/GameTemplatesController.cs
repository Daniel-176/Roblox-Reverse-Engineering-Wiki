using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GameTemplatesController : ControllerBase
{
    [HttpGet("v1/gametemplates")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Api.Develop.Models.GameTemplateModel]> getV1Gametemplates()
    {
        return StatusCode(501);
    }

}
