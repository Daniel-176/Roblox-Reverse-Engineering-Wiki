using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ThumbnailMetricsController : ControllerBase
{
    [HttpPost("v1/thumbnails/load")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1ThumbnailsLoad([FromBody] Roblox.Metrics.Api.RecordThumbnailLoadRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/thumbnails/metadata")]
    public ActionResult<Roblox.Metrics.Api.ThumbnailLoadMetadataResponse> getV1ThumbnailsMetadata()
    {
        return StatusCode(501);
    }

}
