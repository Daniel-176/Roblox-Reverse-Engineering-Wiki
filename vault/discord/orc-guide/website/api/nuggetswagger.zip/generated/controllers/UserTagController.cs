using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserTagController : ControllerBase
{
    [HttpPost("v1/user/get-tags")]
    public ActionResult<Roblox.Contacts.Api.Response.GetUserTagsResponseModel[]> postV1UserGet_tags([FromBody] Roblox.Contacts.Api.Request.GetUserTagsRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/user/set-pending-tag")]
    public ActionResult<Roblox.Contacts.Api.Response.SetUserTagResponseModel> postV1UserSet_pending_tag([FromBody] Roblox.Contacts.Api.Request.SetUserTagRequestModel requestModel)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/user/tag")]
    public ActionResult<Roblox.Contacts.Api.Response.SetUserTagResponseModel> postV1UserTag([FromBody] Roblox.Contacts.Api.Request.SetUserTagRequestModel requestModel)
    {
        return StatusCode(501);
    }

}
