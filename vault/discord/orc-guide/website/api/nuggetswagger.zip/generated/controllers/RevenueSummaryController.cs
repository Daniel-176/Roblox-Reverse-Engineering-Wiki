using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RevenueSummaryController : ControllerBase
{
    [HttpGet("v1/groups/{groupId}/revenue/summary/{timeFrame}")]
    public ActionResult<Roblox.Economy.Api.RevenueSummaryResponse> getV1GroupsGroupIdRevenueSummaryTimeFrame([FromRoute] long groupId, [FromRoute] string timeFrame)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/revenue/summary/{timeFrame}")]
    public ActionResult<Roblox.Economy.Api.RevenueSummaryResponse> getV1UsersUserIdRevenueSummaryTimeFrame([FromRoute] long userId, [FromRoute] string timeFrame)
    {
        return StatusCode(501);
    }

}
