using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TwoStepVerificationController : ControllerBase
{
    [HttpGet("v1/twostepverification/metadata")]
    public ActionResult<Roblox.Authentication.Api.Models.TwoStepVerificationMetadataResponse> getV1TwostepverificationMetadata()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/twostepverification/resend")]
    public ActionResult<Roblox.Authentication.Api.Models.TwoStepVerificationSentResponse> postV1TwostepverificationResend([FromBody] Roblox.Authentication.Api.Models.TwoStepVerificationTicketRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/twostepverification/verify")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1TwostepverificationVerify([FromBody] Roblox.Authentication.Api.Models.TwoStepVerificationVerifyRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v3/users/{userId}/two-step-verification/login")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV3UsersUserIdTwo_step_verificationLogin([FromRoute] long userId, [FromBody] Roblox.Authentication.Api.TwoStepVerificationLoginRequest request)
    {
        return StatusCode(501);
    }

}
