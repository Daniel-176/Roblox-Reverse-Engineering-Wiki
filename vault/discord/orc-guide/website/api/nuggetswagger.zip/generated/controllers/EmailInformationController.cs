using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class EmailInformationController : ControllerBase
{
    [HttpPost("v1/email/verify")]
    public ActionResult<Roblox.AccountInformation.Api.Models.VerifyEmailResponse> postV1EmailVerify([FromBody] Roblox.AccountInformation.Api.Models.VerifyEmailRequest request)
    {
        return StatusCode(501);
    }

}
