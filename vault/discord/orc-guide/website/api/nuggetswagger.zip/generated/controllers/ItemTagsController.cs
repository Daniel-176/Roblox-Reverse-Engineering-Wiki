using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ItemTagsController : ControllerBase
{
    [HttpGet("v1/item-tags")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.ItemConfiguration.Api.ItemWithTags]> getV1Item_tags([FromQuery] string[] itemIds)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/item-tags")]
    public ActionResult<Roblox.ItemConfiguration.Api.ItemTagDetails> postV1Item_tags([FromBody] Roblox.ItemConfiguration.Api.CreateItemTagRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/item-tags/metadata")]
    public ActionResult<Roblox.ItemConfiguration.Api.ItemTagsMetadataResponse> getV1Item_tagsMetadata()
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/item-tags/{itemTagId}")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1Item_tagsItemTagId([FromRoute] string itemTagId)
    {
        return StatusCode(501);
    }

}
