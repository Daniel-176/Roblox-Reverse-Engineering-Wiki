using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DeveloperProductsController : ControllerBase
{
    [HttpGet("v1/developer-products/icons")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Thumbnails.ThumbnailResponse]> getV1Developer_productsIcons([FromQuery] long[] developerProductIds, [FromQuery] string? size, [FromQuery] int format, [FromQuery] bool isCircular)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/universes/{universeId}/developerproducts")]
    public ActionResult<Roblox.Api.Develop.DeveloperProductResponse> postV1UniversesUniverseIdDeveloperproducts([FromRoute] long universeId, [FromQuery] string name, [FromQuery] string description, [FromQuery] long priceInRobux, [FromQuery] long iconImageAssetId)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/universes/{universeId}/developerproducts/{productId}/update")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1UniversesUniverseIdDeveloperproductsProductIdUpdate([FromRoute] long universeId, [FromRoute] long productId, [FromBody] Roblox.Api.Develop.Models.DeveloperProductsUpdateModel updateInfo)
    {
        return StatusCode(501);
    }

}
