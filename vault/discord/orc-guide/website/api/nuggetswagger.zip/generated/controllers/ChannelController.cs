using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ChannelController : ControllerBase
{
    [HttpGet("v2/user-channel")]
    public ActionResult<Roblox.ClientSettings.Api.Models.Response.UserChannelResponse> getV2User_channel()
    {
        return StatusCode(501);
    }

    [HttpGet("v2/user-channel")]
    public ActionResult<Roblox.ClientSettings.Api.Models.Response.UserChannelResponse> getV2User_channel([FromQuery] string? binaryType)
    {
        return StatusCode(501);
    }

}
