using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AvatarAssetsUploadController : ControllerBase
{
    [HttpPost("v1/avatar-assets/{assetType}/upload-captcha-test")]
    public ActionResult<Roblox.ItemConfiguration.Api.AvatarAssetUploadCaptchaCheckResponse> postV1Avatar_assetsAssetTypeUpload_captcha_test([FromRoute] string assetType, [FromQuery] long groupId, [FromBody] Roblox.Web.Captcha.Models.Request.CaptchaTokenRequest captchaTokenRequest)
    {
        return StatusCode(501);
    }

}
