using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BundleController : ControllerBase
{
    [HttpGet("v1/assets/{assetId}/bundles")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Catalog.Api.BundleDetailsModel]> getV1AssetsAssetIdBundles([FromRoute] long assetId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/bundles/details")]
    public ActionResult<Roblox.Catalog.Api.BundleDetailsModel[]> getV1BundlesDetails([FromQuery] long[] bundleIds)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/bundles/{bundleId}/details")]
    public ActionResult<Roblox.Catalog.Api.BundleDetailsModel> getV1BundlesBundleIdDetails([FromRoute] long bundleId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/bundles/{bundleId}/recommendations")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Catalog.Api.BundleDetailsModel]> getV1BundlesBundleIdRecommendations([FromRoute] long bundleId, [FromQuery] int numItems)
    {
        return StatusCode(501);
    }

    [HttpPost("v1/bundles/{bundleId}/unpack")]
    public IActionResult postV1BundlesBundleIdUnpack([FromRoute] long bundleId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/bundles")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Catalog.Api.OwnedBundleModel]> getV1UsersUserIdBundles([FromRoute] long userId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/bundles/{bundleType}")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Catalog.Api.OwnedBundleModel]> getV1UsersUserIdBundlesBundleType([FromRoute] long userId, [FromRoute] string bundleType, [FromQuery] int limit, [FromQuery] string? cursor, [FromQuery] string? sortOrder)
    {
        return StatusCode(501);
    }

}
