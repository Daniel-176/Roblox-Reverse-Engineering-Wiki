using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TradeSettingsController : ControllerBase
{
    [HttpGet("v1/trade-privacy")]
    public ActionResult<Roblox.AccountSettings.Api.TradePrivacyResponse> getV1Trade_privacy()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/trade-privacy")]
    public ActionResult<Roblox.AccountSettings.Api.TradePrivacyUpdateResponse> postV1Trade_privacy([FromBody] Roblox.AccountSettings.Api.UpdateTradePrivacyRequest model)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/trade-value")]
    public ActionResult<Roblox.AccountSettings.Api.TradeValueResponse> getV1Trade_value()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/trade-value")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Trade_value([FromBody] Roblox.AccountSettings.Api.TradeValueRequest model)
    {
        return StatusCode(501);
    }

}
