using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class VerifiedFriendsController : ControllerBase
{
    [HttpGet("v1/friends/verified/nearby/code/{code}")]
    public ActionResult<Roblox.Friends.Api.Models.Response.NearbyFriendsDataResponseModel> getV1FriendsVerifiedNearbyCodeCode([FromRoute] string code)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/friends/verified/nearby/health")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> getV1FriendsVerifiedNearbyHealth()
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/friends/verified/nearby/session")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1FriendsVerifiedNearbySession()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/friends/verified/nearby/session")]
    public ActionResult<Roblox.Friends.Api.Models.Response.NearbySessionResponseModel> postV1FriendsVerifiedNearbySession()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/friends/verified/nearby/{code}/redeem")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1FriendsVerifiedNearbyCodeRedeem([FromRoute] string code)
    {
        return StatusCode(501);
    }

    [HttpDelete("v1/friends/verified/qr/session")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> deleteV1FriendsVerifiedQrSession()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/friends/verified/qr/session")]
    public ActionResult<Roblox.Friends.Api.Models.Response.QRSessionResponseModel> postV1FriendsVerifiedQrSession()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/friends/verified/qr/{code}/redeem")]
    public ActionResult<Roblox.Friends.Api.Models.Response.QRFriendsRedeemResponseModel> postV1FriendsVerifiedQrCodeRedeem([FromRoute] string code)
    {
        return StatusCode(501);
    }

}
