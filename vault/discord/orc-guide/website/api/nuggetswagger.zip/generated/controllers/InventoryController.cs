using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class InventoryController : ControllerBase
{
    [HttpGet("v1/users/{userId}/assets/collectibles")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Inventory.Api.Models.CollectibleUserAssetModel]> getV1UsersUserIdAssetsCollectibles([FromRoute] long userId, [FromQuery] string? assetType, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/can-view-inventory")]
    public ActionResult<Roblox.Inventory.Api.Models.CanViewInventoryResponse> getV1UsersUserIdCan_view_inventory([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/categories")]
    public ActionResult<Roblox.Inventory.Api.CategoriesModel> getV1UsersUserIdCategories([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/categories/favorites")]
    public ActionResult<Roblox.Inventory.Api.CategoriesModel> getV1UsersUserIdCategoriesFavorites([FromRoute] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/inventory/{assetType}")]
    public ActionResult<Roblox.Inventory.Api.Models.InventoryPageResponse> getV1UsersUserIdInventoryAssetType([FromRoute] long userId, [FromRoute] string assetType, [FromQuery] int pageNumber, [FromQuery] int itemsPerPage, [FromQuery] string? keyword)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/users/{userId}/items/{itemType}/{itemTargetId}")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Inventory.Api.Models.IItemModel]> getV1UsersUserIdItemsItemTypeItemTargetId([FromRoute] long userId, [FromRoute] string itemType, [FromRoute] long itemTargetId)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/users/{userId}/inventory")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Inventory.Api.V2.UserAssetItemModelV2]> getV2UsersUserIdInventory([FromRoute] long userId, [FromQuery] object[] assetTypes, [FromQuery] int limit, [FromQuery] string? cursor, [FromQuery] string? sortOrder)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/users/{userId}/inventory/{assetTypeId}")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Inventory.Api.Models.InventoryItemModel]> getV2UsersUserIdInventoryAssetTypeId([FromRoute] long userId, [FromRoute] int assetTypeId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

}
