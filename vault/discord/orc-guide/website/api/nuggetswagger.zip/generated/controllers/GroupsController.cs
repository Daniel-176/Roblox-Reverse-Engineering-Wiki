using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GroupsController : ControllerBase
{
    [HttpGet("groups/{groupId}")]
    public ActionResult<object> Groups_GetGroupInfo([FromQuery] int groupId)
    {
        return StatusCode(501);
    }

    [HttpGet("groups/{groupId}/allies")]
    public ActionResult<object> Groups_GetAllies([FromQuery] int groupId, [FromQuery] int page)
    {
        return StatusCode(501);
    }

    [HttpGet("groups/{groupId}/enemies")]
    public ActionResult<object> Groups_GetEnemies([FromQuery] int groupId, [FromQuery] int page)
    {
        return StatusCode(501);
    }

    [HttpGet("users/{userId:long}/groups")]
    public ActionResult<object> Groups_GetGroups([FromQuery] long userId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/configuration/metadata")]
    public ActionResult<Roblox.Groups.Api.GroupConfigurationDisplayOptionsResponse> getV1GroupsConfigurationMetadata()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/create")]
    public ActionResult<Roblox.Web.Responses.Groups.GroupResponseV2> postV1GroupsCreate([FromForm] string? request_name, [FromForm] string? request_description, [FromForm] bool request_publicGroup, [FromForm] bool request_buildersClubMembersOnly, [FromForm] object? request_files)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/groups/icon")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1GroupsIcon([FromQuery] long groupId, [FromForm] object? request_files)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/metadata")]
    public ActionResult<Roblox.Groups.Api.GroupsDisplayOptionsResponse> getV1GroupsMetadata()
    {
        return StatusCode(501);
    }

    [HttpPost("v1/groups/policies")]
    public ActionResult<Roblox.Groups.Api.GroupPoliciesResponse> postV1GroupsPolicies([FromBody] Roblox.Groups.Api.GroupPolicyRequest groupPolicyRequest)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}")]
    public ActionResult<Roblox.Groups.Api.GroupDetailResponse> getV1GroupsGroupId([FromRoute] long groupId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/audit-log")]
    public ActionResult<Roblox.Groups.Api.GroupAuditLogPageResponse[Roblox.Groups.Api.Models.Response.GroupAuditLogResponseItem]> getV1GroupsGroupIdAudit_log([FromRoute] long groupId, [FromQuery] string? actionType, [FromQuery] long userId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/groups/{groupId}/description")]
    public ActionResult<Roblox.Groups.Api.GroupDescriptionResponse> patchV1GroupsGroupIdDescription([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.UpdateGroupDescriptionRequest request)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/groups/{groupId}/name")]
    public ActionResult<Roblox.Groups.Api.UpdateGroupNameResponse> patchV1GroupsGroupIdName([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.UpdateGroupNameRequest request)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/name-history")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Groups.Api.Models.Response.GroupNameHistoryResponseItem]> getV1GroupsGroupIdName_history([FromRoute] long groupId, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/settings")]
    public ActionResult<Roblox.Groups.Api.GroupSettingsResponse> getV1GroupsGroupIdSettings([FromRoute] long groupId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/groups/{groupId}/settings")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1GroupsGroupIdSettings([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.UpdateGroupSettingsRequest request)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/groups/{groupId}/status")]
    public ActionResult<Roblox.Groups.Api.ShoutResponse> patchV1GroupsGroupIdStatus([FromRoute] long groupId, [FromBody] Roblox.Groups.Api.PostGroupStatusRequest statusRequest)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/universes")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiPageResponse[Roblox.Api.Develop.Models.UniverseModel]> getV1GroupsGroupIdUniverses([FromRoute] long groupId, [FromQuery] bool isArchived, [FromQuery] string? sortOrder, [FromQuery] int limit, [FromQuery] string? cursor)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/groups")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Web.Responses.Groups.GroupResponseV2]> getV2Groups([FromQuery] long[] groupIds)
    {
        return StatusCode(501);
    }

    [HttpGet("v2/users/{userId}/groups/roles")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Groups.Api.GroupMembershipResponse]> getV2UsersUserIdGroupsRoles([FromRoute] long userId)
    {
        return StatusCode(501);
    }

}
