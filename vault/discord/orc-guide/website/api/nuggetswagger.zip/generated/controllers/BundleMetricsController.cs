using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BundleMetricsController : ControllerBase
{
    [HttpPost("v1/bundle-metrics/report")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> postV1Bundle_metricsReport([FromBody] Roblox.Metrics.Api.RecordBundleLoadRequest request)
    {
        return StatusCode(501);
    }

}
