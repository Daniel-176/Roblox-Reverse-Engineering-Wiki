using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PluginController : ControllerBase
{
    [HttpPost("v1/plugins/{pluginId}/icon")]
    public ActionResult<Roblox.Publish.Api.UploadResponse> postV1PluginsPluginIdIcon([FromRoute] long pluginId, [FromForm] object? request_files)
    {
        return StatusCode(501);
    }

}
