using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GameThumbnailsController : ControllerBase
{
    [HttpPost("v1/games/{gameId}/thumbnail/image")]
    public ActionResult<Roblox.Publish.Api.UploadResponse> postV1GamesGameIdThumbnailImage([FromRoute] long gameId, [FromForm] object? request_files)
    {
        return StatusCode(501);
    }

}
