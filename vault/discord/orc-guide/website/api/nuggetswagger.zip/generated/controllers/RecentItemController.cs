using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RecentItemController : ControllerBase
{
    [HttpGet("v1/recent-items/{recentItemListType}/list")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiLegacyPageResponse[Roblox.Api.Avatar.Models.RecentItemModel]> getV1Recent_itemsRecentItemListTypeList([FromRoute] string recentItemListType)
    {
        return StatusCode(501);
    }

}
