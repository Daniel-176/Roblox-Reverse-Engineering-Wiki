using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PermissionsController : ControllerBase
{
    [HttpGet("v1/groups/{groupId}/roles/guest/permissions")]
    public ActionResult<Roblox.Groups.Api.GroupPermissionsResponse> getV1GroupsGroupIdRolesGuestPermissions([FromRoute] long groupId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/roles/permissions")]
    public ActionResult<Roblox.Web.WebAPI.Models.ApiArrayResponse[Roblox.Groups.Api.GroupPermissionsResponse]> getV1GroupsGroupIdRolesPermissions([FromRoute] long groupId)
    {
        return StatusCode(501);
    }

    [HttpGet("v1/groups/{groupId}/roles/{roleSetId}/permissions")]
    public ActionResult<Roblox.Groups.Api.GroupPermissionsResponse> getV1GroupsGroupIdRolesRoleSetIdPermissions([FromRoute] long groupId, [FromRoute] int roleSetId)
    {
        return StatusCode(501);
    }

    [HttpPatch("v1/groups/{groupId}/roles/{roleSetId}/permissions")]
    public ActionResult<Roblox.Web.WebAPI.ApiEmptyResponseModel> patchV1GroupsGroupIdRolesRoleSetIdPermissions([FromRoute] long groupId, [FromRoute] int roleSetId, [FromBody] Roblox.Groups.Api.UpdatePermissionsRequest updatePermissionsRequest)
    {
        return StatusCode(501);
    }

}
