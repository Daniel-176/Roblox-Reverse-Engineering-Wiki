using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CdnController : ControllerBase
{
    [HttpGet("v1/installer-cdns")]
    public IActionResult getV1Installer_cdns()
    {
        return StatusCode(501);
    }

}
