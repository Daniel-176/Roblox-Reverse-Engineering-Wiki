using Microsoft.AspNetCore.Mvc;

namespace Roblox.Website.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PasswordsV2Controller : ControllerBase
{
    [HttpPost("v2/passwords/reset")]
    public ActionResult<ApiEmptyResponseModel> POST_v2_passwords_reset([FromBody] PasswordResetModel request)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/passwords/reset/send")]
    public ActionResult<SendResetPasswordResponse> POST_v2_passwords_reset_send([FromBody] SendResetPasswordRequest request)
    {
        return StatusCode(501);
    }

    [HttpPost("v2/passwords/reset/verify")]
    public ActionResult<PasswordResetVerificationResponse> POST_v2_passwords_reset_verify([FromBody] PasswordResetVerificationRequest request)
    {
        return StatusCode(501);
    }

}
