using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class MarkInteractedRequestModel
{
    public string? eventId { get; set; }
}
