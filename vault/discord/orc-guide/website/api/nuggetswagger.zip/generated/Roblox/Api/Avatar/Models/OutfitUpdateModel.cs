using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class OutfitUpdateModel
{
    public string? name { get; set; }
    public Roblox.Api.Avatar.Models.BodyColorsModel bodyColors { get; set; }
    public long[] assetIds { get; set; }
    public Roblox.Web.Responses.Avatar.ScaleModel scale { get; set; }
    public string? playerAvatarType { get; set; }
}
