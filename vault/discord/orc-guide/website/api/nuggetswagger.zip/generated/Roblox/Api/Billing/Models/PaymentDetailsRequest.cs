using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class PaymentDetailsRequest
{
    public Roblox.Api.Billing.Models.PaymentRequest payment { get; set; }
    public Roblox.Api.Billing.Models.PaymentMethodSumRequest payment_method_sum { get; set; }
    public Roblox.Api.Billing.Models.XsollaBalanceSumRequest xsolla_balance_sum { get; set; }
    public Roblox.Api.Billing.Models.PayoutRequest payout { get; set; }
    public Roblox.Api.Billing.Models.XsollaFeeRequest xsolla_fee { get; set; }
    public Roblox.Api.Billing.Models.PaymentMethodFeeRequest payment_method_fee { get; set; }
    public Roblox.Api.Billing.Models.VatRequest vat { get; set; }
    public Roblox.Api.Billing.Models.SalesTaxRequest sales_tax { get; set; }
    public string? payout_currency_rate { get; set; }
}
