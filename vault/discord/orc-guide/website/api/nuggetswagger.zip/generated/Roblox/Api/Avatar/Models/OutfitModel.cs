using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class OutfitModel
{
    public long id { get; set; }
    public string? name { get; set; }
    public bool isEditable { get; set; }
}
