using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class AssetModelV2
{
    public long id { get; set; }
    public string? name { get; set; }
    public Roblox.Api.Avatar.Models.AssetTypeModel assetType { get; set; }
    public long currentVersionId { get; set; }
    public Roblox.Api.Avatar.Models.AssetMetaModelV1 meta { get; set; }
}
