using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class UnreadStreamNotificationsModel
{
    public long unreadNotifications { get; set; }
    public string? statusMessage { get; set; }
}
