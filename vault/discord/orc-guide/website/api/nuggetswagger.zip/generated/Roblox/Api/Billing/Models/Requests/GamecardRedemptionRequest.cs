using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Requests;

public class GamecardRedemptionRequest
{
    public string? pinCode { get; set; }
    public string? captchaToken { get; set; }
    public string? captchaProvider { get; set; }
}
