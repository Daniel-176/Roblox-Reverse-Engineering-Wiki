using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class GameTemplateModel
{
    public string? gameTemplateType { get; set; }
    public bool hasTutorials { get; set; }
    public Roblox.Api.Develop.Models.UniverseModel universe { get; set; }
}
