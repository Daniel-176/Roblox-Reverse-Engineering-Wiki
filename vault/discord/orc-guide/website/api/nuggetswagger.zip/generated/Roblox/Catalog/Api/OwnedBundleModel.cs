using System;
using System.Collections.Generic;

namespace Roblox.Catalog.Api;

public class OwnedBundleModel
{
    public long id { get; set; }
    public string? name { get; set; }
    public string? bundleType { get; set; }
    public Roblox.Catalog.Api.BundleCreatorModel creator { get; set; }
}
