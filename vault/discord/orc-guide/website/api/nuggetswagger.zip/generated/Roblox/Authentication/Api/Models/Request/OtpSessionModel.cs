using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models.Request;

public class OtpSessionModel
{
    public string? otpSessionToken { get; set; }
    public string? otpContactType { get; set; }
}
