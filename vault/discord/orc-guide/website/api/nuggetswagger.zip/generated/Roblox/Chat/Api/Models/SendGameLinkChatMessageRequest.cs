using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class SendGameLinkChatMessageRequest
{
    public long universeId { get; set; }
    public long conversationId { get; set; }
    public string[] decorators { get; set; }
}
