using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class MarkAsReadRequest
{
    public long conversationId { get; set; }
    public string? endMessageId { get; set; }
}
