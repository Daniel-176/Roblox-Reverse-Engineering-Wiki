using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class TradeValueResponse
{
    public string? tradeValue { get; set; }
}
