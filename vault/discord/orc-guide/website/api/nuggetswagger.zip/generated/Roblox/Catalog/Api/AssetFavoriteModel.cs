using System;
using System.Collections.Generic;

namespace Roblox.Catalog.Api;

public class AssetFavoriteModel
{
    public long assetId { get; set; }
    public long userId { get; set; }
    public DateTime? created { get; set; }
}
