using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class PrivateServerDetailsResponse
{
    public bool isEnabled { get; set; }
    public long price { get; set; }
    public long activeServersCount { get; set; }
    public long activeSubscriptionsCount { get; set; }
}
