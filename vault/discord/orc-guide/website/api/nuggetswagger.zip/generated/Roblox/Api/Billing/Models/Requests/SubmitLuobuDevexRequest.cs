using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Requests;

public class SubmitLuobuDevexRequest
{
    public string? firstName { get; set; }
    public string? lastName { get; set; }
    public string? email { get; set; }
    public double amount { get; set; }
}
