using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class UnreadConversationCountResponse
{
    public long count { get; set; }
}
