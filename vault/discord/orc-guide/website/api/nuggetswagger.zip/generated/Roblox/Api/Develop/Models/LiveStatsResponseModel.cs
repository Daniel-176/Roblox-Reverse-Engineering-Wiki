using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class LiveStatsResponseModel
{
    public int totalPlayerCount { get; set; }
    public object? playerCountsByDeviceType { get; set; }
    public int gameCount { get; set; }
}
