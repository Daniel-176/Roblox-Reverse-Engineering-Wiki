using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class RenameGroupConversationRequest
{
    public long conversationId { get; set; }
    public string? newTitle { get; set; }
}
