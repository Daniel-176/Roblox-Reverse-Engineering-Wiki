using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class RenameConversationResponse
{
    public string? conversationTitle { get; set; }
    public string? resultType { get; set; }
    public Roblox.Chat.Api.Models.ConversationTitle title { get; set; }
    public string? statusMessage { get; set; }
}
