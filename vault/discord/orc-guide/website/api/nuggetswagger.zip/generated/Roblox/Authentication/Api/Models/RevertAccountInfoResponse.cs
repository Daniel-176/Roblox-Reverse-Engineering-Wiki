using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class RevertAccountInfoResponse
{
    public bool isTwoStepVerificationEnabled { get; set; }
    public bool isEmailVerified { get; set; }
    public bool isEmailChanged { get; set; }
    public bool isPhoneVerified { get; set; }
    public long userId { get; set; }
    public string? username { get; set; }
    public string? ticket { get; set; }
}
