using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class InventoryPrivacyUpdateResponse
{
    public int inventoryPrivacy { get; set; }
    public int tradePrivacy { get; set; }
    public int privacySettingResponse { get; set; }
}
