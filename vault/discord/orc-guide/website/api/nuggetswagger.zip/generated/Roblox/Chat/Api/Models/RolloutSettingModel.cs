using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class RolloutSettingModel
{
    public string? featureName { get; set; }
    public bool isRolloutEnabled { get; set; }
}
