using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class RecoveryMetadataResponse
{
    public bool isOnPhone { get; set; }
    public int codeLength { get; set; }
    public bool isPhoneFeatureEnabledForUsername { get; set; }
    public bool isPhoneFeatureEnabledForPassword { get; set; }
    public bool isBedev2CaptchaEnabledForPasswordReset { get; set; }
}
