using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class PaymentMethodsVisibility
{
    public bool isRobloxCreditVisible { get; set; }
    public bool isCreditCardVisible { get; set; }
    public bool isPaypalVisible { get; set; }
    public bool isXsollaOxxoVisible { get; set; }
    public bool isXsollaSofortVisible { get; set; }
    public bool isXsollaBoletoVisible { get; set; }
    public bool isXsollaCreditCardVisible { get; set; }
    public bool isAmazonPayVisible { get; set; }
    public bool isXsollaPayPalVisible { get; set; }
    public bool isXsollaOtherVisible { get; set; }
}
