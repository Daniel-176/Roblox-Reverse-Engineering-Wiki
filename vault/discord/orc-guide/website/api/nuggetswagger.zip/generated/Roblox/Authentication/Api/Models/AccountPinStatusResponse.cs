using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class AccountPinStatusResponse
{
    public bool isEnabled { get; set; }
    public double unlockedUntil { get; set; }
}
