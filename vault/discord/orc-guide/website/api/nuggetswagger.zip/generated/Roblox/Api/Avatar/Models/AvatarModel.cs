using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class AvatarModel
{
    public Roblox.Web.Responses.Avatar.ScaleModel scales { get; set; }
    public string? playerAvatarType { get; set; }
    public Roblox.Api.Avatar.Models.BodyColorsModel bodyColors { get; set; }
    public Roblox.Api.Avatar.Models.AssetModel[] assets { get; set; }
    public bool defaultShirtApplied { get; set; }
    public bool defaultPantsApplied { get; set; }
}
