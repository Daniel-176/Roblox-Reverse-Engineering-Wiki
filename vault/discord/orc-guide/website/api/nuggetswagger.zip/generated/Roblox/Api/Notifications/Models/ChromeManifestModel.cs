using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class ChromeManifestModel
{
    public string? name { get; set; }
    public string? gcm_sender_id { get; set; }
}
