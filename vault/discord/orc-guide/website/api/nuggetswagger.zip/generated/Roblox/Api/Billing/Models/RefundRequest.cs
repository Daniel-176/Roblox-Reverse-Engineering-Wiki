using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class RefundRequest
{
    public int code { get; set; }
    public string? reason { get; set; }
}
