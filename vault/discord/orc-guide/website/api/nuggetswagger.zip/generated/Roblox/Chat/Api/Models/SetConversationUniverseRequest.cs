using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class SetConversationUniverseRequest
{
    public long conversationId { get; set; }
    public long universeId { get; set; }
}
