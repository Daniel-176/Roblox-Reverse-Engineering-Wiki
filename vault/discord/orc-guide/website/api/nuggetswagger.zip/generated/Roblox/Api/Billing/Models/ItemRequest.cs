using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class ItemRequest
{
    public string? sku { get; set; }
    public int amount { get; set; }
}
