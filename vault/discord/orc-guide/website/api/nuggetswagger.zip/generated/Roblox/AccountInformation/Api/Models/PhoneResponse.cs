using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class PhoneResponse
{
    public string? countryCode { get; set; }
    public string? prefix { get; set; }
    public string? phone { get; set; }
    public bool isVerified { get; set; }
    public int verificationCodeLength { get; set; }
}
