using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Requests.Xsolla;

public class CustomParametersRequest
{
    public long user_id { get; set; }
    public int payment_method { get; set; }
    public long account_id { get; set; }
    public long checkout_session_id { get; set; }
    public int main_product { get; set; }
    public double main_product_price { get; set; }
    public int upsell_product { get; set; }
    public double upsell_product_price { get; set; }
    public double total_price { get; set; }
    public string? currency { get; set; }
    public DateTime? transaction_time { get; set; }
    public string? ip_address { get; set; }
    public int price_country_id { get; set; }
    public string? user_agent { get; set; }
}
