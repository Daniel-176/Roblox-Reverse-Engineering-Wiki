using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class AuthMetaDataResponse
{
    public int cookieLawNoticeTimeout { get; set; }
}
