using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class EmailValidationResponse
{
    public bool isEmailValid { get; set; }
}
