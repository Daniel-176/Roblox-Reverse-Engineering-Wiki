using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class GamecardRedemptionResponse
{
    public string? balance { get; set; }
    public string? successMsg { get; set; }
    public string? successSubText { get; set; }
    public string? bonusMsg { get; set; }
    public string? error { get; set; }
    public string? errorMsg { get; set; }
}
