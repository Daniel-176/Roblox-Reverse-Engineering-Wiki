using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class WearResponseModel
{
    public Roblox.Api.Avatar.Models.AssetModel[] invalidAssets { get; set; }
    public long[] invalidAssetIds { get; set; }
    public bool success { get; set; }
}
