using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class PushNotificationRegistration
{
    public long userPushNotificationDestinationId { get; set; }
    public string? name { get; set; }
    public string? notificationToken { get; set; }
    public string? application { get; set; }
    public string? platform { get; set; }
}
