using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models.Response;

public class TeamCreateSettingsResponse
{
    public bool isEnabled { get; set; }
}
