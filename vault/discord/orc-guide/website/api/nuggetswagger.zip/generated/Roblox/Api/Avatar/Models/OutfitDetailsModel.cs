using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class OutfitDetailsModel
{
    public long id { get; set; }
    public string? name { get; set; }
    public Roblox.Api.Avatar.Models.AssetModel[] assets { get; set; }
    public Roblox.Api.Avatar.Models.BodyColorsModel bodyColors { get; set; }
    public Roblox.Web.Responses.Avatar.ScaleModel scale { get; set; }
    public string? playerAvatarType { get; set; }
    public bool isEditable { get; set; }
}
