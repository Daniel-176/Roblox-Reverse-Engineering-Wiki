using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class TryOnModel
{
    public string? url { get; set; }
    public bool final { get; set; }
}
