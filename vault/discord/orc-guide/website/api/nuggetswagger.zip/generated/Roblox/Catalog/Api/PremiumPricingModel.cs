using System;
using System.Collections.Generic;

namespace Roblox.Catalog.Api;

public class PremiumPricingModel
{
    public int premiumDiscountPercentage { get; set; }
    public long premiumPriceInRobux { get; set; }
}
