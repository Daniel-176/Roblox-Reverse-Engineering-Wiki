using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class MonthlyRevenueReportStatus
{
    public int month { get; set; }
    public int year { get; set; }
    public string? RevenueReportStatus { get; set; }
}
