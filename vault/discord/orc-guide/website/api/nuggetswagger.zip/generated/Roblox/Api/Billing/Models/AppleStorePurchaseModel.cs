using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class AppleStorePurchaseModel
{
    public string? productId { get; set; }
    public string? receipt { get; set; }
    public bool isRetry { get; set; }
}
