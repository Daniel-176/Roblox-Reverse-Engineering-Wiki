using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class UserBillingInfoModel
{
    public Roblox.Api.Billing.Models.CountryViewModel[] countries { get; set; }
    public string? firstName { get; set; }
    public string? lastName { get; set; }
    public string? address1 { get; set; }
    public string? address2 { get; set; }
    public string? city { get; set; }
    public string? state { get; set; }
    public string? zip { get; set; }
    public string? country { get; set; }
    public string? email { get; set; }
    public string? phone { get; set; }
}
