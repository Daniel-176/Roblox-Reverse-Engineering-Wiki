using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class RecentItemModel
{
    public long id { get; set; }
    public string? name { get; set; }
    public string? type { get; set; }
    public Roblox.Api.Avatar.Models.AssetTypeModel assetType { get; set; }
    public bool isEditable { get; set; }
}
