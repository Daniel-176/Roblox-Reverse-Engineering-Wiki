using System;
using System.Collections.Generic;

namespace Roblox.Catalog.Api;

public class CatalogItemModel
{
    public long id { get; set; }
    public string? name { get; set; }
    public string? description { get; set; }
    public string? type { get; set; }
    public long priceInRobux { get; set; }
    public Roblox.Catalog.Api.PremiumPricingModel premiumPricing { get; set; }
}
