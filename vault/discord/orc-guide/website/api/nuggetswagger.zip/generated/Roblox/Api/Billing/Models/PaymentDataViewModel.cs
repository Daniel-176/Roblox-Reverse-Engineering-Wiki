using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class PaymentDataViewModel
{
    public bool isDesktopLocalPricingEnabled { get; set; }
    public int countryCurrencyTypeId { get; set; }
    public double selectedProductPrice { get; set; }
    public int currencyTypeId { get; set; }
    public Roblox.Platform.BillingV2.Core.Currency currency { get; set; }
}
