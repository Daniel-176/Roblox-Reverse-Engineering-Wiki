using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class RedeemToyMetadataResponse
{
    public int codeLength { get; set; }
    public string? howToRedeemToysCodeVideoId { get; set; }
}
