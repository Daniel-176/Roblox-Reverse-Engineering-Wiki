using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class NotificationIdsResponseModel
{
    public string[] ids { get; set; }
    public string? statusMessage { get; set; }
}
