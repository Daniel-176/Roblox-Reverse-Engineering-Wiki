using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class SocialAuthenticationDisconnectRequest
{
    public string? Password { get; set; }
}
