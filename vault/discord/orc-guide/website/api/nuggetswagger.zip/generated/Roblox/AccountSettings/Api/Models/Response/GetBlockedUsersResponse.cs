using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api.Models.Response;

public class GetBlockedUsersResponse
{
    public long[] blockedUserIds { get; set; }
}
