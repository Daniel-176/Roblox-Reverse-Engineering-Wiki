using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class GameChatPrivacyRequest
{
    public int gameChatPrivacy { get; set; }
}
