using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class DevStatsCreatorDashboardMetadataResponse
{
    public bool isDevStatsEnabled { get; set; }
    public bool isPremiumPayoutsEnabled { get; set; }
    public bool isPremiumVisitsEnabled { get; set; }
    public bool isDataExportEnabled { get; set; }
    public bool isLiveStatsEnabled_ { get; set; }
    public bool isDeviceFilteringEnabled_ { get; set; }
    public bool isHistoricalDataEnabled_ { get; set; }
    public bool isDeveloperProductSalesEnabled_ { get; set; }
    public bool isDeveloperProductRevenueAggregationEnabled { get; set; }
}
