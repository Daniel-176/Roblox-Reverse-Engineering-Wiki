using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class VirtualCurrencyRequest
{
    public string? name { get; set; }
    public int quantity { get; set; }
    public string? currency { get; set; }
    public double amount { get; set; }
    public string? sku { get; set; }
}
