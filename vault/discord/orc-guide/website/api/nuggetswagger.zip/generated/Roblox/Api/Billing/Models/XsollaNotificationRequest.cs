using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class XsollaNotificationRequest
{
    public string? notification_type { get; set; }
    public Roblox.Api.Billing.Models.PurchaseRequest purchase { get; set; }
    public Roblox.Api.Billing.Models.UserRequest user { get; set; }
    public Roblox.Api.Billing.Models.TransactionRequest transaction { get; set; }
    public Roblox.Api.Billing.Models.PaymentDetailsRequest payment_details { get; set; }
    public Roblox.Api.Billing.Models.SubscriptionRequest subscription { get; set; }
    public Roblox.Api.Billing.Models.RefundRequest refund_details { get; set; }
    public Roblox.Api.Billing.Models.Requests.Xsolla.CustomParametersRequest custom_parameters { get; set; }
}
