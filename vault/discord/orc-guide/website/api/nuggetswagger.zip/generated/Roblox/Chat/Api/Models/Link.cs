using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class Link
{
    public string? type { get; set; }
    public Roblox.Chat.Api.Models.GameLink game { get; set; }
}
