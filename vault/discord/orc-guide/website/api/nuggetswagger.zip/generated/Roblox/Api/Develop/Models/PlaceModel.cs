using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class PlaceModel
{
    public long id { get; set; }
    public long universeId { get; set; }
    public string? name { get; set; }
    public string? description { get; set; }
}
