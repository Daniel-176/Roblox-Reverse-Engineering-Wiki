using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class UsernameChangeRequest
{
    public string? username { get; set; }
    public string? password { get; set; }
}
