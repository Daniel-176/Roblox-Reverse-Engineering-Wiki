using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class UpdateEmailRequest
{
    public string? password { get; set; }
    public string? emailAddress { get; set; }
    public bool skipVerificationEmail { get; set; }
}
