using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api.Models;

public class AccountsSettingsMetadataModel
{
    public bool IsAccountsRestrictionsSpamBugFixEnabled { get; set; }
    public int MaximumParentalControlsMonthlySpendLimitInUSD { get; set; }
    public bool IsParentalMonthlyLimitInUIEnabled { get; set; }
    public bool IsParentalNotificationSettingsInUIEnabled { get; set; }
    public bool IsContentControlsEnabled { get; set; }
}
