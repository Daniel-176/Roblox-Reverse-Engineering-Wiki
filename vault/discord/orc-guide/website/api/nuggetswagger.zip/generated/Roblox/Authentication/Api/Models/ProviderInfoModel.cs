using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class ProviderInfoModel
{
    public string? provider { get; set; }
    public string? identifier { get; set; }
}
