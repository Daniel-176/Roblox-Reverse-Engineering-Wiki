using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class GetLuobuDevexEligibilityResponse
{
    public string? eligibility { get; set; }
}
