using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class PlaceModelV2
{
    public int maxPlayerCount { get; set; }
    public string? socialSlotType { get; set; }
    public int customSocialSlotsCount { get; set; }
    public bool allowCopying { get; set; }
    public int currentSavedVersion { get; set; }
    public long id { get; set; }
    public long universeId { get; set; }
    public string? name { get; set; }
    public string? description { get; set; }
    public bool isRootPlace { get; set; }
}
