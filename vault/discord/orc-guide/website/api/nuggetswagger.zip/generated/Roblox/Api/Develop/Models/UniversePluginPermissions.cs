using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class UniversePluginPermissions
{
    public bool IsThirdPartyTeleportAllowed { get; set; }
    public bool IsThirdPartyAssetAllowed { get; set; }
    public bool IsThirdPartyPurchaseAllowed { get; set; }
}
