using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class PrivateMessagePrivacyResponse
{
    public string? privateMessagePrivacy { get; set; }
}
