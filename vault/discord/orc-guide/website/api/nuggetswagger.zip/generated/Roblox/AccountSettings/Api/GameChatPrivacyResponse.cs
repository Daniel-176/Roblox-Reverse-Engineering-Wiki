using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class GameChatPrivacyResponse
{
    public string? gameChatPrivacy { get; set; }
}
