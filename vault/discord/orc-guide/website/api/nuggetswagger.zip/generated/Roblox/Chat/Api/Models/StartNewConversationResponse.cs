using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class StartNewConversationResponse
{
    public Roblox.Chat.Api.Models.Conversation conversation { get; set; }
    public Roblox.Chat.Api.Models.RejectedChatParticipant[] rejectedParticipants { get; set; }
    public string? resultType { get; set; }
    public string? statusMessage { get; set; }
}
