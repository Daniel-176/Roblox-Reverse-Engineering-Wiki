using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class RequestRevenueReportResponse
{
    public string? revenueReportStatus { get; set; }
}
