using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class SetConversationUniverseEventBased
{
    public long actorUserId { get; set; }
    public long universeId { get; set; }
}
