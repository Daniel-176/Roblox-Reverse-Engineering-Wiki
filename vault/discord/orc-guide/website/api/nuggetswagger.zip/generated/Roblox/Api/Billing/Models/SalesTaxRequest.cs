using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class SalesTaxRequest
{
    public string? currency { get; set; }
    public double amount { get; set; }
}
