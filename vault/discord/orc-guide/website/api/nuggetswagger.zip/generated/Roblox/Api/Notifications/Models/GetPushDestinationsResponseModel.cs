using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class GetPushDestinationsResponseModel
{
    public Roblox.Api.Notifications.Models.UserPushDestination[] destinations { get; set; }
    public string? statusMessage { get; set; }
}
