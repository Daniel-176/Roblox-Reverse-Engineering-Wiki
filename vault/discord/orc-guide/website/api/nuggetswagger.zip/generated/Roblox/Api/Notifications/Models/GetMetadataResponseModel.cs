using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class GetMetadataResponseModel
{
    public Roblox.Api.Notifications.Models.PushNotificationClientMetadata metadata { get; set; }
    public string? statusMessage { get; set; }
}
