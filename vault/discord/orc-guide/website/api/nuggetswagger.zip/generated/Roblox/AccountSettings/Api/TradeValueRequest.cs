using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class TradeValueRequest
{
    public int tradeValue { get; set; }
}
