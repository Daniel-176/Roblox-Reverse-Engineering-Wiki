using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class AppChatPrivacyResponse
{
    public string? appChatPrivacy { get; set; }
}
