using System;
using System.Collections.Generic;

namespace Roblox.CdnProviders.Api;

public class DomainsEnabled
{
    public bool css { get; set; }
    public bool js { get; set; }
    public bool images { get; set; }
    public bool thumbnails { get; set; }
    public bool assets { get; set; }
    public bool setup { get; set; }
    public bool static { get; set; }
}
