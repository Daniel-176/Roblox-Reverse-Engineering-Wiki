using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class GetLuobuLatestRequestStatusResponse
{
    public DateTime? date { get; set; }
    public string? status { get; set; }
    public double amount { get; set; }
}
