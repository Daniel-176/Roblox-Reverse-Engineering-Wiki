using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class DigitalCodeRedemptionModel
{
    public string? redemptionCode { get; set; }
}
