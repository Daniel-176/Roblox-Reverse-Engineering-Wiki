using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class ChatMetadataResponse
{
    public string? isChatEnabledByPrivacySetting { get; set; }
    public string? languageForPrivacySettingUnavailable { get; set; }
    public int maxConversationTitleLength { get; set; }
    public int numberOfMembersForPartyChrome { get; set; }
    public int partyChromeDisplayTimeStampInterval { get; set; }
    public int signalRDisconnectionResponseInMilliseconds { get; set; }
    public int typingInChatFromSenderThrottleMs { get; set; }
    public int typingInChatForReceiverExpirationMs { get; set; }
    public double relativeValueToRecordUiPerformance { get; set; }
    public bool isChatDataFromLocalStorageEnabled { get; set; }
    public int chatDataFromLocalStorageExpirationSeconds { get; set; }
    public bool isUsingCacheToLoadFriendsInfoEnabled { get; set; }
    public int cachedDataFromLocalStorageExpirationMS { get; set; }
    public string[] senderTypesForUnknownMessageTypeError { get; set; }
    public bool isInvalidMessageTypeFallbackEnabled { get; set; }
    public bool isRespectingMessageTypeEnabled { get; set; }
    public string[] validMessageTypesWhiteList { get; set; }
    public bool shouldRespectConversationHasUnreadMessageToMarkAsRead { get; set; }
    public bool isVoiceChatForClientSideEnabled { get; set; }
    public bool isAliasChatForClientSideEnabled { get; set; }
    public bool isPlayTogetherForGameCardsEnabled { get; set; }
    public bool isRoactChatEnabled { get; set; }
}
