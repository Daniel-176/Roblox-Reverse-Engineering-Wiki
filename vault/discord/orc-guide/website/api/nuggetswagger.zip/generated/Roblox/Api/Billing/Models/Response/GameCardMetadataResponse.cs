using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class GameCardMetadataResponse
{
    public bool IsNewInCommEndpointEnabled { get; set; }
    public bool IsNewGiftCardEndpointEnabled { get; set; }
    public bool IsConvertCreditFlowEnabled { get; set; }
    public string? PinPlaceholder { get; set; }
    public int GiftCardCodeLength { get; set; }
    public int GameCardCodeLength { get; set; }
    public bool IsEventStreamEnabled { get; set; }
}
