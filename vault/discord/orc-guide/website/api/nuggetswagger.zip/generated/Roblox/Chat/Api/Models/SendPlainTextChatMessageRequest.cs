using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class SendPlainTextChatMessageRequest
{
    public string? message { get; set; }
    public long conversationId { get; set; }
    public string[] decorators { get; set; }
}
