using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class StarCodeAffiliateResponse
{
    public long userId { get; set; }
    public string? name { get; set; }
    public string? code { get; set; }
}
