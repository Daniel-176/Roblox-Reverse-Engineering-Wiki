using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class CreditPaymentMetadataResponse
{
    public Roblox.Api.Billing.Models.Response.CreditPaymentViewModel viewModel { get; set; }
    public string? redirectionUrl { get; set; }
}
