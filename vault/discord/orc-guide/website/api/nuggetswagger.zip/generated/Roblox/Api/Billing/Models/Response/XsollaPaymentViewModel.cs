using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class XsollaPaymentViewModel
{
    public string? paymentProviderType { get; set; }
    public Roblox.Platform.Billing.ProductDisplayModel selectedProduct { get; set; }
    public Roblox.Platform.Billing.ProductDisplayModel selectedProductBcVersion { get; set; }
    public int selectedUpsellProductId { get; set; }
    public string? xsollaPaymentUIToken { get; set; }
    public string? xsollaValidOrigin { get; set; }
    public string? incrementCounterUrl { get; set; }
    public bool isXsollaBoleto { get; set; }
    public string? xsollaPaymentUIUrl { get; set; }
    public string? robloxSupportUrl { get; set; }
    public string? xsollaSupportUrl { get; set; }
    public bool isXsollaPaypalIframeEnabled { get; set; }
}
