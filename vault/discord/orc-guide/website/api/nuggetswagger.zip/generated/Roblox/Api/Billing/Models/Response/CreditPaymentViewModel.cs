using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class CreditPaymentViewModel
{
    public Roblox.Platform.Billing.ProductDisplayModel selectedProduct { get; set; }
    public double availableCredit { get; set; }
    public double totalDue { get; set; }
    public double balance { get; set; }
}
