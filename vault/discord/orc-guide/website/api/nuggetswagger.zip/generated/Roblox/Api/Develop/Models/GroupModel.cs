using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class GroupModel
{
    public long id { get; set; }
    public string? name { get; set; }
}
