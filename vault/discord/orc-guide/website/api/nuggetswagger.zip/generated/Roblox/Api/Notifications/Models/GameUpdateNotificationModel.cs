using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class GameUpdateNotificationModel
{
    public long universeId { get; set; }
    public long rootPlaceId { get; set; }
    public DateTime? createdOn { get; set; }
    public string? createdOnKey { get; set; }
    public string? content { get; set; }
    public string? universeName { get; set; }
}
