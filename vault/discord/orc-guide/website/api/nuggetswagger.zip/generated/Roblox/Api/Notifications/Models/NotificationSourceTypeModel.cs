using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class NotificationSourceTypeModel
{
    public string? sourceType { get; set; }
}
