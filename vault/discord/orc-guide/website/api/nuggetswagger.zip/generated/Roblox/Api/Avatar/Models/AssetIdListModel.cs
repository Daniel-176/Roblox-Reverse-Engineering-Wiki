using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class AssetIdListModel
{
    public long[] assetIds { get; set; }
}
