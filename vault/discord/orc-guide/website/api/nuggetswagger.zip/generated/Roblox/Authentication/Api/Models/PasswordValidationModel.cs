using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class PasswordValidationModel
{
    public string? username { get; set; }
    public string? password { get; set; }
}
