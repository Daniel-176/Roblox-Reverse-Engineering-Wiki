using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class AmazonStorePurchaseModel
{
    public string? receiptId { get; set; }
    public string? amazonUserId { get; set; }
    public bool isRetry { get; set; }
}
