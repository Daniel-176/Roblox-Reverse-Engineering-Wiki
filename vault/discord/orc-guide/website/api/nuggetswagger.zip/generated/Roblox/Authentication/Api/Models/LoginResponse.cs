using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class LoginResponse
{
    public Roblox.Web.Responses.Users.SkinnyUserResponse user { get; set; }
    public Roblox.Authentication.Api.Models.TwoStepVerificationSentResponse twoStepVerificationData { get; set; }
    public string? identityVerificationLoginTicket { get; set; }
    public bool isBanned { get; set; }
}
