using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class CanSendCredentialsVerificationMessageResponse
{
    public bool canSend { get; set; }
}
