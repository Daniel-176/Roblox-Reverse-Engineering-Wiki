using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class SendPlainTextChatMessageResponse
{
    public string? content { get; set; }
    public bool filteredForReceivers { get; set; }
    public string? messageId { get; set; }
    public DateTime? sent { get; set; }
    public string? messageType { get; set; }
    public string? resultType { get; set; }
    public string? statusMessage { get; set; }
}
