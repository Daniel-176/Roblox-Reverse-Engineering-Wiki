using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class OutfitUpdateModelV3
{
    public string? name { get; set; }
    public Roblox.Platform.Avatar.BodyColorsModelV2 bodyColors { get; set; }
    public Roblox.Api.Avatar.Models.AssetWearModel[] assets { get; set; }
    public Roblox.Web.Responses.Avatar.ScaleModel scale { get; set; }
    public string? playerAvatarType { get; set; }
    public int outfitType { get; set; }
}
