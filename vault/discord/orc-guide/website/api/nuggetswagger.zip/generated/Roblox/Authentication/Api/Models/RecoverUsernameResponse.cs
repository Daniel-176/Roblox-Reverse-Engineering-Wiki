using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class RecoverUsernameResponse
{
    public string? transmissionType { get; set; }
}
