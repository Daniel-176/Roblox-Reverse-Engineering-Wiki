using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class UniverseModel
{
    public long id { get; set; }
    public string? name { get; set; }
    public string? description { get; set; }
    public bool isArchived { get; set; }
    public long rootPlaceId { get; set; }
    public bool isActive { get; set; }
    public string? privacyType { get; set; }
    public string? creatorType { get; set; }
    public long creatorTargetId { get; set; }
    public string? creatorName { get; set; }
    public DateTime? created { get; set; }
    public DateTime? updated { get; set; }
}
