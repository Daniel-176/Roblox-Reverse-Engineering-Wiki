using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Controllers.V1.AvatarController;

public class EmptyResponse
{
}
