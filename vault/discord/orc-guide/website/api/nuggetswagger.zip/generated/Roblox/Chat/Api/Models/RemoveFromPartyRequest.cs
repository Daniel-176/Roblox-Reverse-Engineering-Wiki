using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class RemoveFromPartyRequest
{
    public string? partyId { get; set; }
    public long userId { get; set; }
}
