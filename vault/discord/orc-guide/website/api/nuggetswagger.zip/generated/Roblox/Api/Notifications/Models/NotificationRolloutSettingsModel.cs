using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class NotificationRolloutSettingsModel
{
    public Roblox.Api.Notifications.Models.RolloutSettingsModel[] rollOutFeatureEnabledList { get; set; }
}
