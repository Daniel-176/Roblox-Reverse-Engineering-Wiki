using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class GenderResponse
{
    public int gender { get; set; }
}
