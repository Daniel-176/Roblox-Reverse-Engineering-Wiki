using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api;

public class RobloxBadgeResponse
{
    public int id { get; set; }
    public string? name { get; set; }
    public string? description { get; set; }
    public string? imageUrl { get; set; }
}
