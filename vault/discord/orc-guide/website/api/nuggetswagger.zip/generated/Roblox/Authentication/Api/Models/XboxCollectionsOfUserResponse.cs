using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class XboxCollectionsOfUserResponse
{
    public Roblox.Authentication.Api.Models.XboxUserModel[] Users { get; set; }
}
