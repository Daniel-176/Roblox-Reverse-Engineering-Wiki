using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class UniverseIdPermissionsModel
{
    public long universeId { get; set; }
    public bool canManage { get; set; }
    public bool canCloudEdit { get; set; }
}
