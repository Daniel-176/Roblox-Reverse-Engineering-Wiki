using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class UsernameValidationResponse
{
    public string? code { get; set; }
    public string? message { get; set; }
}
