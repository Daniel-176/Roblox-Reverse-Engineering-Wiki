using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class PhoneRequest
{
    public string? countryCode { get; set; }
    public string? prefix { get; set; }
    public string? phone { get; set; }
    public string? password { get; set; }
}
