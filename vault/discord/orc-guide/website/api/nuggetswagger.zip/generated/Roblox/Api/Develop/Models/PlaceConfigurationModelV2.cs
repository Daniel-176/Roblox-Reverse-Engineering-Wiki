using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class PlaceConfigurationModelV2
{
    public string? name { get; set; }
    public string? description { get; set; }
    public int maxPlayerCount { get; set; }
    public string? socialSlotType { get; set; }
    public int customSocialSlotsCount { get; set; }
    public bool allowCopying { get; set; }
}
