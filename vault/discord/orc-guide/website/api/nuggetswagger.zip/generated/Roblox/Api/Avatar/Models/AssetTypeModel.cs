using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class AssetTypeModel
{
    public long id { get; set; }
    public string? name { get; set; }
}
