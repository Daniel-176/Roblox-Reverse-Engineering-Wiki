using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class RecommendedUsernameRequest
{
    public string? username { get; set; }
    public DateTime? birthday { get; set; }
}
