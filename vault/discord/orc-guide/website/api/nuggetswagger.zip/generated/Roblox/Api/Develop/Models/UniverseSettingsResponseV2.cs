using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class UniverseSettingsResponseV2
{
    public bool allowPrivateServers { get; set; }
    public long privateServerPrice { get; set; }
    public long id { get; set; }
    public string? name { get; set; }
    public string? description { get; set; }
    public string? universeAvatarType { get; set; }
    public string? universeAnimationType { get; set; }
    public string? universeCollisionType { get; set; }
    public string? universeJointPositioningType { get; set; }
    public bool isArchived { get; set; }
    public bool isFriendsOnly { get; set; }
    public string? genre { get; set; }
    public string[] playableDevices { get; set; }
    public bool isForSale { get; set; }
    public long price { get; set; }
    public Roblox.Platform.UniverseSettings.UniverseAvatarAssetOverrideResponseModel[] universeAvatarAssetOverrides { get; set; }
    public Roblox.Web.Responses.Avatar.ScaleModel universeAvatarMinScales { get; set; }
    public Roblox.Web.Responses.Avatar.ScaleModel universeAvatarMaxScales { get; set; }
    public bool studioAccessToApisAllowed { get; set; }
    public Roblox.Api.Develop.Models.UniversePluginPermissions permissions { get; set; }
}
