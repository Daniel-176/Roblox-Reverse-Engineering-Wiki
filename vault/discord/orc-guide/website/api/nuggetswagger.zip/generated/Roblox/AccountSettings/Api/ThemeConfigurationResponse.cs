using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class ThemeConfigurationResponse
{
    public string? themeType { get; set; }
}
