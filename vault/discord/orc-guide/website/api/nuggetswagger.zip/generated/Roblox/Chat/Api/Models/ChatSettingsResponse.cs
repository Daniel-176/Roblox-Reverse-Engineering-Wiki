using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class ChatSettingsResponse
{
    public bool chatEnabled { get; set; }
    public bool isActiveChatUser { get; set; }
}
