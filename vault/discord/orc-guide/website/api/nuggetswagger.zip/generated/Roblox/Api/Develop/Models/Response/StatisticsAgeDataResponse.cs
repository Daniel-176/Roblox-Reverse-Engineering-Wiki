using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models.Response;

public class StatisticsAgeDataResponse
{
    public bool isAgeDataAvailable { get; set; }
}
