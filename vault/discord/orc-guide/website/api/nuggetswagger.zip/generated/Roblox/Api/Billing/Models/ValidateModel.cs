using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class ValidateModel
{
    public string? productId { get; set; }
    public string? currency { get; set; }
}
