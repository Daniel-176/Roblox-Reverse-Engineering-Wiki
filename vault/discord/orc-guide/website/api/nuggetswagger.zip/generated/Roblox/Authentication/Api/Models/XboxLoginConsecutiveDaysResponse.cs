using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class XboxLoginConsecutiveDaysResponse
{
    public int count { get; set; }
}
