using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class RemoveUserFromConversationRequest
{
    public long participantUserId { get; set; }
    public long conversationId { get; set; }
}
