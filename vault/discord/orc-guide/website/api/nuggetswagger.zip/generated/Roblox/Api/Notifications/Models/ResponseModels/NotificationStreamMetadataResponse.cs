using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models.ResponseModels;

public class NotificationStreamMetadataResponse
{
    public int bannerDismissTimeSpan { get; set; }
    public long signalRDisconnectionResponseInMilliseconds { get; set; }
    public bool canLaunchGameFromGameUpdate { get; set; }
}
