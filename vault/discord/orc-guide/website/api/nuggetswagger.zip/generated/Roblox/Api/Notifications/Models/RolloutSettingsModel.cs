using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class RolloutSettingsModel
{
    public string? featureName { get; set; }
    public bool isRolloutEnabled { get; set; }
    public bool isValidFeature { get; set; }
}
