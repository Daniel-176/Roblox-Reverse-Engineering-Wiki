using System;
using System.Collections.Generic;

namespace Roblox.Ads.Api;

public class CreateUserAdRequest
{
    public string? name { get; set; }
}
