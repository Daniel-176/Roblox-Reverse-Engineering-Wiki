using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class GameUpdateNotificationReadRequestModel
{
    public long universeId { get; set; }
    public string? createdOn { get; set; }
    public long currentUserId { get; set; }
}
