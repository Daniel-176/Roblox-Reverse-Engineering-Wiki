using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Requests;

public class IncrementUserAgentCounterRequest
{
    public string? CounterPrefix { get; set; }
}
