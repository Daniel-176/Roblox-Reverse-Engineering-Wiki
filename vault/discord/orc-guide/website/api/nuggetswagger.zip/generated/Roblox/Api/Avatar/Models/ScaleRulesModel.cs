using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class ScaleRulesModel
{
    public double min { get; set; }
    public double max { get; set; }
    public double increment { get; set; }
}
