using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class DefaultClothingAssets
{
    public long[] defaultShirtAssetIds { get; set; }
    public long[] defaultPantAssetIds { get; set; }
}
