using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class MarkAsSeenRequest
{
    public long[] conversationsToMarkSeen { get; set; }
}
