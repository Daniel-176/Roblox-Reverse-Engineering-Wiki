using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class GameStatsListResponse
{
    public Roblox.DevMetrics.Models.ReportStatusResult[] reports { get; set; }
}
