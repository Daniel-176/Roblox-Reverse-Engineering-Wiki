using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class PromotionChannelsRequest
{
    public string? facebook { get; set; }
    public string? twitter { get; set; }
    public string? youtube { get; set; }
    public string? twitch { get; set; }
    public string? promotionChannelsVisibilityPrivacy { get; set; }
}
