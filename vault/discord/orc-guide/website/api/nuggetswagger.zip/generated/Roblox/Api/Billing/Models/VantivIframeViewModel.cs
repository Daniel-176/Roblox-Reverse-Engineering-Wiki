using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class VantivIframeViewModel
{
    public string? eprotectClientJsSource { get; set; }
    public string? eprotectId { get; set; }
    public string? cssFilename { get; set; }
    public string? reportGroup { get; set; }
    public int timeoutInMilliseconds { get; set; }
    public string? orderId { get; set; }
    public string? paypageRegistrationId { get; set; }
    public Roblox.Api.Billing.Models.MaskedCreditCardInfoModel maskedCreditCardInfoModel { get; set; }
}
