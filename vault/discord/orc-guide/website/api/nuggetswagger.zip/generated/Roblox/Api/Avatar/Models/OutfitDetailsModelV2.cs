using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class OutfitDetailsModelV2
{
    public long id { get; set; }
    public string? name { get; set; }
    public Roblox.Api.Avatar.Models.AssetModelV2[] assets { get; set; }
    public Roblox.Api.Avatar.Models.BodyColorsModelV2 bodyColors3 { get; set; }
    public Roblox.Web.Responses.Avatar.ScaleModel scale { get; set; }
    public string? playerAvatarType { get; set; }
    public string? outfitType { get; set; }
    public bool isEditable { get; set; }
}
