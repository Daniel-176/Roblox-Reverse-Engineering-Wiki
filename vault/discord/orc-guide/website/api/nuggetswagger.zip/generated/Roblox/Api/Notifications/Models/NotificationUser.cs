using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class NotificationUser
{
    public string? name { get; set; }
    public long userId { get; set; }
}
