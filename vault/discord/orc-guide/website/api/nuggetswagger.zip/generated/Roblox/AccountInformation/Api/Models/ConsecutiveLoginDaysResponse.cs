using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class ConsecutiveLoginDaysResponse
{
    public int count { get; set; }
}
