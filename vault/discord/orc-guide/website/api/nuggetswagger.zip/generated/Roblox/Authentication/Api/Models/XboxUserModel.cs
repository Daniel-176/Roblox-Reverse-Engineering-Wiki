using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class XboxUserModel
{
    public string? Id { get; set; }
    public long UserId { get; set; }
    public string? Username { get; set; }
}
