using System;
using System.Collections.Generic;

namespace Roblox.Billing.Api;

public class PurchasedProductResponse
{
    public string? name { get; set; }
}
