using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class SignupResponse
{
    public long userId { get; set; }
    public long starterPlaceId { get; set; }
}
