using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class PartyRequest
{
    public string? partyId { get; set; }
}
