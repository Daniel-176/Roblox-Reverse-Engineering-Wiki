using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class UpdateTeamCreateSettingsRequest
{
    public bool isEnabled { get; set; }
}
