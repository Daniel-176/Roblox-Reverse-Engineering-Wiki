using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class CreateOneToOneConversationRequest
{
    public long participantUserId { get; set; }
}
