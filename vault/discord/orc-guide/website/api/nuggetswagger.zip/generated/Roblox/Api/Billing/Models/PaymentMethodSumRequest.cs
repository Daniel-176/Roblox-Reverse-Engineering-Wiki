using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class PaymentMethodSumRequest
{
    public string? currency { get; set; }
    public double amount { get; set; }
}
