using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class CreditPaymentCheckoutResponse
{
    public bool isSuccess { get; set; }
    public string? redirectionUrl { get; set; }
}
