using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class MetadataResponse
{
    public bool isUpdateUsernameEnabled { get; set; }
    public string? ftuxAvatarAssetMap { get; set; }
    public bool IsEmailUpsellAtLogoutEnabled { get; set; }
    public bool ShouldFetchEmailUpsellIXPValuesAtLogout { get; set; }
    public bool IsAccountRecoveryPromptEnabled { get; set; }
    public bool IsContactMethodRequiredAtSignup { get; set; }
    public bool IsUserAgreementsSignupIntegrationEnabled { get; set; }
    public bool IsKoreaIdVerificationEnabled { get; set; }
    public bool IsPasswordRequiredForUsernameChange { get; set; }
}
