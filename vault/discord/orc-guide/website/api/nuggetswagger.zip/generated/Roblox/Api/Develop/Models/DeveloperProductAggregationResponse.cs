using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class DeveloperProductAggregationResponse
{
    public Roblox.Api.Develop.Models.DeveloperProductRevenue[] allDevicesDeveloperProductRevenue { get; set; }
    public object? developerProductRevenueByDevice { get; set; }
}
