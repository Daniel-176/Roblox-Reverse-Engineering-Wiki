using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class ReceiverDestinationPreferenceModel
{
    public string? notificationSourceType { get; set; }
    public long destinationId { get; set; }
    public bool isEnabled { get; set; }
}
