using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class VerifyEmailRequest
{
    public string? ticket { get; set; }
}
