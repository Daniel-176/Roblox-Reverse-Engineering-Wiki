using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api.Models.Response;

public class GetDetailedBlockedUsersResponse
{
    public Roblox.AccountSettings.Api.Models.BlockedUser[] blockedUsers { get; set; }
    public int maxBlockedUsers { get; set; }
    public long total { get; set; }
}
