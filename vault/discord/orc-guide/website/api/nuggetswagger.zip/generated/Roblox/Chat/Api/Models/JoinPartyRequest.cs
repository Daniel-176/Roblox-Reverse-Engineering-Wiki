using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class JoinPartyRequest
{
    public string? partyId { get; set; }
    public bool autoFollowPartyLeader { get; set; }
}
