using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class PlayerAvatarTypeModel
{
    public string? playerAvatarType { get; set; }
}
