using System;
using System.Collections.Generic;

namespace Roblox.AdConfiguration.Api;

public class GetSponsoredGamesResponse
{
    public Roblox.AdConfiguration.Api.SponsoredGameV2Model[] sponsoredGames { get; set; }
    public string? previousPageCursor { get; set; }
    public string? nextPageCursor { get; set; }
}
