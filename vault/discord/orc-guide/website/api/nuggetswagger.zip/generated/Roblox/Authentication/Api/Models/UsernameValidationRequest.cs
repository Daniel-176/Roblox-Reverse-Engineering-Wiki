using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class UsernameValidationRequest
{
    public string? username { get; set; }
    public DateTime? birthday { get; set; }
    public string? context { get; set; }
}
