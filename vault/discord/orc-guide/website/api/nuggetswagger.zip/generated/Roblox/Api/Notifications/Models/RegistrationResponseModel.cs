using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class RegistrationResponseModel
{
    public Roblox.Api.Notifications.Models.PushNotificationRegistration registration { get; set; }
    public string? statusMessage { get; set; }
}
