using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class PasswordValidationResponse
{
    public string? code { get; set; }
    public string? message { get; set; }
}
