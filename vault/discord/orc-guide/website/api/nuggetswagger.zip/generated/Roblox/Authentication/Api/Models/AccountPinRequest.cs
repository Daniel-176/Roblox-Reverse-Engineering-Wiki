using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class AccountPinRequest
{
    public string? pin { get; set; }
    public string? reauthenticationToken { get; set; }
}
