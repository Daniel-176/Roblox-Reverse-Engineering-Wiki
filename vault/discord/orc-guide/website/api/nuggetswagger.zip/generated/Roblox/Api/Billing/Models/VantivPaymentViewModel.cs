using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class VantivPaymentViewModel
{
    public string? paymentProviderType { get; set; }
    public Roblox.Platform.Billing.ProductDisplayModel selectedProduct { get; set; }
    public Roblox.Platform.Billing.ProductDisplayModel selectedProductBcVersion { get; set; }
    public int robuxBcBonus { get; set; }
    public int selectedUpsellProductId { get; set; }
    public Roblox.Api.Billing.Models.PaymentDataViewModel dataViewModel { get; set; }
    public Roblox.Api.Billing.Models.UserBillingInfoModel userBillingInfo { get; set; }
    public Roblox.Platform.Billing.CreditCard creditCard { get; set; }
    public Roblox.Api.Billing.Models.VantivIframeViewModel vantivIframeViewModel { get; set; }
    public bool displayDoublePurchase { get; set; }
    public bool doublePurchaseConfirmed { get; set; }
    public bool isKountEnabled { get; set; }
    public bool kountNoIFrameEnabled { get; set; }
    public string? kountScriptSDKUrl { get; set; }
    public string? kountUrl { get; set; }
    public string? kountSessionId { get; set; }
    public bool isVantivThreatMetrixEnabled { get; set; }
    public string? vantivThreatMetrixScriptUrl { get; set; }
    public string? vantivThreatMetrixIframeUrl { get; set; }
    public string? vantivThreatMetrixSessionId { get; set; }
    public int vantivPaymentAbTestVariationValue { get; set; }
    public bool isIframeLoadingForVantivEnabled { get; set; }
    public int iframeLoadingTimeOutForVantiv { get; set; }
}
