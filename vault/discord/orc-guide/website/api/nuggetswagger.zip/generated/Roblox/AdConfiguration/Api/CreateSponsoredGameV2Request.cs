using System;
using System.Collections.Generic;

namespace Roblox.AdConfiguration.Api;

public class CreateSponsoredGameV2Request
{
    public long universeId { get; set; }
    public string? targetGender { get; set; }
    public string? targetAgeBracket { get; set; }
    public long budgetInRobux { get; set; }
    public DateTime? startDate { get; set; }
    public DateTime? endDate { get; set; }
    public string? targetDeviceType { get; set; }
    public string? adName { get; set; }
    public long bidAmountInRobux { get; set; }
}
