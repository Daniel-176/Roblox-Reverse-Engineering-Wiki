using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class LoginRequest
{
    public string? ctype { get; set; }
    public string? cvalue { get; set; }
    public string? password { get; set; }
    public long userId { get; set; }
    public string? securityQuestionSessionId { get; set; }
    public string? securityQuestionRedemptionToken { get; set; }
    public Roblox.Authentication.Api.Models.Request.SecureAuthenticationIntentModel secureAuthenticationIntent { get; set; }
    public string? captchaId { get; set; }
    public string? captchaToken { get; set; }
    public string? captchaProvider { get; set; }
    public string? challengeId { get; set; }
}
