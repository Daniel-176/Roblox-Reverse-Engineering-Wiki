using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class SubmitLuobuDevexResponse
{
}
