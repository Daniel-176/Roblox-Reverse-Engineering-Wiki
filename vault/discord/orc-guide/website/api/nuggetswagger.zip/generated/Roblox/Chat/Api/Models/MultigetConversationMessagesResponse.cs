using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class MultigetConversationMessagesResponse
{
    public long conversationId { get; set; }
    public Roblox.Chat.Api.Models.ChatMessage[] chatMessages { get; set; }
}
