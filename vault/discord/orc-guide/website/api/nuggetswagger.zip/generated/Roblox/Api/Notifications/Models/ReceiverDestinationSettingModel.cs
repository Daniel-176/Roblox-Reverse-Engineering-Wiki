using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class ReceiverDestinationSettingModel
{
    public string? name { get; set; }
    public string? platform { get; set; }
    public long destinationId { get; set; }
    public bool isEnabled { get; set; }
    public bool isSetByReceiver { get; set; }
}
