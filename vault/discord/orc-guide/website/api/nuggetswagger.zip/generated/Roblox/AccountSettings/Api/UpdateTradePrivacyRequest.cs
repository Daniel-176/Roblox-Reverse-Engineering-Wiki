using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class UpdateTradePrivacyRequest
{
    public int tradePrivacy { get; set; }
}
