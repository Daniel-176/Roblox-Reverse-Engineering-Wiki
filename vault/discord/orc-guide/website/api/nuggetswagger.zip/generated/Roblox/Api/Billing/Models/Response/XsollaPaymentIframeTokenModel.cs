using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class XsollaPaymentIframeTokenModel
{
    public string? token { get; set; }
    public bool success { get; set; }
    public string? message { get; set; }
}
