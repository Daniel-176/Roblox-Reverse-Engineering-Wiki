using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api.Models;

public class BlockedUser
{
    public long userId { get; set; }
    public string? name { get; set; }
    public string? displayName { get; set; }
}
