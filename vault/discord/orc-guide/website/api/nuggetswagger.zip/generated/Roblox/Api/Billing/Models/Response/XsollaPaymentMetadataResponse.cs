using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class XsollaPaymentMetadataResponse
{
    public Roblox.Api.Billing.Models.Response.XsollaPaymentViewModel viewModel { get; set; }
    public Roblox.Api.Billing.Models.RedirectionModel redirectionModel { get; set; }
}
