using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class InventoryPrivacyResponse
{
    public int inventoryPrivacy { get; set; }
}
