using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class AvatarFilteredPageResponse<OutfitModel>
{
    public int filteredCount { get; set; }
    public Roblox.Api.Avatar.Models.OutfitModel[] data { get; set; }
    public long total { get; set; }
}
