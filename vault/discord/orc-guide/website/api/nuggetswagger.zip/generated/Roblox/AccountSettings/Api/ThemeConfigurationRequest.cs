using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class ThemeConfigurationRequest
{
    public string? themeType { get; set; }
}
