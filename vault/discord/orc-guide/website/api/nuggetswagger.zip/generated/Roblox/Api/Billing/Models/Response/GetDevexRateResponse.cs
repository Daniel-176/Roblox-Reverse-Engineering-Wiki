using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class GetDevexRateResponse
{
    public double rate { get; set; }
    public string? currency_code { get; set; }
}
