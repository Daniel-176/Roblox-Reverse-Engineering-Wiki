using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class AliasRequest
{
    public string? name { get; set; }
    public string? type { get; set; }
    public long targetId { get; set; }
}
