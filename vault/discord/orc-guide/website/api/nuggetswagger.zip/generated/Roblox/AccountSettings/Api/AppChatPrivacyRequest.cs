using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class AppChatPrivacyRequest
{
    public int appChatPrivacy { get; set; }
}
