using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models.Request;

public class IdentityVerificationLoginRequest
{
    public string? loginTicket { get; set; }
    public string? resultToken { get; set; }
}
