using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class TwoStepVerificationVerifyRequest
{
    public string? username { get; set; }
    public string? ticket { get; set; }
    public string? code { get; set; }
    public bool rememberDevice { get; set; }
    public string? actionType { get; set; }
}
