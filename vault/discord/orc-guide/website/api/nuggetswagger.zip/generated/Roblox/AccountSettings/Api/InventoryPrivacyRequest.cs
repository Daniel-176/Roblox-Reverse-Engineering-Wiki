using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class InventoryPrivacyRequest
{
    public int inventoryPrivacy { get; set; }
}
