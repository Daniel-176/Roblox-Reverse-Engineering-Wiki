using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class VirtualItemsRequest
{
    public Roblox.Api.Billing.Models.ItemRequest[] items { get; set; }
    public string? currency { get; set; }
    public double amount { get; set; }
}
