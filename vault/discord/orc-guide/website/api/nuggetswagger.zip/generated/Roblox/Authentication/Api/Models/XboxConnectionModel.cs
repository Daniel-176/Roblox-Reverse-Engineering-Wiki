using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class XboxConnectionModel
{
    public bool hasConnectedXboxAccount { get; set; }
}
