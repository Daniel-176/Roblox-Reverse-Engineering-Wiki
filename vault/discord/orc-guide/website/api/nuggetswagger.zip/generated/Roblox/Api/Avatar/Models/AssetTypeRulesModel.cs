using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class AssetTypeRulesModel
{
    public int maxNumber { get; set; }
    public long id { get; set; }
    public string? name { get; set; }
}
