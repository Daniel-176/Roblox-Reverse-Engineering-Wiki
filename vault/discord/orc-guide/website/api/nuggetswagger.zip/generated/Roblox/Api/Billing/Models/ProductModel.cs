using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class ProductModel
{
    public int productId { get; set; }
    public double expectedPrice { get; set; }
}
