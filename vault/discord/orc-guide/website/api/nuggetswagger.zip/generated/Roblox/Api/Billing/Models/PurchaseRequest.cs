using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class PurchaseRequest
{
    public Roblox.Api.Billing.Models.VirtualCurrencyRequest virtual_currency { get; set; }
    public Roblox.Api.Billing.Models.VirtualItemsRequest virtual_items { get; set; }
    public Roblox.Api.Billing.Models.CheckoutRequest checkout { get; set; }
    public Roblox.Api.Billing.Models.SubscriptionRequest subscription { get; set; }
    public Roblox.Api.Billing.Models.TotalRequest total { get; set; }
}
