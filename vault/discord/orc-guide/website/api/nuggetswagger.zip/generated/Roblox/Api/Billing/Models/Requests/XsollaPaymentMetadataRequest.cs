using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Requests;

public class XsollaPaymentMetadataRequest
{
    public int ProductId { get; set; }
    public string? paymentMethod { get; set; }
    public int selectedUpsellProductId { get; set; }
}
