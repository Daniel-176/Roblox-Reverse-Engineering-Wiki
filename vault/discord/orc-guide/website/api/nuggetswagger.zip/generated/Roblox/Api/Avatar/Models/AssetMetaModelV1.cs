using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class AssetMetaModelV1
{
    public int order { get; set; }
    public float puffiness { get; set; }
    public int version { get; set; }
}
