using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class DescriptionRequest
{
    public string? description { get; set; }
}
