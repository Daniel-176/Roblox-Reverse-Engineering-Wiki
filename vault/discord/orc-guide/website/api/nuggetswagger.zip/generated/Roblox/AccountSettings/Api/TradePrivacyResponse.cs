using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class TradePrivacyResponse
{
    public string? tradePrivacy { get; set; }
}
