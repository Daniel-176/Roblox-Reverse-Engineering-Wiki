using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class EmailValidationRequestModel
{
    public string? email { get; set; }
}
