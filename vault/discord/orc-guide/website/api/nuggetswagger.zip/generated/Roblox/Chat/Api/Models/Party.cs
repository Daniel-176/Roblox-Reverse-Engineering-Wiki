using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class Party
{
    public string? Id { get; set; }
    public long ConversationId { get; set; }
    public Roblox.Chat.Api.Models.PartyUser CreatorUser { get; set; }
    public Roblox.Chat.Api.Models.PartyUser LeaderUser { get; set; }
    public Roblox.Chat.Api.Models.PartyUser[] PendingUsers { get; set; }
    public Roblox.Chat.Api.Models.PartyUser[] MemberUsers { get; set; }
    public string? GameId { get; set; }
    public string? GameName { get; set; }
    public long GamePlaceId { get; set; }
    public DateTime? GameSlotExpiry { get; set; }
    public string? PartyType { get; set; }
}
