using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class EmailResponse
{
    public string? emailAddress { get; set; }
    public bool verified { get; set; }
    public bool canBypassPasswordForEmailUpdate { get; set; }
}
