using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class TeamCreateMembershipRequest
{
    public long userId { get; set; }
}
