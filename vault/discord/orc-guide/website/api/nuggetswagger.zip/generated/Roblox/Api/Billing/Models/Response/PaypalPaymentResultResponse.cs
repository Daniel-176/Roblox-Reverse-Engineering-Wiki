using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class PaypalPaymentResultResponse
{
    public bool success { get; set; }
    public bool isRetry { get; set; }
    public int errorCode { get; set; }
    public string? errorMsg { get; set; }
    public string? redirectLink { get; set; }
}
