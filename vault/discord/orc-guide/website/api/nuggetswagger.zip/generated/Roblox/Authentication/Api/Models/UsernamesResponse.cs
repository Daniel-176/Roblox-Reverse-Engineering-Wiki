using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class UsernamesResponse
{
    public string[] usernames { get; set; }
}
