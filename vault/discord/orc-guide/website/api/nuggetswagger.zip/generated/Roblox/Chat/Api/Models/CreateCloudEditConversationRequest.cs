using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class CreateCloudEditConversationRequest
{
    public long placeId { get; set; }
}
