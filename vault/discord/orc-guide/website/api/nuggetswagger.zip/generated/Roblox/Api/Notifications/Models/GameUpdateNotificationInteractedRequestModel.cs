using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class GameUpdateNotificationInteractedRequestModel
{
    public long universeId { get; set; }
    public string? createdOnKey { get; set; }
    public string? interactionType { get; set; }
    public long currentUserId { get; set; }
}
