using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class CreatePartyRequest
{
    public long[] invitedUserIds { get; set; }
    public long conversationId { get; set; }
}
