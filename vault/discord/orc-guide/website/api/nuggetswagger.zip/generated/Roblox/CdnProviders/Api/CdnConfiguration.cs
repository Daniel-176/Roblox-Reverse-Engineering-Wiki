using System;
using System.Collections.Generic;

namespace Roblox.CdnProviders.Api;

public class CdnConfiguration
{
    public string? cdnName { get; set; }
    public bool globalEnabled { get; set; }
    public Roblox.CdnProviders.Api.DomainsEnabled domainsEnabled { get; set; }
    public object? marketWeights { get; set; }
}
