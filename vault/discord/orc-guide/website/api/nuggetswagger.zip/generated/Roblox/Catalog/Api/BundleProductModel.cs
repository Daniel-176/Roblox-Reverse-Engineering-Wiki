using System;
using System.Collections.Generic;

namespace Roblox.Catalog.Api;

public class BundleProductModel
{
    public long id { get; set; }
    public string? type { get; set; }
    public bool isPublicDomain { get; set; }
    public bool isForSale { get; set; }
    public long priceInRobux { get; set; }
    public bool isFree { get; set; }
    public string? noPriceText { get; set; }
    public Roblox.Catalog.Api.PremiumPricingModel premiumPricing { get; set; }
}
