using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class BirthdateRequest
{
    public int birthMonth { get; set; }
    public int birthDay { get; set; }
    public int birthYear { get; set; }
}
