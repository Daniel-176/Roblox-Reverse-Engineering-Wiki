using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Requests;

public class GamecardReversalRequest
{
    public string? PinCode { get; set; }
    public long UserId { get; set; }
}
