using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class PromotionChannelsResponse
{
    public string? promotionChannelsVisibilityPrivacy { get; set; }
    public string? facebook { get; set; }
    public string? twitter { get; set; }
    public string? youtube { get; set; }
    public string? twitch { get; set; }
}
