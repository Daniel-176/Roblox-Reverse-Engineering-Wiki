using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class GenderRequest
{
    public string? gender { get; set; }
}
