using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class UserPushDestination
{
    public Roblox.Api.Notifications.Models.NotificationUser user { get; set; }
    public string? name { get; set; }
    public string? notificationToken { get; set; }
    public bool supportsUpdateNotifications { get; set; }
    public long userPushNotificationDestinationId { get; set; }
    public string? application { get; set; }
    public string? platform { get; set; }
}
