using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class VerifyPhoneRequest
{
    public string? code { get; set; }
}
