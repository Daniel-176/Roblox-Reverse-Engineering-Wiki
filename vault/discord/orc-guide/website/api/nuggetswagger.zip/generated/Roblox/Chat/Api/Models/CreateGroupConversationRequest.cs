using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class CreateGroupConversationRequest
{
    public long[] participantUserIds { get; set; }
    public string? title { get; set; }
}
