using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class RemoveUserFromConversationResponse
{
    public long conversationId { get; set; }
    public string? resultType { get; set; }
    public string? statusMessage { get; set; }
}
