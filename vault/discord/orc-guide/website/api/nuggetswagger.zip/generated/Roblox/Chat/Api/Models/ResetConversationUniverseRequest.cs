using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class ResetConversationUniverseRequest
{
    public long conversationId { get; set; }
}
