using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class SendCredentialsVerificationMessageRequest
{
    public string? credentialType { get; set; }
    public string? credentialValue { get; set; }
    public string? password { get; set; }
}
