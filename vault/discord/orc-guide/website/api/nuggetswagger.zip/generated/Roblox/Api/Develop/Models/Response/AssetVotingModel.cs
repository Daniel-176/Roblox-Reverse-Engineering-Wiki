using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models.Response;

public class AssetVotingModel
{
    public long assetId { get; set; }
    public bool hasUserVoted { get; set; }
    public bool canUserVote { get; set; }
    public bool shouldShowVotes { get; set; }
    public long upVotes { get; set; }
    public long downVotes { get; set; }
    public string? reasonForNotAbleToVote { get; set; }
}
