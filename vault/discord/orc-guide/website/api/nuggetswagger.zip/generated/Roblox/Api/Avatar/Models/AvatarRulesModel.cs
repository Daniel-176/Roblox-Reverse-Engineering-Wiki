using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class AvatarRulesModel
{
    public string[] playerAvatarTypes { get; set; }
    public object? scales { get; set; }
    public Roblox.Api.Avatar.Models.AssetTypeRulesModel[] wearableAssetTypes { get; set; }
    public Roblox.Api.Avatar.Models.BodyColorModel[] bodyColorsPalette { get; set; }
    public Roblox.Api.Avatar.Models.BodyColorModel[] basicBodyColorsPalette { get; set; }
    public double minimumDeltaEBodyColorDifference { get; set; }
    public bool proportionsAndBodyTypeEnabledForUser { get; set; }
    public Roblox.Api.Avatar.Models.DefaultClothingAssets defaultClothingAssetLists { get; set; }
    public bool bundlesEnabledForUser { get; set; }
    public bool emotesEnabledForUser { get; set; }
}
