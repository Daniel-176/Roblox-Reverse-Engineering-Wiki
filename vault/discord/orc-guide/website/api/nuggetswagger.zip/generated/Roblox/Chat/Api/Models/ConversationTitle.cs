using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class ConversationTitle
{
    public string? titleForViewer { get; set; }
    public bool isDefaultTitle { get; set; }
}
