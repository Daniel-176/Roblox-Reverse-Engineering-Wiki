using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class MarkAsReadResponse
{
    public string? resultType { get; set; }
}
