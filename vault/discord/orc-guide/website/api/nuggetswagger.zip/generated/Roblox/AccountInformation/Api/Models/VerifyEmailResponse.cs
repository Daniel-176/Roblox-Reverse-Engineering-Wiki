using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class VerifyEmailResponse
{
    public int verifiedUserHatAssetId { get; set; }
}
