using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class TwoStepVerificationTicketRequest
{
    public string? username { get; set; }
    public string? ticket { get; set; }
    public string? actionType { get; set; }
}
