using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class MaskedCreditCardInfoModel
{
    public string? firstSix { get; set; }
    public string? lastFour { get; set; }
    public int expirationMonth { get; set; }
    public int expirationYear { get; set; }
}
