using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class Conversation
{
    public long id { get; set; }
    public string? title { get; set; }
    public Roblox.Chat.Api.Models.ChatParticipant initiator { get; set; }
    public bool hasUnreadMessages { get; set; }
    public Roblox.Chat.Api.Models.ChatParticipant[] participants { get; set; }
    public string? conversationType { get; set; }
    public Roblox.Chat.Api.Models.ConversationTitle conversationTitle { get; set; }
    public DateTime? lastUpdated { get; set; }
    public Roblox.Chat.Api.Models.ConversationUniverse conversationUniverse { get; set; }
}
