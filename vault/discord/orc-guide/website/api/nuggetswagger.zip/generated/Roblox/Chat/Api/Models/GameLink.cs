using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class GameLink
{
    public long universeId { get; set; }
}
