using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class StatisticsResponse
{
    public long placeId { get; set; }
    public string? dataType { get; set; }
    public string? dataGranularity { get; set; }
    public DateTime? startTime { get; set; }
    public DateTime? endTime { get; set; }
    public object? data { get; set; }
}
