using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class GooglePlayPurchaseModel
{
    public string? packageName { get; set; }
    public string? productId { get; set; }
    public string? token { get; set; }
    public bool isRetry { get; set; }
    public string? orderId { get; set; }
}
