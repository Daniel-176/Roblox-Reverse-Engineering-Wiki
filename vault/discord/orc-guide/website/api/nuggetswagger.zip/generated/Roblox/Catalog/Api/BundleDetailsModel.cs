using System;
using System.Collections.Generic;

namespace Roblox.Catalog.Api;

public class BundleDetailsModel
{
    public long id { get; set; }
    public string? name { get; set; }
    public string? description { get; set; }
    public string? bundleType { get; set; }
    public Roblox.Catalog.Api.BundleItemDetailModel[] items { get; set; }
    public Roblox.Catalog.Api.BundleCreatorModel creator { get; set; }
    public Roblox.Catalog.Api.BundleProductModel product { get; set; }
}
