using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class RevenueReportStatusListResponse
{
    public Roblox.Api.Develop.Models.MonthlyRevenueReportStatus[] monthlyRevenueReportStatusList { get; set; }
}
