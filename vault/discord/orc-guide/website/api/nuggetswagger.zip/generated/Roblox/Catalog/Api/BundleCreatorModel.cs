using System;
using System.Collections.Generic;

namespace Roblox.Catalog.Api;

public class BundleCreatorModel
{
    public long id { get; set; }
    public string? name { get; set; }
    public string? type { get; set; }
}
