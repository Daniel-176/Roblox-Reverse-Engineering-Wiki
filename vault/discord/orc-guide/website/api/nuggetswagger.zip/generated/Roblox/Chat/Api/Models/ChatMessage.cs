using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class ChatMessage
{
    public string? id { get; set; }
    public string? senderType { get; set; }
    public DateTime? sent { get; set; }
    public bool read { get; set; }
    public string? messageType { get; set; }
    public string[] decorators { get; set; }
    public long senderTargetId { get; set; }
    public string? content { get; set; }
    public Roblox.Chat.Api.Models.Link link { get; set; }
    public Roblox.Chat.Api.Models.EventBased eventBased { get; set; }
}
