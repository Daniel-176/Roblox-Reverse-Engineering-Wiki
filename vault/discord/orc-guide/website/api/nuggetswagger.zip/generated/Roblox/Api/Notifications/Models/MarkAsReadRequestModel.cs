using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class MarkAsReadRequestModel
{
    public string? platformType { get; set; }
    public string? notificationId { get; set; }
}
