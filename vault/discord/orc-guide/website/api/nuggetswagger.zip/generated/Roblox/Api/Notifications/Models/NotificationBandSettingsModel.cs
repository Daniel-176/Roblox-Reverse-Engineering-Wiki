using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class NotificationBandSettingsModel
{
    public Roblox.Api.Notifications.Models.NotificationBandSettingModel[] updatedSettings { get; set; }
}
