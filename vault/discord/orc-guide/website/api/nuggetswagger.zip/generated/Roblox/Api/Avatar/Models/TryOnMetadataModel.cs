using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class TryOnMetadataModel
{
    public bool tryOnEndpointsEnabled { get; set; }
}
