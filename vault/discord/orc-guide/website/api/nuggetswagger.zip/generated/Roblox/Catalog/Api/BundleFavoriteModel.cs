using System;
using System.Collections.Generic;

namespace Roblox.Catalog.Api;

public class BundleFavoriteModel
{
    public long bundleId { get; set; }
    public long userId { get; set; }
    public DateTime? created { get; set; }
}
