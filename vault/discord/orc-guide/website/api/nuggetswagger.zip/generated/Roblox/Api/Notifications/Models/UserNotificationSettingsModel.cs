using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class UserNotificationSettingsModel
{
    public Roblox.Api.Notifications.Models.ReceiverNotificationSettingGroupModel[] notificationBandSettings { get; set; }
    public string[] optedOutNotificationSourceTypes { get; set; }
    public string[] optedOutReceiverDestinationTypes { get; set; }
}
