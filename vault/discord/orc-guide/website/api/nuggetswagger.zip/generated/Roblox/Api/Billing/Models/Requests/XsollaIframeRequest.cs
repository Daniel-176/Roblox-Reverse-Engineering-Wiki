using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Requests;

public class XsollaIframeRequest
{
    public int mainProductId { get; set; }
    public int upsellProductId { get; set; }
    public string? paymentProviderType { get; set; }
    public bool verifiedEmailOrPhone { get; set; }
}
