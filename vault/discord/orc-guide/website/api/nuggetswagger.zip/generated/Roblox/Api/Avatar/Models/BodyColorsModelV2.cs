using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class BodyColorsModelV2
{
    public string? headColor3 { get; set; }
    public string? torsoColor3 { get; set; }
    public string? rightArmColor3 { get; set; }
    public string? leftArmColor3 { get; set; }
    public string? rightLegColor3 { get; set; }
    public string? leftLegColor3 { get; set; }
}
