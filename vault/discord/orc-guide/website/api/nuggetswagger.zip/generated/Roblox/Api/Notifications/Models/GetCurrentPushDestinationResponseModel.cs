using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class GetCurrentPushDestinationResponseModel
{
    public Roblox.Api.Notifications.Models.UserPushDestination destination { get; set; }
    public string? statusMessage { get; set; }
}
