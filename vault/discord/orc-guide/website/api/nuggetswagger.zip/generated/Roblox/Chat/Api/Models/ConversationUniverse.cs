using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class ConversationUniverse
{
    public long universeId { get; set; }
    public long rootPlaceId { get; set; }
}
