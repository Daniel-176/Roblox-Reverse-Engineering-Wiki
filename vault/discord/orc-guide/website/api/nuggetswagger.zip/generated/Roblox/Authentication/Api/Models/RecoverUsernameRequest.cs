using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class RecoverUsernameRequest
{
    public string? targetType { get; set; }
    public string? target { get; set; }
}
