using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop;

public class DeveloperProductResponse
{
    public long id { get; set; }
    public string? name { get; set; }
    public string? Description { get; set; }
    public long shopId { get; set; }
    public long iconImageAssetId { get; set; }
}
