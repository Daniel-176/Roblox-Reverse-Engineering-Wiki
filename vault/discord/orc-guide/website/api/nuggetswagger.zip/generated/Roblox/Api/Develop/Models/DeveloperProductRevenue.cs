using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class DeveloperProductRevenue
{
    public string? developerProductName { get; set; }
    public long revenueAmount { get; set; }
}
