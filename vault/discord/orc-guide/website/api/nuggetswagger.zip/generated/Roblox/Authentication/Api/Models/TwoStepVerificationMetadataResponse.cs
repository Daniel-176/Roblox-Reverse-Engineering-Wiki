using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class TwoStepVerificationMetadataResponse
{
    public int codeLength { get; set; }
    public string? loadingImageUrl { get; set; }
    public string? supportUrl { get; set; }
}
