using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Requests;

public class CreditPaymentCheckoutRequest
{
    public int productId { get; set; }
}
