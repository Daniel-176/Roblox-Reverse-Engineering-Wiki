using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class SubscriptionRequest
{
    public long subscription_id { get; set; }
    public string? plan_id { get; set; }
    public string? product_id { get; set; }
    public DateTime? date_create { get; set; }
    public DateTime? date_next_charge { get; set; }
    public string? currency { get; set; }
    public double amount { get; set; }
}
