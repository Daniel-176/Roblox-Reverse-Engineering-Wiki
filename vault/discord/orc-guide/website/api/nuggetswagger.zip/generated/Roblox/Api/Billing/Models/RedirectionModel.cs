using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class RedirectionModel
{
    public string? redirectionUrl { get; set; }
    public string? redirectionParams { get; set; }
}
