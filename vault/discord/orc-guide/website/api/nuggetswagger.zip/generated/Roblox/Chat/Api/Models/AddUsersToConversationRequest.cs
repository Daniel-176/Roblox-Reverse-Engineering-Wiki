using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class AddUsersToConversationRequest
{
    public long[] participantUserIds { get; set; }
    public long conversationId { get; set; }
}
