using System;
using System.Collections.Generic;

namespace Roblox.AdConfiguration.Api.Models;

public class UniverseModel
{
    public long id { get; set; }
    public string? name { get; set; }
}
