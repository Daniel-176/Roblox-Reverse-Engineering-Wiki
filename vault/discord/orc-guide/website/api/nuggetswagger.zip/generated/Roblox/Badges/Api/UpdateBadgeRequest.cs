using System;
using System.Collections.Generic;

namespace Roblox.Badges.Api;

public class UpdateBadgeRequest
{
    public string? name { get; set; }
    public string? description { get; set; }
    public bool enabled { get; set; }
}
