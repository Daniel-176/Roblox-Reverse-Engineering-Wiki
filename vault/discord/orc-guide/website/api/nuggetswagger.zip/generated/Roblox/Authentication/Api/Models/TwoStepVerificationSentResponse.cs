using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class TwoStepVerificationSentResponse
{
    public string? mediaType { get; set; }
    public string? ticket { get; set; }
}
