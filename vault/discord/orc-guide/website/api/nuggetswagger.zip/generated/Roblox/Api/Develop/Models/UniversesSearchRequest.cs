using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class UniversesSearchRequest
{
    public System.Tuple<System.String, Roblox.DataV2.Core.SortOrder>[] Sorts { get; set; }
    public string? RawQuery { get; set; }
    public string? Keywords { get; set; }
    public bool IsArchived { get; set; }
    public bool IsActive { get; set; }
    public string? UniverseSearchPreset { get; set; }
    public string[] GroupIds { get; set; }
}
