using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class VantivPaymentResponse
{
    public bool isSuccess { get; set; }
    public string? redirectLink { get; set; }
    public string? errorMessage { get; set; }
    public Roblox.Api.Billing.Models.VantivPaymentViewModel viewModel { get; set; }
}
