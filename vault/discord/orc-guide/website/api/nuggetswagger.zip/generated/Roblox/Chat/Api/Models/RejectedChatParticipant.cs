using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class RejectedChatParticipant
{
    public string? rejectedReason { get; set; }
    public string? type { get; set; }
    public long targetId { get; set; }
    public string? name { get; set; }
    public string? displayName { get; set; }
}
