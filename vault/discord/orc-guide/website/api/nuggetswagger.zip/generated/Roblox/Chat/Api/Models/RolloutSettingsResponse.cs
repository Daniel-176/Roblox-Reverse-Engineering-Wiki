using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class RolloutSettingsResponse
{
    public Roblox.Chat.Api.Models.RolloutSettingModel[] rolloutFeatures { get; set; }
}
