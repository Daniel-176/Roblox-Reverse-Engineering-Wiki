using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Requests;

public class PromoCodeRequest
{
    public string? code { get; set; }
}
