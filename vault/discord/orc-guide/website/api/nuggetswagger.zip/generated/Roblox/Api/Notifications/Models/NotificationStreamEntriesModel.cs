using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class NotificationStreamEntriesModel
{
    public string? id { get; set; }
    public string? notificationSourceType { get; set; }
    public DateTime? eventDate { get; set; }
    public bool isInteracted { get; set; }
    public object[] metadataCollection { get; set; }
    public long eventCount { get; set; }
}
