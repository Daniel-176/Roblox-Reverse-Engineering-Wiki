using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class RegisterAndroidAmazonRequestModel
{
    public string? notificationToken { get; set; }
    public bool authorizeForUser { get; set; }
    public string? oldNotificationToken { get; set; }
    public string? deviceName { get; set; }
}
