using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class GameUpdateMessageModel
{
    public long universeId { get; set; }
    public DateTime? createdOn { get; set; }
    public string? createdOnKey { get; set; }
    public string? creatorType { get; set; }
    public long creatorId { get; set; }
    public string? creatorName { get; set; }
    public DateTime? expiredOn { get; set; }
    public string? content { get; set; }
    public long impressions { get; set; }
    public long plays { get; set; }
    public long unfollows { get; set; }
}
