using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class PartyUser
{
    public long Id { get; set; }
    public string? Name { get; set; }
}
