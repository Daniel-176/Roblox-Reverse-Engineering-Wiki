using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class ReceiverNotificationSettingGroupModel
{
    public string? notificationSourceType { get; set; }
    public string? receiverDestinationType { get; set; }
    public bool isEnabled { get; set; }
    public bool isOverridable { get; set; }
    public bool isSetByReceiver { get; set; }
    public Roblox.Api.Notifications.Models.ReceiverDestinationSettingModel[] pushNotificationDestinationPreferences { get; set; }
}
