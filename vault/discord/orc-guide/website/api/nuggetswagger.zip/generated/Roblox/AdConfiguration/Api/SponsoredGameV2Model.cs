using System;
using System.Collections.Generic;

namespace Roblox.AdConfiguration.Api;

public class SponsoredGameV2Model
{
    public long adId { get; set; }
    public long adSetId { get; set; }
    public string? adName { get; set; }
    public string? adStatus { get; set; }
    public string? creativeType { get; set; }
    public long creativeTargetId { get; set; }
    public string? creativeUrl { get; set; }
    public long bidAmountInRobux { get; set; }
    public long budgetInRobux { get; set; }
    public string? adSetStatus { get; set; }
    public DateTime? startDate { get; set; }
    public DateTime? endDate { get; set; }
    public string? targetGender { get; set; }
    public string? targetAgeBracket { get; set; }
    public string? targetDeviceType { get; set; }
    public string? campaignTargetType { get; set; }
    public long campaignTargetId { get; set; }
    public long totalSpendInRobux { get; set; }
    public long totalImpressions { get; set; }
    public long totalClicks { get; set; }
    public long totalConversions { get; set; }
    public long impressionConversions { get; set; }
    public long clickConversions { get; set; }
}
