using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class VantivPaymentMetadataResponse
{
    public Roblox.Api.Billing.Models.VantivPaymentViewModel viewModel { get; set; }
    public string? redirectLink { get; set; }
}
