using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class SendVerifyEmailRequest
{
    public bool freeItem { get; set; }
}
