using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class PlaceCompatibilityModel
{
    public string? status { get; set; }
    public string? platformName { get; set; }
    public double crashRatePercentage { get; set; }
}
