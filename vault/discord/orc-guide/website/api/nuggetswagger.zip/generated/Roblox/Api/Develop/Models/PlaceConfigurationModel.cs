using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class PlaceConfigurationModel
{
    public string? name { get; set; }
    public string? description { get; set; }
}
