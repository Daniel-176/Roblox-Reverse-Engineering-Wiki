using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class SignupRequest
{
    public string? username { get; set; }
    public string? password { get; set; }
    public string? gender { get; set; }
    public DateTime? birthday { get; set; }
    public bool isTosAgreementBoxChecked { get; set; }
    public string? email { get; set; }
    public string? locale { get; set; }
    public long[] assetIds { get; set; }
    public int bodyColorId { get; set; }
    public double bodyTypeScale { get; set; }
    public double headScale { get; set; }
    public double heightScale { get; set; }
    public double widthScale { get; set; }
    public double proportionScale { get; set; }
    public Roblox.Authentication.Api.Models.ReferralDataModel referralData { get; set; }
    public string[] agreementIds { get; set; }
    public string? identityVerificationResultToken { get; set; }
    public Roblox.Authentication.Api.Models.Request.SecureAuthenticationIntentModel secureAuthenticationIntent { get; set; }
    public Roblox.Authentication.Api.Models.Request.OtpSessionModel otpSession { get; set; }
    public string? captchaId { get; set; }
    public string? captchaToken { get; set; }
    public string? captchaProvider { get; set; }
    public string? challengeId { get; set; }
}
