using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api;

public class TwoStepVerificationLoginRequest
{
    public string? challengeId { get; set; }
    public string? verificationToken { get; set; }
    public bool rememberDevice { get; set; }
}
