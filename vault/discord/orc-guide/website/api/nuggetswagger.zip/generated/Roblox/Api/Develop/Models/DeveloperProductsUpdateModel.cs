using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class DeveloperProductsUpdateModel
{
    public string? Name { get; set; }
    public string? Description { get; set; }
    public long IconImageAssetId { get; set; }
    public long PriceInRobux { get; set; }
}
