using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class MarkInteractionRequestModel
{
    public string? platformType { get; set; }
    public string? notificationToken { get; set; }
    public string? notificationId { get; set; }
    public string? interactionType { get; set; }
}
