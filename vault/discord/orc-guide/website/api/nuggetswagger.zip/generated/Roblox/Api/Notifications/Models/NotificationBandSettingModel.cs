using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class NotificationBandSettingModel
{
    public string? notificationSourceType { get; set; }
    public string? receiverDestinationType { get; set; }
    public bool isEnabled { get; set; }
}
