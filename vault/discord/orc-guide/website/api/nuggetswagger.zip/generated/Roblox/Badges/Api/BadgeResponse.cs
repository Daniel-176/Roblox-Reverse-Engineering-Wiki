using System;
using System.Collections.Generic;

namespace Roblox.Badges.Api;

public class BadgeResponse
{
    public long id { get; set; }
    public string? name { get; set; }
    public string? description { get; set; }
    public string? displayName { get; set; }
    public string? displayDescription { get; set; }
    public bool enabled { get; set; }
    public long iconImageId { get; set; }
    public long displayIconImageId { get; set; }
    public DateTime? created { get; set; }
    public DateTime? updated { get; set; }
    public Roblox.Web.Responses.Badges.BadgeAwardStatisticsResponse statistics { get; set; }
    public Roblox.Badges.Api.UniverseResponse awardingUniverse { get; set; }
}
