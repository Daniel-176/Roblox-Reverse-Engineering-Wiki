using System;
using System.Collections.Generic;

namespace Roblox.Badges.Api;

public class UniverseResponse
{
    public long id { get; set; }
    public string? name { get; set; }
    public long rootPlaceId { get; set; }
}
