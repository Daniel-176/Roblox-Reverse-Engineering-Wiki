using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class AssetModel
{
    public long id { get; set; }
    public string? name { get; set; }
    public Roblox.Api.Avatar.Models.AssetTypeModel assetType { get; set; }
}
