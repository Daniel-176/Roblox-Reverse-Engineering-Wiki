using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class RegisterChromeRequestModel
{
    public string? notificationToken { get; set; }
    public bool initiatedByUser { get; set; }
}
