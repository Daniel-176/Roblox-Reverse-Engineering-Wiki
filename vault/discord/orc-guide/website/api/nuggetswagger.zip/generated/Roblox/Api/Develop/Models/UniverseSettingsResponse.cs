using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class UniverseSettingsResponse
{
    public long id { get; set; }
    public string? name { get; set; }
    public string? universeAvatarType { get; set; }
    public string? universeScaleType { get; set; }
    public string? universeAnimationType { get; set; }
    public string? universeCollisionType { get; set; }
    public string? universeBodyType { get; set; }
    public string? universeJointPositioningType { get; set; }
    public bool isArchived { get; set; }
    public bool isFriendsOnly { get; set; }
    public string? genre { get; set; }
    public string[] playableDevices { get; set; }
    public bool isForSale { get; set; }
    public long price { get; set; }
}
