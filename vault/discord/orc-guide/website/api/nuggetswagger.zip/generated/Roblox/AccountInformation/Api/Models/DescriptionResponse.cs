using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class DescriptionResponse
{
    public string? description { get; set; }
}
