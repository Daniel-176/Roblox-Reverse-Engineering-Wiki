using System;
using System.Collections.Generic;

namespace Roblox.AccountInformation.Api.Models;

public class StarCodeAffiliateRequest
{
    public string? code { get; set; }
}
