using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class InviteUserRequest
{
    public string? partyId { get; set; }
    public long invitedUserId { get; set; }
}
