using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models.Response;

public class PlaceCompatibilitiesResponse
{
    public Roblox.Api.Develop.Models.PlaceCompatibilityModel[] Compatibilities { get; set; }
}
