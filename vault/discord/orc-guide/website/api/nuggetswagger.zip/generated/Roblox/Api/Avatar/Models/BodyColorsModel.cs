using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class BodyColorsModel
{
    public int headColorId { get; set; }
    public int torsoColorId { get; set; }
    public int rightArmColorId { get; set; }
    public int leftArmColorId { get; set; }
    public int rightLegColorId { get; set; }
    public int leftLegColorId { get; set; }
}
