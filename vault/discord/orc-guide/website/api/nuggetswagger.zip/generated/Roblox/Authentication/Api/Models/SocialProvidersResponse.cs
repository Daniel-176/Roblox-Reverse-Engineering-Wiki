using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class SocialProvidersResponse
{
    public Roblox.Authentication.Api.Models.ProviderInfoModel[] providers { get; set; }
}
