using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class ReferralDataModel
{
    public DateTime? acquisitionTime { get; set; }
    public string? acquisitionReferrer { get; set; }
    public string? medium { get; set; }
    public string? source { get; set; }
    public string? campaign { get; set; }
    public string? adGroup { get; set; }
    public string? keyword { get; set; }
    public string? matchType { get; set; }
    public bool sendInfo { get; set; }
    public string? requestSessionId { get; set; }
    public string? offerId { get; set; }
}
