using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class TransactionRequest
{
    public int id { get; set; }
    public string? external_id { get; set; }
    public DateTime? payment_date { get; set; }
    public int payment_method { get; set; }
    public int dry_run { get; set; }
}
