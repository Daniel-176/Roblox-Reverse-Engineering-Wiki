using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class UserRequest
{
    public string? id { get; set; }
    public string? ip { get; set; }
    public string? phone { get; set; }
    public string? email { get; set; }
    public string? country { get; set; }
}
