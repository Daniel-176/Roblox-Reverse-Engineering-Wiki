using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class PushNotificationClientMetadata
{
    public string? notificationId { get; set; }
    public string? type { get; set; }
    public object? detail { get; set; }
    public bool fallbackDelivered { get; set; }
}
