using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class RegisterFirefoxRequestModel
{
    public string? notificationToken { get; set; }
    public string? notificationEndpoint { get; set; }
    public bool initiatedByUser { get; set; }
}
