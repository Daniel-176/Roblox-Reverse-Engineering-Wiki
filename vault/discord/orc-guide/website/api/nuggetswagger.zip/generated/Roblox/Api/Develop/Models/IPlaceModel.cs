using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class IPlaceModel
{
}
