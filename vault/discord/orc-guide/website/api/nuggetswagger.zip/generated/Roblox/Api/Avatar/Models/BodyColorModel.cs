using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class BodyColorModel
{
    public int brickColorId { get; set; }
    public string? hexColor { get; set; }
    public string? name { get; set; }
}
