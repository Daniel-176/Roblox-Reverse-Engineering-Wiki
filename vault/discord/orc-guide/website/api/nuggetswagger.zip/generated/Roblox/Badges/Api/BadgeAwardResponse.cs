using System;
using System.Collections.Generic;

namespace Roblox.Badges.Api;

public class BadgeAwardResponse
{
    public long badgeId { get; set; }
    public DateTime? awardedDate { get; set; }
}
