using System;
using System.Collections.Generic;

namespace Roblox.AdConfiguration.Api.Models;

public class GetRecentAdsRankedUniversesResponse
{
    public Roblox.AdConfiguration.Api.Models.UniverseModel[] universes { get; set; }
}
