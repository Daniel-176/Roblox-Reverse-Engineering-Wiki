using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class UserResponse
{
    public string? buildersClubMembershipType { get; set; }
    public long userId { get; set; }
    public string? username { get; set; }
    public string? displayName { get; set; }
}
