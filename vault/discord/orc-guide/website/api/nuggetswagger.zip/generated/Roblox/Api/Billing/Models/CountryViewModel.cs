using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models;

public class CountryViewModel
{
    public string? code { get; set; }
    public string? name { get; set; }
    public bool isSelected { get; set; }
}
