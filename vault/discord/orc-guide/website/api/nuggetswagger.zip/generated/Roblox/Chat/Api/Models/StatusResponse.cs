using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class StatusResponse
{
    public bool Success { get; set; }
    public string? StatusMessage { get; set; }
}
