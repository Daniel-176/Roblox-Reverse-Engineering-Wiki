using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models.Request;

public class SecureAuthenticationIntentModel
{
    public string? clientPublicKey { get; set; }
    public long clientEpochTimestamp { get; set; }
    public string? saiSignature { get; set; }
    public string? serverNonce { get; set; }
}
