using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class MarkAsSeenResponse
{
    public string? resultType { get; set; }
}
