using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models.Response;

public class StatisticsRange
{
    public string? type { get; set; }
    public object? data { get; set; }
}
