using System;
using System.Collections.Generic;

namespace Roblox.Billing.Api;

public class PaymentResponse
{
    public DateTime? paymentDate { get; set; }
    public Roblox.Billing.Api.PurchasedProductResponse[] products { get; set; }
    public Roblox.Platform.BillingV2.Core.Money money { get; set; }
    public string? paymentProviderType { get; set; }
    public string? creditCardType { get; set; }
    public string? cardNumber { get; set; }
}
