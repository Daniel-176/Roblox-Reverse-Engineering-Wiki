using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class PaymentMethodsResponse
{
    public string? redirectUrl { get; set; }
    public Roblox.Platform.Billing.ProductDisplayModel selectedProduct { get; set; }
    public bool loggedIn { get; set; }
    public double currentCredit { get; set; }
    public Roblox.Api.Billing.Models.Response.PaymentMethodsVisibility paymentMethodsVisibility { get; set; }
    public bool isNewRobuxIconEnabled { get; set; }
    public bool isStarcodeV2Enabled { get; set; }
    public bool allowCreditForRenewingPurchases { get; set; }
}
