using System;
using System.Collections.Generic;

namespace Roblox.Catalog.Api;

public class BundleItemDetailModel
{
    public bool owned { get; set; }
    public long id { get; set; }
    public string? name { get; set; }
    public string? type { get; set; }
}
