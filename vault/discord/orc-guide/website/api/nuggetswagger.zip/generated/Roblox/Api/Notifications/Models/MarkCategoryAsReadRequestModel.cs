using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class MarkCategoryAsReadRequestModel
{
    public string? notificationType { get; set; }
    public string? category { get; set; }
    public string? latestNotificationId { get; set; }
}
