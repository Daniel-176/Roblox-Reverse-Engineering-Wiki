using System;
using System.Collections.Generic;

namespace Roblox.AccountSettings.Api;

public class PrivateMessagePrivacyRequest
{
    public string? privateMessagePrivacy { get; set; }
}
