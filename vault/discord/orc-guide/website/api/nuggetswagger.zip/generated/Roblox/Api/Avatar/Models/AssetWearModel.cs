using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class AssetWearModel
{
    public long id { get; set; }
    public Roblox.Api.Avatar.Models.AssetMetaModelV1 meta { get; set; }
}
