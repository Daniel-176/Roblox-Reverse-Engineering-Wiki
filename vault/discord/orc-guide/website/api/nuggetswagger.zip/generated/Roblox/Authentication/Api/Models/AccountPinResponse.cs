using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class AccountPinResponse
{
    public double unlockedUntil { get; set; }
}
