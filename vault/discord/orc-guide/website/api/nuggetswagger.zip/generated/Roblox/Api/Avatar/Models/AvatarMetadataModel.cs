using System;
using System.Collections.Generic;

namespace Roblox.Api.Avatar.Models;

public class AvatarMetadataModel
{
    public bool enableDefaultClothingMessage { get; set; }
    public bool isAvatarScaleEmbeddedInTab { get; set; }
    public bool isBodyTypeScaleOutOfTab { get; set; }
    public double scaleHeightIncrement { get; set; }
    public double scaleWidthIncrement { get; set; }
    public double scaleHeadIncrement { get; set; }
    public double scaleProportionIncrement { get; set; }
    public double scaleBodyTypeIncrement { get; set; }
    public bool supportProportionAndBodyType { get; set; }
    public bool showDefaultClothingMessageOnPageLoad { get; set; }
    public bool areThreeDeeThumbsEnabled { get; set; }
}
