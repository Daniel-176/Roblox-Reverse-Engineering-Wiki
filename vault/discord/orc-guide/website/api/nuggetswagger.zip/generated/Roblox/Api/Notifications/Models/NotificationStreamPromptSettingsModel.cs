using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class NotificationStreamPromptSettingsModel
{
    public bool hasUserInteractedWithNotificationStream { get; set; }
    public bool showNotificationStreamPrompt { get; set; }
}
