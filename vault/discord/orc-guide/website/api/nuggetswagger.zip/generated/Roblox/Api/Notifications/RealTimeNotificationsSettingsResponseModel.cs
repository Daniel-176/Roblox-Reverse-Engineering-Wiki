using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications;

public class RealTimeNotificationsSettingsResponseModel
{
    public string? primaryDomain { get; set; }
    public string? fallbackDomain { get; set; }
}
