using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Response;

public class PromoCodeResponse
{
    public bool success { get; set; }
    public string? errorMsg { get; set; }
    public string? successMsg { get; set; }
}
