using System;
using System.Collections.Generic;

namespace Roblox.Chat.Api.Models;

public class EventBased
{
    public string? type { get; set; }
    public Roblox.Chat.Api.Models.SetConversationUniverseEventBased setConversationUniverse { get; set; }
}
