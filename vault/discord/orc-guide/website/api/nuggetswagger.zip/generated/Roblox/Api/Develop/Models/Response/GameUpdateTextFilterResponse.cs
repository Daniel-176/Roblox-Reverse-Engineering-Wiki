using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models.Response;

public class GameUpdateTextFilterResponse
{
    public string? filteredGameUpdateText { get; set; }
    public bool isFiltered { get; set; }
    public string? moderationLevel { get; set; }
}
