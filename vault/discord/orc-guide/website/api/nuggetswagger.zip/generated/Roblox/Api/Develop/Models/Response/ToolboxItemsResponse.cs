using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models.Response;

public class ToolboxItemsResponse
{
    public long TotalResults { get; set; }
    public Roblox.Web.ToolboxResponseModels.ToolboxItemModel[] Results { get; set; }
}
