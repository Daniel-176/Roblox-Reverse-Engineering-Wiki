using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class RecommendedUsernameResponse
{
    public bool didGenerateNewUsername { get; set; }
    public string? suggestedUsername { get; set; }
}
