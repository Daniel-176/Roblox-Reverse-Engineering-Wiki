using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class SuccessResponseModel
{
    public string? statusMessage { get; set; }
}
