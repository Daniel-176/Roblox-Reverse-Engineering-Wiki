using System;
using System.Collections.Generic;

namespace Roblox.Api.Develop.Models;

public class UniversePermissionsModel
{
    public bool canManage { get; set; }
    public bool canCloudEdit { get; set; }
}
