using System;
using System.Collections.Generic;

namespace Roblox.Api.Notifications.Models;

public class ReceiverDestinationTypeModel
{
    public string? destinationType { get; set; }
}
