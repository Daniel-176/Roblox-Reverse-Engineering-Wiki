using System;
using System.Collections.Generic;

namespace Roblox.Api.Billing.Models.Requests;

public class VantivPaymentRequest
{
    public string? paypageRegistrationId { get; set; }
    public Roblox.Api.Billing.Models.MaskedCreditCardInfoModel maskedCreditCardInfoModel { get; set; }
    public string? kountSessionIdentifier { get; set; }
    public string? vantivThreatMetrixIdentifier { get; set; }
    public string? firstName { get; set; }
    public string? lastName { get; set; }
    public string? address1 { get; set; }
    public string? address2 { get; set; }
    public string? city { get; set; }
    public string? state { get; set; }
    public string? zip { get; set; }
    public string? country { get; set; }
    public string? email { get; set; }
    public string? phone { get; set; }
    public Roblox.Api.Billing.Models.ProductModel mainProduct { get; set; }
    public Roblox.Api.Billing.Models.ProductModel upsellProduct { get; set; }
    public double expectedPrice { get; set; }
    public bool isDoublePurchaseConfirmed { get; set; }
}
