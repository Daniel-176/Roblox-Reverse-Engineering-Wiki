using System;
using System.Collections.Generic;

namespace Roblox.Authentication.Api.Models;

public class XboxTranslateRequest
{
    public string[] ids { get; set; }
}
