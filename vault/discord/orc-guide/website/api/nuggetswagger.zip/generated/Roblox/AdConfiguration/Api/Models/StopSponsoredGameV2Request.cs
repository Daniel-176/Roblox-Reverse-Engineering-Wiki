using System;
using System.Collections.Generic;

namespace Roblox.AdConfiguration.Api.Models;

public class StopSponsoredGameV2Request
{
    public long adSetId { get; set; }
}
