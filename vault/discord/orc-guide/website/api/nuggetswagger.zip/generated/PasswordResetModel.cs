using System;
using System.Collections.Generic;

namespace (global);

public class PasswordResetModel
{
    public string? ticket { get; set; }
    public string? password { get; set; }
}
