using System;
using System.Collections.Generic;

namespace (global);

public class IGroupMembership
{
}
