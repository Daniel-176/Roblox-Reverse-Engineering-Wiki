using System;
using System.Collections.Generic;

namespace (global);

public class PasswordResetVerificationRequest
{
    public string? nonce { get; set; }
    public string? code { get; set; }
}
