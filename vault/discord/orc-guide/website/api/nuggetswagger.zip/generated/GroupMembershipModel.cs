using System;
using System.Collections.Generic;

namespace (global);

public class GroupMembershipModel
{
    public string? Name { get; set; }
    public long Id { get; set; }
    public string? EmblemUrl { get; set; }
    public long EmblemId { get; set; }
    public int Rank { get; set; }
    public string? Role { get; set; }
    public bool IsPrimary { get; set; }
    public bool IsInClan { get; set; }
}
