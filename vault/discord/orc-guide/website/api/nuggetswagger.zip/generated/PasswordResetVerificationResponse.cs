using System;
using System.Collections.Generic;

namespace (global);

public class PasswordResetVerificationResponse
{
    public ForgotPasswordUserResponse[] userTickets { get; set; }
}
